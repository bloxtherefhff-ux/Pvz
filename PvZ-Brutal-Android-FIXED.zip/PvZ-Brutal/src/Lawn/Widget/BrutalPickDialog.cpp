#include "BrutalPickDialog.h"
#include "../../LawnApp.h"
#include "../System/PlayerInfo.h"
#include "../Brutal/BrutalSecrets.h"
#include "GameButton.h"
#include "ChallengeScreen.h"
#include "../Board.h"
#include "../LawnCommon.h"
#include "../System/SaveGame.h"
#include "../../GameConstants.h"
#include "../../PvzpLib/PvzpStringFile.h"
#include "widget/WidgetManager.h"
#include <algorithm>
#include <format>
#include <utility>

namespace
{
constexpr int kSecretEntriesPerPage = 12;
constexpr int kSecretSlotCount = 12;
constexpr int kSecretPrevIndex = 12;
constexpr int kSecretPageIndex = 13;
constexpr int kSecretNextIndex = 14;
constexpr int kSecretCloseIndex = 15;
}

BrutalPickDialog::BrutalPickDialog(LawnApp* theApp, BrutalPickMode mode)
	: LawnDialog(theApp, Dialogs::DIALOG_BRUTAL_PICK, true,
		mode == BrutalPickMode::Secrets ? "BRUTAL SECRETS" :
		mode == BrutalPickMode::SaveStates ? "SAVE STATES — CHOOSE SLOT" :
		mode == BrutalPickMode::Admin ? "ADMIN PANEL" :
		mode == BrutalPickMode::Spawner ? "ADMIN: SPAWN ZOMBIE" : "CHEATS — TAP ONE",
		"", "", Dialog::BUTTONS_NONE)
	, mApp(theApp)
	, mMode(mode)
{
	mVerticalCenterText = false;
	auto addBtn = [this](int id, const std::string& label)
	{
		mButtons.push_back(MakeButton(id, this, label));
	};

	if (mMode == BrutalPickMode::SaveStates)
	{
		for (int slot = 1; slot <= 3; ++slot)
		{
			addBtn(Btn_SaveSlotBase + slot - 1, std::format("Save Slot {}", slot));
			addBtn(Btn_LoadSlotBase + slot - 1, std::format("Load Slot {}", slot));
		}
		addBtn(Btn_Close, "Back to Game");
		CalcSize(100, 190);
		return;
	}

	if (mMode == BrutalPickMode::Admin)
	{
		addBtn(Btn_AdminCheats, "Open Cheats");
		addBtn(Btn_AdminSecrets, "Open Secrets");
		addBtn(Btn_AdminUnlock, "Unlock All Modes");
		addBtn(Btn_AdminBeatEverything, "Complete Everything");
		addBtn(Btn_Close, "Close Admin Panel");
		CalcSize(330, 48 + static_cast<int>(mButtons.size()) * 40);
		return;
	}

	if (mMode == BrutalPickMode::Cheats)
	{
		addBtn(Btn_InfSun, "Infinite Sun");
		addBtn(Btn_NoCd, "No Cooldown");
		addBtn(Btn_Coins, "Max Coins");
		addBtn(Btn_Skip, "Skip Level");
		addBtn(Btn_Unlock, "Unlock Modes");
		addBtn(Btn_Best, "Beat Everything");
		// Jump to the first level of any of the six original campaign areas.
		addBtn(Btn_SecretBase + 100, "Jump 1-1");
		addBtn(Btn_SecretBase + 101, "Jump 2-1");
		addBtn(Btn_SecretBase + 102, "Jump 3-1");
		addBtn(Btn_SecretBase + 103, "Jump 4-1");
		addBtn(Btn_SecretBase + 104, "Jump 5-1");
		addBtn(Btn_SecretBase + 105, "Jump 6-1");
		addBtn(Btn_Close, "Close");
		CalcSize(300, 20 + static_cast<int>(mButtons.size()) * 42);
		return;
	}

	if (mMode == BrutalPickMode::Spawner)
	{
		BuildSpawnEntries();
		for (int i = 0; i < kSecretSlotCount; ++i)
			addBtn(Btn_SecretEntryBase + i, "");
		addBtn(Btn_SecretPrev, "< Previous");
		addBtn(Btn_SecretPageLabel, "Page 1 / 1");
		addBtn(Btn_SecretNext, "Next >");
		addBtn(Btn_Close, "Close");
		addBtn(Btn_SpawnRow, std::format("Lane: {}", mSpawnRow));
		CalcSize(560, 370);
		RefreshSecretPage();
		return;
	}

	BuildSecretEntries();
	for (int i = 0; i < kSecretSlotCount; ++i)
		addBtn(Btn_SecretEntryBase + i, "");
	addBtn(Btn_SecretPrev, "< Previous");
	addBtn(Btn_SecretPageLabel, "Page 1 / 1");
	addBtn(Btn_SecretNext, "Next >");
	addBtn(Btn_Close, "Close");
	CalcSize(560, 370);
	RefreshSecretPage();
}

void BrutalPickDialog::BuildSecretEntries()
{
	mSecretEntries.clear();
	for (int i = 1; i <= BrutalSecretCount(); ++i)
	{
		const BrutalSecretInfo* info = BrutalSecretGetInfo(i);
		if (!info) continue;
		mSecretEntries.push_back({ true, i, std::format("{}. {}", i, info->title) });
	}

	// The regular Mini-Games/Survival pages omit all LIMBO entries. Puzzle
	// modes are separate from the Mini-Games page as well. Put every playable
	// omitted mode here so none depends on the five-click hidden page gesture.
	for (int i = 0; i < NUM_CHALLENGE_MODES; ++i)
	{
		const ChallengeDefinition& def = GetChallengeDefinition(i);
		if (def.mPage != ChallengePage::CHALLENGE_PAGE_LIMBO &&
			def.mPage != ChallengePage::CHALLENGE_PAGE_PUZZLE)
			continue;
		if (def.mChallengeMode == GameMode::GAMEMODE_UPSELL ||
			def.mChallengeMode == GameMode::GAMEMODE_INTRO)
			continue; // these are transitions, not playable levels

		std::string label(PvzpStringTranslate(def.mChallengeName));
		if (label.empty()) label = "Hidden challenge";
		if (def.mPage == ChallengePage::CHALLENGE_PAGE_PUZZLE)
			label = "Puzzle: " + label;
		else
			label = "Hidden: " + label;
		mSecretEntries.push_back({ false, static_cast<int>(def.mChallengeMode), std::move(label) });
	}
}

void BrutalPickDialog::BuildSpawnEntries()
{
	// Every spawnable zombie type in this build. Backup Dancer is intentionally absent:
	// it needs a Dancing Zombie leader, and the Dancing Zombie summons its own.
	static const std::pair<ZombieType, const char*> kZombies[] = {
		{ ZombieType::ZOMBIE_NORMAL, "Zombie" },
		{ ZombieType::ZOMBIE_FLAG, "Flag Zombie" },
		{ ZombieType::ZOMBIE_TRAFFIC_CONE, "Conehead" },
		{ ZombieType::ZOMBIE_POLEVAULTER, "Pole Vaulting" },
		{ ZombieType::ZOMBIE_PAIL, "Buckethead" },
		{ ZombieType::ZOMBIE_NEWSPAPER, "Newspaper" },
		{ ZombieType::ZOMBIE_DOOR, "Screen Door" },
		{ ZombieType::ZOMBIE_FOOTBALL, "Football" },
		{ ZombieType::ZOMBIE_DANCER, "Dancing Zombie" },
		{ ZombieType::ZOMBIE_DUCKY_TUBE, "Ducky Tube" },
		{ ZombieType::ZOMBIE_SNORKEL, "Snorkel" },
		{ ZombieType::ZOMBIE_ZAMBONI, "Zomboni" },
		{ ZombieType::ZOMBIE_BOBSLED, "Bobsled Team" },
		{ ZombieType::ZOMBIE_DOLPHIN_RIDER, "Dolphin Rider" },
		{ ZombieType::ZOMBIE_JACK_IN_THE_BOX, "Jack-in-the-Box" },
		{ ZombieType::ZOMBIE_BALLOON, "Balloon" },
		{ ZombieType::ZOMBIE_DIGGER, "Digger" },
		{ ZombieType::ZOMBIE_POGO, "Pogo" },
		{ ZombieType::ZOMBIE_YETI, "Zombie Yeti" },
		{ ZombieType::ZOMBIE_BUNGEE, "Bungee" },
		{ ZombieType::ZOMBIE_LADDER, "Ladder" },
		{ ZombieType::ZOMBIE_CATAPULT, "Catapult" },
		{ ZombieType::ZOMBIE_GARGANTUAR, "Gargantuar" },
		{ ZombieType::ZOMBIE_IMP, "Imp" },
		{ ZombieType::ZOMBIE_BOSS, "Dr. Zomboss" },
		{ ZombieType::ZOMBIE_PEA_HEAD, "Peashooter Zombie" },
		{ ZombieType::ZOMBIE_WALLNUT_HEAD, "Wall-nut Zombie" },
		{ ZombieType::ZOMBIE_JALAPENO_HEAD, "Jalapeno Zombie" },
		{ ZombieType::ZOMBIE_GATLING_HEAD, "Gatling Pea Zombie" },
		{ ZombieType::ZOMBIE_SQUASH_HEAD, "Squash Zombie" },
		{ ZombieType::ZOMBIE_TALLNUT_HEAD, "Tall-nut Zombie" },
		{ ZombieType::ZOMBIE_REDEYE_GARGANTUAR, "Giga-gargantuar" },
	};
	mSecretEntries.clear();
	for (const auto& z : kZombies)
		mSecretEntries.push_back({ false, static_cast<int>(z.first), z.second });
}

void BrutalPickDialog::SpawnZombie(int zombieType)
{
	Board* board = mApp->mBoard;
	// The level may have ended while the panel was open; never touch a stale board.
	if (!board || mApp->mGameScene != GameScenes::SCENE_PLAYING || !mApp->IsAdminProfile())
	{
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	}
	if (zombieType <= ZombieType::ZOMBIE_INVALID || zombieType >= ZombieType::NUM_ZOMBIE_TYPES ||
		zombieType == ZombieType::ZOMBIE_BACKUP_DANCER)
		return;

	// Only one Dr. Zomboss at a time: a second boss shares the same global boss state.
	if (zombieType == ZombieType::ZOMBIE_BOSS)
	{
		for (Zombie* aZombie : board->mZombies)
			if (!aZombie->mDead && aZombie->mZombieType == ZombieType::ZOMBIE_BOSS)
				return;
	}

	const int maxRows = (board->StageHasPool() || board->StageHas6Rows()) ? 6 : 5;
	const int row = std::clamp(mSpawnRow, 1, maxRows) - 1;
	Zombie* spawned = board->AddZombieInRow(static_cast<ZombieType>(zombieType), row, 0);
	if (spawned && mApp->mPlayerInfo)
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
}

void BrutalPickDialog::RefreshSecretPage()
{
	if ((mMode != BrutalPickMode::Secrets && mMode != BrutalPickMode::Spawner) || mButtons.size() < 16)
		return;
	const int pageCount = std::max(1, (static_cast<int>(mSecretEntries.size()) + kSecretEntriesPerPage - 1) / kSecretEntriesPerPage);
	mSecretPage = std::clamp(mSecretPage, 0, pageCount - 1);
	const int first = mSecretPage * kSecretEntriesPerPage;
	for (int i = 0; i < kSecretSlotCount; ++i)
	{
		const int entryIndex = first + i;
		LawnStoneButton* button = mButtons[i].get();
		if (entryIndex < static_cast<int>(mSecretEntries.size()))
		{
			button->SetLabel(mSecretEntries[entryIndex].label);
			button->mVisible = true;
			button->SetDisabled(false);
		}
		else
		{
			button->mVisible = false;
			button->SetDisabled(true);
		}
	}
	mButtons[kSecretPrevIndex]->SetDisabled(mSecretPage == 0);
	mButtons[kSecretPageIndex]->SetLabel(std::format("Page {} / {}", mSecretPage + 1, pageCount));
	mButtons[kSecretPageIndex]->SetDisabled(true);
	mButtons[kSecretNextIndex]->SetDisabled(mSecretPage + 1 >= pageCount);
}

BrutalPickDialog::~BrutalPickDialog() = default;

void BrutalPickDialog::AddedToManager(Sexy::WidgetManager* theWidgetManager)
{
	LawnDialog::AddedToManager(theWidgetManager);
	for (auto& b : mButtons)
		AddWidget(b.get());
}

void BrutalPickDialog::RemovedFromManager(Sexy::WidgetManager* theWidgetManager)
{
	for (auto& b : mButtons)
		RemoveWidget(b.get());
	LawnDialog::RemovedFromManager(theWidgetManager);
}

void BrutalPickDialog::Resize(int theX, int theY, int theWidth, int theHeight)
{
	LawnDialog::Resize(theX, theY, theWidth, theHeight);
	if (mMode == BrutalPickMode::SaveStates && mButtons.size() == 7)
	{
		const int top = 48;
		const int buttonHeight = 36;
		const int gapY = 8;
		const int colWidth = (mWidth - 50) / 2;
		for (int slot = 0; slot < 3; ++slot)
		{
			const int y = top + slot * (buttonHeight + gapY);
			mButtons[slot * 2]->Resize(20, y, colWidth, buttonHeight);
			mButtons[slot * 2 + 1]->Resize(30 + colWidth, y, colWidth, buttonHeight);
		}
		mButtons[6]->Resize(20, mHeight - 48, mWidth - 40, 32);
		return;
	}

	if ((mMode == BrutalPickMode::Secrets || mMode == BrutalPickMode::Spawner) && mButtons.size() >= 16)
	{
		const int top = 44;
		const int buttonHeight = 30;
		const int gapY = 6;
		const int colWidth = (mWidth - 50) / 2;
		for (int i = 0; i < kSecretSlotCount; ++i)
		{
			const int col = i % 2;
			const int row = i / 2;
			mButtons[i]->Resize(20 + col * (colWidth + 10), top + row * (buttonHeight + gapY), colWidth, buttonHeight);
		}
		const int navY = mHeight - 91;
		mButtons[kSecretPrevIndex]->Resize(20, navY, 145, 30);
		mButtons[kSecretPageIndex]->Resize(170, navY, 180, 30);
		mButtons[kSecretNextIndex]->Resize(375, navY, mWidth - 395, 30);
		if (mMode == BrutalPickMode::Spawner && mButtons.size() >= 17)
		{
			const int half = (mWidth - 50) / 2;
			mButtons[kSecretCloseIndex]->Resize(20, mHeight - 48, half, 32);
			mButtons[16]->Resize(30 + half, mHeight - 48, half, 32);
		}
		else
		{
			mButtons[kSecretCloseIndex]->Resize(20, mHeight - 48, mWidth - 40, 32);
		}
		return;
	}

	const int top = 48;
	const int buttonHeight = 34;
	const int gap = 6;
	int y = top;
	for (auto& button : mButtons)
	{
		button->Resize(20, y, mWidth - 40, buttonHeight);
		y += buttonHeight + gap;
	}
}

void BrutalPickDialog::LaunchBrutalSecret(int secretId)
{
	const BrutalSecretInfo* info = BrutalSecretGetInfo(secretId);
	if (!info || !mApp->mPlayerInfo) return;

	mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
	mApp->mBrutalSecretId = secretId;
	mApp->mPlayerInfo->mHasUsedCheatKeys = 1;

	if (info->challengeMode != GameMode::NUM_GAME_MODES)
	{
		// Minigame-based secret: start it through the same path the hidden modes use,
		// so the minigame's own board/state setup runs. Never routed through the
		// adventure restart, which would load adventure state for a minigame.
		mApp->mBrutalCheatJump = false;
		mApp->WriteCurrentUserConfig();
		mApp->PreNewGame(info->challengeMode, false);
		return;
	}

	mApp->mBrutalCheatJump = true;
	mApp->mPlayerInfo->mFinishedAdventure = 0;
	const int level = std::clamp(info->startLevel, 1, FINAL_LEVEL);
	mApp->mPlayerInfo->SetLevel(level);
	mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
	mApp->WriteCurrentUserConfig();
	mApp->BrutalSafeRestartAdventure();
}

void BrutalPickDialog::LaunchHiddenMode(GameMode mode)
{
	mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
	mApp->mBrutalSecretId = BRUTAL_SECRET_NONE;
	mApp->mBrutalCheatJump = false;
	// These are genuine game modes. Start them through the same normal path as
	// their regular selector buttons so their intro, seed chooser, and records work.
	const bool useSeedChooser = mode != GameMode::GAMEMODE_CHALLENGE_ZEN_GARDEN &&
		mode != GameMode::GAMEMODE_TREE_OF_WISDOM;
	mApp->PreNewGame(mode, useSeedChooser);
}

void BrutalPickDialog::RunSaveState(bool loadState, int slot)
{
	if (slot < 1 || slot > 3)
		return;

	if (!mApp->mBoard || mApp->mGameScene != GameScenes::SCENE_PLAYING)
	{
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Save State",
			"Enter a running level before saving or loading a state.",
			"[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
		return;
	}

	const std::string fileName = Sexy::GetAppDataPath(
		std::format("userdata/brutal_state_{}.v4", slot));
	bool ok = false;
	if (loadState)
		ok = mApp->mBoard->LoadGame(fileName);
	else
	{
		Sexy::MkDir(Sexy::GetAppDataPath("userdata"));
		ok = LawnSaveGame(mApp->mBoard, fileName);
	}

	mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
	const std::string message = ok
		? std::format("{} slot {}.", loadState ? "Loaded" : "Saved", slot)
		: loadState ? std::format("Slot {} is empty or incompatible.", slot)
				 : std::format("Could not write slot {}.", slot);
	mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Save State", message,
		"[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
}

void BrutalPickDialog::ButtonDepress(int theId)
{
	if (theId == Btn_Close)
	{
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	}

	if (mMode == BrutalPickMode::SaveStates)
	{
		if (theId >= Btn_SaveSlotBase && theId < Btn_SaveSlotBase + 3)
			RunSaveState(false, theId - Btn_SaveSlotBase + 1);
		else if (theId >= Btn_LoadSlotBase && theId < Btn_LoadSlotBase + 3)
			RunSaveState(true, theId - Btn_LoadSlotBase + 1);
		return;
	}

	if (mMode == BrutalPickMode::Admin)
	{
		switch (theId)
		{
		case Btn_AdminCheats:
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->DoBrutalCheatMenu();
			return;
		case Btn_AdminSecrets:
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->DoBrutalSecretsDialog();
			return;
		case Btn_AdminUnlock:
			if (mApp->mPlayerInfo)
			{
				mApp->mPlayerInfo->mHasUnlockedMinigames = 1;
				mApp->mPlayerInfo->mHasUnlockedPuzzleMode = 1;
				mApp->mPlayerInfo->mHasUnlockedSurvivalMode = 1;
				mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
				mApp->WriteCurrentUserConfig();
			}
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->DoDialog(Dialogs::DIALOG_INFO, true, "Admin Panel",
				"Mini-Games, Puzzle, and Survival modes have been unlocked for this profile.",
				"[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return;
		case Btn_AdminBeatEverything:
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->BrutalBeatEverything();
			return;
		default:
			return;
		}
	}

	if (mMode == BrutalPickMode::Spawner)
	{
		if (theId == Btn_SecretPrev)
		{
			mSecretPage--;
			RefreshSecretPage();
		}
		else if (theId == Btn_SecretNext)
		{
			mSecretPage++;
			RefreshSecretPage();
		}
		else if (theId == Btn_SpawnRow)
		{
			const int maxRows = (mApp->mBoard && (mApp->mBoard->StageHasPool() || mApp->mBoard->StageHas6Rows())) ? 6 : 5;
			mSpawnRow = (mSpawnRow >= maxRows) ? 1 : mSpawnRow + 1;
			if (mButtons.size() >= 17)
				mButtons[16]->SetLabel(std::format("Lane: {}", mSpawnRow));
		}
		else if (theId >= Btn_SecretEntryBase && theId < Btn_SecretEntryBase + kSecretSlotCount)
		{
			const int idx = mSecretPage * kSecretEntriesPerPage + theId - Btn_SecretEntryBase;
			if (idx >= 0 && idx < static_cast<int>(mSecretEntries.size()))
				SpawnZombie(mSecretEntries[idx].value);
		}
		return;
	}

	if (mMode == BrutalPickMode::Secrets)
	{
		if (theId == Btn_SecretPrev)
		{
			mSecretPage--;
			RefreshSecretPage();
			return;
		}
		if (theId == Btn_SecretNext)
		{
			mSecretPage++;
			RefreshSecretPage();
			return;
		}
		if (theId >= Btn_SecretEntryBase && theId < Btn_SecretEntryBase + kSecretSlotCount)
		{
			const int idx = mSecretPage * kSecretEntriesPerPage + theId - Btn_SecretEntryBase;
			if (idx < 0 || idx >= static_cast<int>(mSecretEntries.size())) return;
			const SecretEntry entry = mSecretEntries[idx];
			if (entry.isBrutalSecret)
				LaunchBrutalSecret(entry.value);
			else
				LaunchHiddenMode(static_cast<GameMode>(entry.value));
		}
		return;
	}

	switch (theId)
	{
	case Btn_InfSun:
		mApp->BrutalEnableInGameCheats(true, false, false);
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	case Btn_NoCd:
		mApp->BrutalEnableInGameCheats(false, true, true);
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	case Btn_Coins:
		if (mApp->mPlayerInfo)
		{
			mApp->mPlayerInfo->AddCoins(99999);
			mApp->WriteCurrentUserConfig();
		}
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	case Btn_Skip:
	{
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		if (!mApp->mPlayerInfo) return;
		const int level = std::min(mApp->mPlayerInfo->GetLevel() + 1, FINAL_LEVEL);
		mApp->mPlayerInfo->SetLevel(level);
		mApp->mPlayerInfo->mFinishedAdventure = 0;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mBrutalCheatJump = true;
		mApp->WriteCurrentUserConfig();
		mApp->BrutalSafeRestartAdventure();
		return;
	}
	case Btn_Unlock:
		if (mApp->mPlayerInfo)
		{
			mApp->mPlayerInfo->mHasUnlockedMinigames = 1;
			mApp->mPlayerInfo->mHasUnlockedPuzzleMode = 1;
			mApp->mPlayerInfo->mHasUnlockedSurvivalMode = 1;
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			mApp->WriteCurrentUserConfig();
		}
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	case Btn_Best:
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		mApp->BrutalBeatEverything();
		return;
	default:
		break;
	}

	// Jump shortcuts are 1-1 through 6-1 only in original Brutal Mode.
	if (theId >= Btn_SecretBase + 100 && theId <= Btn_SecretBase + 105)
	{
		const int area = theId - (Btn_SecretBase + 100) + 1;
		const int level = (area - 1) * LEVELS_PER_AREA + 1;
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		if (!mApp->mPlayerInfo) return;
		mApp->mPlayerInfo->SetLevel(level);
		mApp->mPlayerInfo->mFinishedAdventure = 0;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mBrutalCheatJump = true;
		mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
		mApp->WriteCurrentUserConfig();
		mApp->BrutalSafeRestartAdventure();
	}
}
