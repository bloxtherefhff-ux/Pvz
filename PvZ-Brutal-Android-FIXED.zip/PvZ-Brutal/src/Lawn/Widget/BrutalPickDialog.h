#pragma once
#include "LawnDialog.h"
#include <memory>
#include <string>
#include <vector>
#include "../../ConstEnums.h"

class LawnApp;
class LawnStoneButton;

enum class BrutalPickMode
{
	Cheats,
	Secrets,
	SaveStates,
	Admin,
	Spawner
};

class BrutalPickDialog : public LawnDialog
{
public:
	enum
	{
		// button ids offset from dialog base
		Btn_Close = 1000,
		Btn_InfSun = 1001,
		Btn_NoCd = 1002,
		Btn_Coins = 1003,
		Btn_Skip = 1004,
		Btn_Unlock = 1005,
		Btn_Best = 1006,
		Btn_SecretBase = 1100, // + secret id 1..N; +100 for adventure area shortcuts
		Btn_SecretEntryBase = 2000,
		Btn_SecretPrev = 2020,
		Btn_SecretPageLabel = 2021,
		Btn_SecretNext = 2022,
		Btn_SpawnRow = 2030,
		Btn_SaveSlotBase = 3000, // + slot - 1
		Btn_LoadSlotBase = 3010, // + slot - 1
		Btn_AdminCheats = 4000,
		Btn_AdminSecrets = 4001,
		Btn_AdminUnlock = 4002,
		Btn_AdminBeatEverything = 4003
	};

	LawnApp* mApp;
	BrutalPickMode mMode;
	std::vector<std::unique_ptr<LawnStoneButton>> mButtons;
	struct SecretEntry
	{
		bool isBrutalSecret = false;
		int value = 0; // secret ID or GameMode
		std::string label;
	};
	std::vector<SecretEntry> mSecretEntries;
	int mSecretPage = 0;
	int mSpawnRow = 3; // 1-based lane for the admin zombie spawner
	void BuildSpawnEntries();
	void SpawnZombie(int zombieType);
	void BuildSecretEntries();
	void RefreshSecretPage();
	void LaunchBrutalSecret(int secretId);
	void LaunchHiddenMode(GameMode mode);
	void RunSaveState(bool loadState, int slot);

	BrutalPickDialog(LawnApp* theApp, BrutalPickMode mode);
	~BrutalPickDialog() override;

	void AddedToManager(Sexy::WidgetManager* theWidgetManager) override;
	void RemovedFromManager(Sexy::WidgetManager* theWidgetManager) override;
	void Resize(int theX, int theY, int theWidth, int theHeight) override;
	void ButtonDepress(int theId) override;
};
