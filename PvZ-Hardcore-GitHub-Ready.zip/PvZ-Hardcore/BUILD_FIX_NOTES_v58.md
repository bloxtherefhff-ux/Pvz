# v58 build/cheat fix notes

## Changes
- Key `8` now toggles free planting, infinite sun, and no seed-packet cooldown together; it is reversible and works without developer debug keys.
- All three cheat flags reset when a new Board is constructed, so they do not leak into the next level.
- Removed the old `iboW_S` command that jumped to levels and unlocked progression.
- Added admin-only zombie spawning: name the profile `admin` or `Admin`, then type `spawn0` through `spawn32` during a live level. The enum order is listed in `src/ConstEnums.h`; 0 is a normal zombie, 2 is a conehead, 7 is a football zombie, and 32 is a red-eye Gargantuar. The number maps to the `ZombieType` enum in `src/ConstEnums.h`.

## Important build-log mismatch
The reported GitHub error says `src/Lawn/Challenge.h:386`, but `src/Lawn/Challenge.h` in the supplied ZIP is only 265 lines and contains no array initializer near line 386. Therefore that exact compiler error comes from a different/newer `Challenge.h` currently in the GitHub repository than the one in this ZIP. This ZIP cannot truthfully claim that the remote file was fixed. Replace the repository's `src/Lawn/Challenge.h` with the matching file from this ZIP, or provide the exact failing file revision if that header contains required changes.

## Validation limits
ZIP integrity and targeted source assertions are checked. This environment does not have the Android NDK/SDL/vcpkg dependency set for a complete APK build; GitHub Actions must confirm compilation and runtime behavior.
