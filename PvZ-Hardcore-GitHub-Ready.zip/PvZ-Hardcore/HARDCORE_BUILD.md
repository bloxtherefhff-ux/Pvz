# PvZ Portable — Hardcore All-In-One Build

Integrated gameplay changes:
- normal sun pickup: 50
- small sun: 25
- large sun: 100
- plant economy rebalance: higher costs and cooldowns across the plant roster
- targeted buffs/nerfs for key plants (Sunflower, Peashooter, Repeaters, Wall-nut family, explosives, mushrooms, Gatling Pea, Cob Cannon, etc.)
- stronger durability for key defensive plants
- every selectable zombie type can spawn as a hardcore variant
- hardcore zombie chance starts at 50% and rises with wave progression
- type-specific zombie health/speed scaling
- periodic speed surges for fast variants
- limited healing while chewing for selected variants
- periodic damage resistance for heavy variants
- original zombie AI/types are preserved for compatibility

The source tree does not include EA/PopCap game assets. Import your own `main.pak` and `properties/` when running the resulting PvZ-Portable build.


## Zombie ability chance
Every spawned zombie has a 50% chance to become a Hardcore variant. Hardcore variants keep their original zombie type and AI, receive a type-specific color, and execute a unique ability for that zombie class. The boss also has its own pulse ability.

v12 keeps the 4x zombie quantity-per-wave behavior and adds type-specific hardcore zombie abilities.
