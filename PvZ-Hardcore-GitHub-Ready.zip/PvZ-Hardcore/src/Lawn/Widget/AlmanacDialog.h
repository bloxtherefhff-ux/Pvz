/*
 * Copyright (C) 2026 Zhou Qiankang <wszqkzqk@qq.com>
 *
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * This file is part of PvZ-Portable.
 *
 * PvZ-Portable is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PvZ-Portable is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with PvZ-Portable. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef __ALMANACDIALOG_H__
#define __ALMANACDIALOG_H__

#include "LawnDialog.h"
#include <array>
#include <memory>

constexpr const int NUM_ALMANAC_SEEDS = 49;
constexpr const int NUM_ALMANAC_ZOMBIES = 26;

constexpr const float			ALMANAC_PLANT_POSITION_X		= 578.0f;
constexpr const float			ALMANAC_PLANT_POSITION_Y		= 140.0f;
constexpr const float			ALMANAC_ZOMBIE_POSITION_X		= 559.0f;
constexpr const float			ALMANAC_ZOMBIE_POSITION_Y		= 175.0f;
constexpr const int				ALMANAC_INDEXPLANT_POSITION_X	= 167;
constexpr const int				ALMANAC_INDEXPLANT_POSITION_Y	= 255;
constexpr const float			ALMANAC_INDEXZOMBIE_POSITION_X	= 535.0f;
constexpr const float			ALMANAC_INDEXZOMBIE_POSITION_Y	= 215.0f;

class Plant;
class Zombie;
class LawnApp;
class GameButton;
class Reanimation;
class AlmanacDialog : public LawnDialog
{
private:
	enum
	{
		ALMANAC_BUTTON_CLOSE = 0,
		ALMANAC_BUTTON_PLANT = 1,
		ALMANAC_BUTTON_ZOMBIE = 2,
		ALMANAC_BUTTON_INDEX = 3
	};

public:
	LawnApp*					mApp;
	std::unique_ptr<GameButton>	mCloseButton;
	std::unique_ptr<GameButton>	mIndexButton;
	std::unique_ptr<GameButton>	mPlantButton;
	std::unique_ptr<GameButton>	mZombieButton;
	AlmanacPage					mOpenPage;
	Reanimation*				mReanim[4];
	SeedType					mSelectedSeed;
	ZombieType					mSelectedZombie;
	std::unique_ptr<Plant>		mPlant;
	std::unique_ptr<Zombie>		mZombie;
	std::array<std::unique_ptr<Zombie>, 400>	mZombiePerfTest;

public:
	AlmanacDialog(LawnApp* theApp);
	~AlmanacDialog() override;

	void						ClearPlantsAndZombies();
	void						RemovedFromManager(WidgetManager* theWidgetManager) override;
	void						SetupPlant();
	void						SetupZombie();
	void						SetPage(AlmanacPage thePage);
	void						Update() override;
	void						DrawIndex(Graphics* g);
	void						DrawPlants(Graphics* g);
	void						DrawZombies(Graphics* g);
	void						Draw(Graphics* g) override;
	void						GetSeedPosition(SeedType theSeedType, int& x, int& y);
	SeedType					SeedHitTest(int x, int y);
	bool				ZombieHasSilhouette(ZombieType theZombieType);
	bool						ZombieIsShown(ZombieType theZombieType);
	bool						ZombieHasDescription(ZombieType theZombieType);
	void						GetZombiePosition(ZombieType theZombieType, int& x, int& y);
	ZombieType					ZombieHitTest(int x, int y);
	void						MouseUp(int x, int y, int theClickCount) override;
	void						MouseDown(int x, int y, int theClickCount) override;
	void						KeyDown(KeyCode theKey) override;
//	virtual void				KeyChar(char theChar);

	static ZombieType			GetZombieType(int theIndex);
	void				ShowPlant(SeedType theSeedType);
	void				ShowZombie(ZombieType theZombieType);
};
extern bool gZombieDefeated[NUM_ZOMBIE_TYPES];

void					AlmanacInitForPlayer();
void					AlmanacPlayerDefeatedZombie(ZombieType theZombieType);

#endif
