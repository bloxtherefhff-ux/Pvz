# Hardcore rework manifest

- 53 plant definitions: explicit hardcore seed-cost/recharge balance plus individual health values.
- Hardcore zombie chance: 15% at early waves, scaling to 40%.
- Every regular zombie class in the wave roster receives its own periodic hardcore ability and its own tint.


## v8 tap ability rebalance
- Plant tap abilities cost **50 sun**.
- Removed the universal 5,000-damage row shockwave and the generic fallback attack.
- Each plant has a separate, plant-specific tap effect.
- Sunflower tap: grants **150 sun and sacrifices the Sunflower**.
- Peashooter tap is limited to a single bonus pea.
- Tap cooldown is **75 frames (~1.25 seconds)** for balance.
- Zombie spawning remains **4x the number of zombies** through the hardcore countdown multiplier.

- v9 tap changes: Sunflower ability is free and grants 150 sun before sacrificing itself; Peashooter fires a 10-pea burst with a higher cost and longer cooldown; ability prices scale by power instead of using one universal cost.
