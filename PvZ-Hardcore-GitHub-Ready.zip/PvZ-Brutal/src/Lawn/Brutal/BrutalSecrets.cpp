#include "BrutalSecrets.h"
#include "../Board.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include "../../ConstEnums.h"
#include <cctype>
#include <cstdlib>
#include <algorithm>

static const BrutalSecretInfo kSecrets[] = {
	{ BRUTAL_SECRET_STORM,    "storm",    "Sunshine Storm",     "No sky sun; producers weaker; big-sun pressure", 5 },
	{ BRUTAL_SECRET_CLOSE,    "close",    "No Swimming",        "Aquatic plants disabled (pool levels)", 21 },
	{ BRUTAL_SECRET_LONG,     "long",     "War of Attrition",   "Extra wave pressure; denser spawns", 15 },
	{ BRUTAL_SECRET_VISUAL,   "visual",   "Visual Distortion",  "Heavy fog for hard readability", 8 },
	{ BRUTAL_SECRET_ESCAPE,   "escape",   "Air Raid",           "Plants shoved back on contact", 25 },
	{ BRUTAL_SECRET_FRIGHT,   "fright",   "Night Fright",       "Graves enabled; rising pressure", 11 },
	{ BRUTAL_SECRET_SINGLE,   "single",   "Lone Gun",           "Fewer seed slots (3)", 12 },
	{ BRUTAL_SECRET_SLOT,     "slot",     "Slot Crisis",        "One chosen style bank: 6 peas", 18 },
	{ BRUTAL_SECRET_OVERCAST, "overcast", "Overcast",           "No sky sun", 6 },
	{ BRUTAL_SECRET_CERTAIN,  "certain",  "Heisenberg Zombies","Zombie speeds randomized hard", 22 },
	{ BRUTAL_SECRET_GUARDIAN, "guardian", "Invisible Guardians","Maximum fog", 14 },
	{ BRUTAL_SECRET_GIANT,    "giant",    "Giant Trouble",      "Zombies 2x size, 4x HP, half speed", 20 },
	{ BRUTAL_SECRET_REPRISAL, "reprisal", "Dr. Zomboss Revenge","Start with 300 sun; high pressure", 35 },
};

const BrutalSecretInfo* BrutalSecretGetInfo(int id)
{
	if (id <= 0 || id >= BRUTAL_SECRET_COUNT) return nullptr;
	return &kSecrets[id - 1];
}

int BrutalSecretCount()
{
	return (int)(sizeof(kSecrets) / sizeof(kSecrets[0]));
}

int BrutalParseNameLevelCode(const std::string& name)
{
	std::string s;
	for (char c : name)
	{
		if (c == ' ' || c == '-' || c == '_') continue;
		if (!std::isdigit(static_cast<unsigned char>(c)))
			return -1;
		s.push_back(c);
	}
	if (s.size() < 2 || s.size() > 3)
		return -1;
	int area = 0, sub = 0;
	if (s.size() == 2)
	{
		area = s[0] - '0';
		sub = s[1] - '0';
	}
	else
	{
		area = s[0] - '0';
		sub = (s[1] - '0') * 10 + (s[2] - '0');
	}
	if (area < 1 || area > 5) return -1;
	if (sub < 1 || sub > 10) return -1;
	return (area - 1) * 10 + sub;
}

void BrutalSecretApplyToBoard(Board* board)
{
	if (!board || !board->mApp) return;
	int id = board->mApp->mBrutalSecretId;
	if (id <= 0) return;

	// Fog-heavy secrets
	if (id == BRUTAL_SECRET_VISUAL || id == BRUTAL_SECRET_GUARDIAN)
	{
		for (int x = 0; x < MAX_GRID_SIZE_X; x++)
			for (int y = 0; y < MAX_GRID_SIZE_Y + 1; y++)
				board->mGridCelFog[x][y] = (id == BRUTAL_SECRET_GUARDIAN) ? 1000 : 600;
		board->mFogOffset = 200.0f;
		board->mFogBlownCountDown = 0;
	}

	if (id == BRUTAL_SECRET_FRIGHT)
	{
		board->mEnableGraveStones = true;
	}

	if (id == BRUTAL_SECRET_REPRISAL)
	{
		board->mSunMoney = std::max(board->mSunMoney, 300);
	}

	if (id == BRUTAL_SECRET_SINGLE && board->mSeedBank)
	{
		board->mSeedBank->mNumPackets = 3;
		board->mSeedBank->UpdateWidth();
	}

	if (id == BRUTAL_SECRET_SLOT && board->mSeedBank)
	{
		board->mSeedBank->mNumPackets = 6;
		board->mSeedBank->UpdateWidth();
		for (int i = 0; i < 6; i++)
		{
			board->mSeedBank->mSeedPackets[i].SetPacketType(SeedType::SEED_PEASHOOTER);
			board->mSeedBank->mSeedPackets[i].mX = board->GetSeedPacketPositionX(i);
		}
	}

	if (id == BRUTAL_SECRET_LONG)
	{
		// denser early pressure
		board->mNumSunsFallen = 5;
	}
}
