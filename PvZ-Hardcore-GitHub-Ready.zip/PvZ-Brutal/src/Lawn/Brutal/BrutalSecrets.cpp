#include "BrutalSecrets.h"
#include "../Board.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include "../../ConstEnums.h"
#include "../../GameConstants.h"
#include <cctype>
#include <cstdlib>
#include <algorithm>

// challengeMode = real minigame when possible (hidden "secret level" like original mini-games)
static const BrutalSecretInfo kSecrets[] = {
	{ BRUTAL_SECRET_STORM,    "storm",    "Sunshine Storm",      "Stormy Night minigame", 5,  GameMode::GAMEMODE_CHALLENGE_STORMY_NIGHT },
	{ BRUTAL_SECRET_CLOSE,    "close",    "No Swimming",         "Pool 3-1; no aquatic plants", 21, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_LONG,     "long",     "War of Attrition",    "More waves + denser packs", 15, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_VISUAL,   "visual",   "Visual Distortion",   "Invisighoul minigame", 8,  GameMode::GAMEMODE_CHALLENGE_INVISIGHOUL },
	{ BRUTAL_SECRET_ESCAPE,   "escape",   "Air Raid",            "Air Raid minigame", 25, GameMode::GAMEMODE_CHALLENGE_AIR_RAID },
	{ BRUTAL_SECRET_FRIGHT,   "fright",   "Night Fright",        "Grave Danger minigame", 11, GameMode::GAMEMODE_CHALLENGE_GRAVE_DANGER },
	{ BRUTAL_SECRET_SINGLE,   "single",   "Lone Gun",            "Only 3 seed slots", 12, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_SLOT,     "slot",     "Slot Crisis",         "Slot Machine minigame", 18, GameMode::GAMEMODE_CHALLENGE_SLOT_MACHINE },
	{ BRUTAL_SECRET_OVERCAST, "overcast", "Overcast",            "No sky sun at all", 6,  GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_CERTAIN,  "certain",  "Heisenberg Zombies",  "Wild speed on every zombie", 22, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_GUARDIAN, "guardian", "Invisible Guardians", "Invisighoul + heavy fog", 14, GameMode::GAMEMODE_CHALLENGE_INVISIGHOUL },
	{ BRUTAL_SECRET_GIANT,    "giant",    "Giant Trouble",       "Huge slow tanks", 20, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_REPRISAL, "reprisal", "Dr. Zomboss Revenge", "300 sun; brutal pressure", 35, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_BEGHOULED, "beghouled", "Beghouled", "Match plants to clear the board", 1, GameMode::GAMEMODE_CHALLENGE_BEGHOULED },
	{ BRUTAL_SECRET_BEGHOULED_TWIST, "beghouled twist", "Beghouled Twist", "Match plants with the twisted board rules", 1, GameMode::GAMEMODE_CHALLENGE_BEGHOULED_TWIST },
};

const BrutalSecretInfo* BrutalSecretGetInfo(int id)
{
	if (id <= 0 || id >= BRUTAL_SECRET_COUNT) return nullptr;
	return &kSecrets[id - 1];
}

int BrutalSecretCount()
{
	return (int)(sizeof(kSecrets) / sizeof(kSecrets[0]));
}

int BrutalParseNameLevelCode(const std::string& name)
{
	std::string s;
	for (char c : name)
	{
		if (c == ' ' || c == '-' || c == '_') continue;
		if (!std::isdigit(static_cast<unsigned char>(c)))
			return -1;
		s.push_back(c);
	}
	if (s.size() < 2 || s.size() > 3) return -1;
	int area = 0, sub = 0;
	if (s.size() == 2)
	{
		area = s[0] - '0';
		sub = s[1] - '0';
	}
	else
	{
		area = (s[0] - '0') * 10 + (s[1] - '0');
		sub = s[2] - '0';
		if (area > 5) { area = s[0] - '0'; sub = (s[1] - '0') * 10 + (s[2] - '0'); }
	}
	if (area < 1 || area > 5 || sub < 1 || sub > 10) return -1;
	return (area - 1) * 10 + sub;
}

void BrutalSecretApplyToBoard(Board* board)
{
	if (!board || !board->mApp) return;
	const int id = board->mApp->mBrutalSecretId;
	if (id <= 0) return;

	const BrutalSecretInfo* info = BrutalSecretGetInfo(id);
	if (info)
	{
		// Visible banner so the secret is obviously active
		board->DisplayAdvice(
			std::string("[SECRET] ") + info->title,
			MessageStyle::MESSAGE_STYLE_HINT_LONG,
			AdviceType::ADVICE_NONE);
	}

	if (id == BRUTAL_SECRET_VISUAL || id == BRUTAL_SECRET_GUARDIAN)
	{
		for (int x = 0; x < MAX_GRID_SIZE_X; x++)
			for (int y = 0; y < MAX_GRID_SIZE_Y + 1; y++)
				board->mGridCelFog[x][y] = (id == BRUTAL_SECRET_GUARDIAN) ? 1000 : 500;
		board->mFogBlownCountDown = 3000;
	}

	if (id == BRUTAL_SECRET_FRIGHT || id == BRUTAL_SECRET_CLOSE)
	{
		board->mEnableGraveStones = true;
	}

	if (id == BRUTAL_SECRET_REPRISAL)
	{
		board->mSunMoney = std::max(board->mSunMoney, 300);
	}

	if (id == BRUTAL_SECRET_LONG)
	{
		board->mNumSunsFallen = 8;
		// denser: more waves later handled by BrutalMode getters when secret active
	}

	if (id == BRUTAL_SECRET_OVERCAST || id == BRUTAL_SECRET_STORM)
	{
		board->mNumSunsFallen = 99;
		board->mSunCountDown = 999999; // effectively no sky sun
	}

	if (id == BRUTAL_SECRET_CLOSE)
	{
		// Force pool background path via level 21 if still adventure
		if (board->mApp->IsAdventureMode() && board->mLevel < 21)
		{
			board->mLevel = 21;
			if (board->mApp->mPlayerInfo)
				board->mApp->mPlayerInfo->SetLevel(21);
		}
	}

	BrutalSecretApplyLate(board);
}

void BrutalSecretApplyLate(Board* board)
{
	if (!board || !board->mApp || !board->mSeedBank) return;
	const int id = board->mApp->mBrutalSecretId;
	if (id <= 0) return;

	if (id == BRUTAL_SECRET_SINGLE)
	{
		board->mSeedBank->mNumPackets = std::min(3, SEEDBANK_MAX);
		board->mSeedBank->UpdateWidth();
		for (int i = 0; i < board->mSeedBank->mNumPackets; i++)
			board->mSeedBank->mSeedPackets[i].mX = board->GetSeedPacketPositionX(i);
	}
	if (id == BRUTAL_SECRET_SLOT && board->mApp->mGameMode == GameMode::GAMEMODE_ADVENTURE)
	{
		int n = std::min(6, SEEDBANK_MAX);
		board->mSeedBank->mNumPackets = n;
		board->mSeedBank->UpdateWidth();
		for (int i = 0; i < n; i++)
		{
			board->mSeedBank->mSeedPackets[i].SetPacketType(SeedType::SEED_PEASHOOTER);
			board->mSeedBank->mSeedPackets[i].mX = board->GetSeedPacketPositionX(i);
		}
	}
}
