#include "BrutalSecrets.h"
#include "../Board.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include "../../ConstEnums.h"
#include "../../GameConstants.h"
#include <cctype>
#include <cstdlib>
#include <algorithm>

// challengeMode = real minigame when possible (hidden "secret level" like original mini-games)
static const BrutalSecretInfo kSecrets[] = {
	{ BRUTAL_SECRET_STORM,    "storm",    "Sunshine Storm",      "Stormy Night minigame", 5,  GameMode::GAMEMODE_CHALLENGE_STORMY_NIGHT },
	{ BRUTAL_SECRET_CLOSE,    "close",    "No Swimming",         "Pool 3-1; no aquatic plants", 21, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_LONG,     "long",     "War of Attrition",    "More waves + denser packs", 15, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_VISUAL,   "visual",   "Visual Distortion",   "Invisighoul minigame", 8,  GameMode::GAMEMODE_CHALLENGE_INVISIGHOUL },
	{ BRUTAL_SECRET_ESCAPE,   "escape",   "Air Raid",            "Air Raid minigame", 25, GameMode::GAMEMODE_CHALLENGE_AIR_RAID },
	{ BRUTAL_SECRET_FRIGHT,   "fright",   "Night Fright",        "Grave Danger minigame", 11, GameMode::GAMEMODE_CHALLENGE_GRAVE_DANGER },
	{ BRUTAL_SECRET_SINGLE,   "single",   "Lone Gun",            "Only 3 seed slots", 12, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_SLOT,     "slot",     "Slot Crisis",         "Slot Machine minigame", 18, GameMode::GAMEMODE_CHALLENGE_SLOT_MACHINE },
	{ BRUTAL_SECRET_OVERCAST, "overcast", "Overcast",            "No sky sun at all", 6,  GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_CERTAIN,  "certain",  "Heisenberg Zombies",  "Wild speed on every zombie", 22, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_GUARDIAN, "guardian", "Invisible Guardians", "Invisighoul + heavy fog", 14, GameMode::GAMEMODE_CHALLENGE_INVISIGHOUL },
	{ BRUTAL_SECRET_GIANT,    "giant",    "Giant Trouble",       "Huge slow tanks", 20, GameMode::NUM_GAME_MODES },
	{ BRUTAL_SECRET_REPRISAL, "reprisal", "Dr. Zomboss Revenge", "300 sun; brutal pressure", 35, GameMode::NUM_GAME_MODES },
	{ static_cast<BrutalSecretId>(14), "mini14", "War and Peas", "Built-in game mode: War and Peas", 1, GameMode::GAMEMODE_CHALLENGE_WAR_AND_PEAS },
	{ static_cast<BrutalSecretId>(15), "mini15", "Wall-nut Bowling", "Built-in game mode: Wall-nut Bowling", 1, GameMode::GAMEMODE_CHALLENGE_WALLNUT_BOWLING },
	{ static_cast<BrutalSecretId>(16), "mini16", "Slot Machine", "Built-in game mode: Slot Machine", 1, GameMode::GAMEMODE_CHALLENGE_SLOT_MACHINE },
	{ static_cast<BrutalSecretId>(17), "mini17", "Raining Seeds", "Built-in game mode: Raining Seeds", 1, GameMode::GAMEMODE_CHALLENGE_RAINING_SEEDS },
	{ static_cast<BrutalSecretId>(18), "mini18", "Bingo / Beghouled", "Built-in game mode: Bingo / Beghouled", 1, GameMode::GAMEMODE_CHALLENGE_BEGHOULED },
	{ static_cast<BrutalSecretId>(19), "mini19", "Invisighoul", "Built-in game mode: Invisighoul", 1, GameMode::GAMEMODE_CHALLENGE_INVISIGHOUL },
	{ static_cast<BrutalSecretId>(20), "mini20", "Seeing Stars", "Built-in game mode: Seeing Stars", 1, GameMode::GAMEMODE_CHALLENGE_SEEING_STARS },
	{ static_cast<BrutalSecretId>(21), "mini21", "Zombiquarium", "Built-in game mode: Zombiquarium", 1, GameMode::GAMEMODE_CHALLENGE_ZOMBIQUARIUM },
	{ static_cast<BrutalSecretId>(22), "mini22", "Beghouled Twist", "Built-in game mode: Beghouled Twist", 1, GameMode::GAMEMODE_CHALLENGE_BEGHOULED_TWIST },
	{ static_cast<BrutalSecretId>(23), "mini23", "Little Trouble", "Built-in game mode: Little Trouble", 1, GameMode::GAMEMODE_CHALLENGE_LITTLE_TROUBLE },
	{ static_cast<BrutalSecretId>(24), "mini24", "Portal Combat", "Built-in game mode: Portal Combat", 1, GameMode::GAMEMODE_CHALLENGE_PORTAL_COMBAT },
	{ static_cast<BrutalSecretId>(25), "mini25", "Column", "Built-in game mode: Column", 1, GameMode::GAMEMODE_CHALLENGE_COLUMN },
	{ static_cast<BrutalSecretId>(26), "mini26", "Bobsled Bonanza", "Built-in game mode: Bobsled Bonanza", 1, GameMode::GAMEMODE_CHALLENGE_BOBSLED_BONANZA },
	{ static_cast<BrutalSecretId>(27), "mini27", "Speed", "Built-in game mode: Speed", 1, GameMode::GAMEMODE_CHALLENGE_SPEED },
	{ static_cast<BrutalSecretId>(28), "mini28", "Whack A Zombie", "Built-in game mode: Whack A Zombie", 1, GameMode::GAMEMODE_CHALLENGE_WHACK_A_ZOMBIE },
	{ static_cast<BrutalSecretId>(29), "mini29", "Last Stand", "Built-in game mode: Last Stand", 1, GameMode::GAMEMODE_CHALLENGE_LAST_STAND },
	{ static_cast<BrutalSecretId>(30), "mini30", "War and Peas 2", "Built-in game mode: War and Peas 2", 1, GameMode::GAMEMODE_CHALLENGE_WAR_AND_PEAS_2 },
	{ static_cast<BrutalSecretId>(31), "mini31", "Wall-nut Bowling 2", "Built-in game mode: Wall-nut Bowling 2", 1, GameMode::GAMEMODE_CHALLENGE_WALLNUT_BOWLING_2 },
	{ static_cast<BrutalSecretId>(32), "mini32", "Pogo Party", "Built-in game mode: Pogo Party", 1, GameMode::GAMEMODE_CHALLENGE_POGO_PARTY },
	{ static_cast<BrutalSecretId>(33), "mini33", "Final Boss", "Built-in game mode: Final Boss", 1, GameMode::GAMEMODE_CHALLENGE_FINAL_BOSS },
	{ static_cast<BrutalSecretId>(34), "mini34", "Art Challenge Wallnut", "Built-in game mode: Art Challenge Wallnut", 1, GameMode::GAMEMODE_CHALLENGE_ART_CHALLENGE_WALLNUT },
	{ static_cast<BrutalSecretId>(35), "mini35", "Sunny Day", "Built-in game mode: Sunny Day", 1, GameMode::GAMEMODE_CHALLENGE_SUNNY_DAY },
	{ static_cast<BrutalSecretId>(36), "mini36", "Resodded", "Built-in game mode: Resodded", 1, GameMode::GAMEMODE_CHALLENGE_RESODDED },
	{ static_cast<BrutalSecretId>(37), "mini37", "Big Time", "Built-in game mode: Big Time", 1, GameMode::GAMEMODE_CHALLENGE_BIG_TIME },
	{ static_cast<BrutalSecretId>(38), "mini38", "Art Challenge Sunflower", "Built-in game mode: Art Challenge Sunflower", 1, GameMode::GAMEMODE_CHALLENGE_ART_CHALLENGE_SUNFLOWER },
	{ static_cast<BrutalSecretId>(39), "mini39", "Air Raid", "Built-in game mode: Air Raid", 1, GameMode::GAMEMODE_CHALLENGE_AIR_RAID },
	{ static_cast<BrutalSecretId>(40), "mini40", "Ice", "Built-in game mode: Ice", 1, GameMode::GAMEMODE_CHALLENGE_ICE },
	{ static_cast<BrutalSecretId>(41), "mini41", "Zen Garden", "Built-in game mode: Zen Garden", 1, GameMode::GAMEMODE_CHALLENGE_ZEN_GARDEN },
	{ static_cast<BrutalSecretId>(42), "mini42", "High Gravity", "Built-in game mode: High Gravity", 1, GameMode::GAMEMODE_CHALLENGE_HIGH_GRAVITY },
	{ static_cast<BrutalSecretId>(43), "mini43", "Grave Danger", "Built-in game mode: Grave Danger", 1, GameMode::GAMEMODE_CHALLENGE_GRAVE_DANGER },
	{ static_cast<BrutalSecretId>(44), "mini44", "Shovel", "Built-in game mode: Shovel", 1, GameMode::GAMEMODE_CHALLENGE_SHOVEL },
	{ static_cast<BrutalSecretId>(45), "mini45", "Stormy Night", "Built-in game mode: Stormy Night", 1, GameMode::GAMEMODE_CHALLENGE_STORMY_NIGHT },
	{ static_cast<BrutalSecretId>(46), "mini46", "Bungee Blitz", "Built-in game mode: Bungee Blitz", 1, GameMode::GAMEMODE_CHALLENGE_BUNGEE_BLITZ },
	{ static_cast<BrutalSecretId>(47), "mini47", "Squirrel", "Built-in game mode: Squirrel", 1, GameMode::GAMEMODE_CHALLENGE_SQUIRREL },
	{ static_cast<BrutalSecretId>(48), "mini48", "Scary potter 1", "Built-in game mode: Scary potter 1", 1, GameMode::GAMEMODE_SCARY_POTTER_1 },
	{ static_cast<BrutalSecretId>(49), "mini49", "Scary potter 2", "Built-in game mode: Scary potter 2", 1, GameMode::GAMEMODE_SCARY_POTTER_2 },
	{ static_cast<BrutalSecretId>(50), "mini50", "Scary potter 3", "Built-in game mode: Scary potter 3", 1, GameMode::GAMEMODE_SCARY_POTTER_3 },
	{ static_cast<BrutalSecretId>(51), "mini51", "Scary potter 4", "Built-in game mode: Scary potter 4", 1, GameMode::GAMEMODE_SCARY_POTTER_4 },
	{ static_cast<BrutalSecretId>(52), "mini52", "Scary potter 5", "Built-in game mode: Scary potter 5", 1, GameMode::GAMEMODE_SCARY_POTTER_5 },
	{ static_cast<BrutalSecretId>(53), "mini53", "Scary potter 6", "Built-in game mode: Scary potter 6", 1, GameMode::GAMEMODE_SCARY_POTTER_6 },
	{ static_cast<BrutalSecretId>(54), "mini54", "Scary potter 7", "Built-in game mode: Scary potter 7", 1, GameMode::GAMEMODE_SCARY_POTTER_7 },
	{ static_cast<BrutalSecretId>(55), "mini55", "Scary potter 8", "Built-in game mode: Scary potter 8", 1, GameMode::GAMEMODE_SCARY_POTTER_8 },
	{ static_cast<BrutalSecretId>(56), "mini56", "Scary potter 9", "Built-in game mode: Scary potter 9", 1, GameMode::GAMEMODE_SCARY_POTTER_9 },
	{ static_cast<BrutalSecretId>(57), "mini57", "Scary potter endless", "Built-in game mode: Scary potter endless", 1, GameMode::GAMEMODE_SCARY_POTTER_ENDLESS },
	{ static_cast<BrutalSecretId>(58), "mini58", "I-zombie 1", "Built-in game mode: I-zombie 1", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_1 },
	{ static_cast<BrutalSecretId>(59), "mini59", "I-zombie 2", "Built-in game mode: I-zombie 2", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_2 },
	{ static_cast<BrutalSecretId>(60), "mini60", "I-zombie 3", "Built-in game mode: I-zombie 3", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_3 },
	{ static_cast<BrutalSecretId>(61), "mini61", "I-zombie 4", "Built-in game mode: I-zombie 4", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_4 },
	{ static_cast<BrutalSecretId>(62), "mini62", "I-zombie 5", "Built-in game mode: I-zombie 5", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_5 },
	{ static_cast<BrutalSecretId>(63), "mini63", "I-zombie 6", "Built-in game mode: I-zombie 6", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_6 },
	{ static_cast<BrutalSecretId>(64), "mini64", "I-zombie 7", "Built-in game mode: I-zombie 7", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_7 },
	{ static_cast<BrutalSecretId>(65), "mini65", "I-zombie 8", "Built-in game mode: I-zombie 8", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_8 },
	{ static_cast<BrutalSecretId>(66), "mini66", "I-zombie 9", "Built-in game mode: I-zombie 9", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_9 },
	{ static_cast<BrutalSecretId>(67), "mini67", "I-zombie endless", "Built-in game mode: I-zombie endless", 1, GameMode::GAMEMODE_PUZZLE_I_ZOMBIE_ENDLESS },
};

const BrutalSecretInfo* BrutalSecretGetInfo(int id)
{
	if (id <= 0 || id >= BRUTAL_SECRET_COUNT) return nullptr;
	return &kSecrets[id - 1];
}

int BrutalSecretCount()
{
	return (int)(sizeof(kSecrets) / sizeof(kSecrets[0]));
}

int BrutalParseNameLevelCode(const std::string& name)
{
	std::string s;
	for (char c : name)
	{
		if (c == ' ' || c == '-' || c == '_') continue;
		if (!std::isdigit(static_cast<unsigned char>(c)))
			return -1;
		s.push_back(c);
	}
	if (s.size() < 2 || s.size() > 3) return -1;
	int area = 0, sub = 0;
	if (s.size() == 2)
	{
		area = s[0] - '0';
		sub = s[1] - '0';
	}
	else
	{
		area = (s[0] - '0') * 10 + (s[1] - '0');
		sub = s[2] - '0';
		if (area > 5) { area = s[0] - '0'; sub = (s[1] - '0') * 10 + (s[2] - '0'); }
	}
	if (area < 1 || area > 5 || sub < 1 || sub > 10) return -1;
	return (area - 1) * 10 + sub;
}

void BrutalSecretApplyToBoard(Board* board)
{
	if (!board || !board->mApp) return;
	const int id = board->mApp->mBrutalSecretId;
	if (id <= 0) return;

	const BrutalSecretInfo* info = BrutalSecretGetInfo(id);
	if (info)
	{
		// Visible banner so the secret is obviously active
		board->DisplayAdvice(
			std::string("[SECRET] ") + info->title,
			MessageStyle::MESSAGE_STYLE_HINT_LONG,
			AdviceType::ADVICE_NONE);
	}

	if (id == BRUTAL_SECRET_VISUAL || id == BRUTAL_SECRET_GUARDIAN)
	{
		for (int x = 0; x < MAX_GRID_SIZE_X; x++)
			for (int y = 0; y < MAX_GRID_SIZE_Y + 1; y++)
				board->mGridCelFog[x][y] = (id == BRUTAL_SECRET_GUARDIAN) ? 1000 : 500;
		board->mFogBlownCountDown = 3000;
	}

	if (id == BRUTAL_SECRET_FRIGHT || id == BRUTAL_SECRET_CLOSE)
	{
		board->mEnableGraveStones = true;
	}

	if (id == BRUTAL_SECRET_REPRISAL)
	{
		board->mSunMoney = std::max(board->mSunMoney, 300);
	}

	if (id == BRUTAL_SECRET_LONG)
	{
		board->mNumSunsFallen = 8;
		// denser: more waves later handled by BrutalMode getters when secret active
	}

	if (id == BRUTAL_SECRET_OVERCAST || id == BRUTAL_SECRET_STORM)
	{
		board->mNumSunsFallen = 99;
		board->mSunCountDown = 999999; // effectively no sky sun
	}

	if (id == BRUTAL_SECRET_CLOSE)
	{
		// Force pool background path via level 21 if still adventure
		if (board->mApp->IsAdventureMode() && board->mLevel < 21)
		{
			board->mLevel = 21;
			if (board->mApp->mPlayerInfo)
				board->mApp->mPlayerInfo->SetLevel(21);
		}
	}

	BrutalSecretApplyLate(board);
}

void BrutalSecretApplyLate(Board* board)
{
	if (!board || !board->mApp || !board->mSeedBank) return;
	const int id = board->mApp->mBrutalSecretId;
	if (id <= 0) return;

	if (id == BRUTAL_SECRET_SINGLE)
	{
		board->mSeedBank->mNumPackets = std::min(3, SEEDBANK_MAX);
		board->mSeedBank->UpdateWidth();
		for (int i = 0; i < board->mSeedBank->mNumPackets; i++)
			board->mSeedBank->mSeedPackets[i].mX = board->GetSeedPacketPositionX(i);
	}
	if (id == BRUTAL_SECRET_SLOT && board->mApp->mGameMode == GameMode::GAMEMODE_ADVENTURE)
	{
		int n = std::min(6, SEEDBANK_MAX);
		board->mSeedBank->mNumPackets = n;
		board->mSeedBank->UpdateWidth();
		for (int i = 0; i < n; i++)
		{
			board->mSeedBank->mSeedPackets[i].SetPacketType(SeedType::SEED_PEASHOOTER);
			board->mSeedBank->mSeedPackets[i].mX = board->GetSeedPacketPositionX(i);
		}
	}
}
