#include "BrutalAlmanac.h"

std::string BrutalPlantAlmanacExtra(SeedType seed)
{
	switch (seed)
	{
	case SeedType::SEED_PEASHOOTER:
		return "\n\n[BRUTAL] First Dream: each shot can raise fire rate (cap +50%).";
	case SeedType::SEED_SUNFLOWER:
	case SeedType::SEED_TWINSUNFLOWER:
		return "\n\n[BRUTAL] Sun House: 12% chance extra small sun.";
	case SeedType::SEED_CHERRYBOMB:
		return "\n\n[BRUTAL] Twin Cherry: 21% leave a Potato Mine.";
	case SeedType::SEED_WALLNUT:
		return "\n\n[BRUTAL] Healing Art: regenerates / full heal after long idle.";
	case SeedType::SEED_POTATOMINE:
		return "\n\n[BRUTAL] Quick Start: arms immediately.";
	case SeedType::SEED_SNOWPEA:
		return "\n\n[BRUTAL] Mind Flame: 22% chance fire pea.";
	case SeedType::SEED_CHOMPER:
		return "\n\n[BRUTAL] Feast: digest time scales with swallowed HP.";
	case SeedType::SEED_REPEATER:
		return "\n\n[BRUTAL] Twin Scatter: 33% extra angled peas + fire-rate stacks.";
	case SeedType::SEED_PUFFSHROOM:
		return "\n\n[BRUTAL] Frost Armor: 23% freeze eater on death.";
	case SeedType::SEED_SUNSHROOM:
		return "\n\n[BRUTAL] Fast Grow: big form in 90s; extra sun when big.";
	case SeedType::SEED_FUMESHROOM:
		return "\n\n[BRUTAL] Eagle Eye: fumes cover a full row.";
	case SeedType::SEED_GRAVEBUSTER:
		return "\n\n[BRUTAL] Necro Convert: refunds 75 sun; 1/3 extra sun.";
	case SeedType::SEED_HYPNOSHROOM:
		return "\n\n[BRUTAL] Part of Brutal pressure rules.";
	case SeedType::SEED_SCAREDYSHROOM:
		return "\n\n[BRUTAL] Hero Miracle: 1500 HP and faster shots.";
	case SeedType::SEED_ICESHROOM:
		return "\n\n[BRUTAL] Strong freeze pressure in Brutal levels.";
	case SeedType::SEED_DOOMSHROOM:
		return "\n\n[BRUTAL] Battlefield Scar: longer crater recovery.";
	case SeedType::SEED_LILYPAD:
		return "\n\n[BRUTAL] Needed for pool; banned in No Swimming secret.";
	case SeedType::SEED_SQUASH:
		return "\n\n[BRUTAL] Heavy Impact: longer range; 27% multi-smash.";
	case SeedType::SEED_THREEPEATER:
		return "\n\n[BRUTAL] God/Demon: peas may be fire or ice.";
	case SeedType::SEED_TANGLEKELP:
		return "\n\n[BRUTAL] Sea Demon: can drag up to 3 zombies.";
	case SeedType::SEED_JALAPENO:
		return "\n\n[BRUTAL] Ice & Fire: 13% freeze other rows.";
	case SeedType::SEED_SPIKEWEED:
	case SeedType::SEED_SPIKEROCK:
		return "\n\n[BRUTAL] Soul Strike: high chance butter-stun.";
	case SeedType::SEED_TORCHWOOD:
		return "\n\n[BRUTAL] Torch Chain: each Torchwood upgrades fire peas (tiers 40-80 dmg).";
	case SeedType::SEED_TALLNUT:
		return "\n\n[BRUTAL] Flesh Regen + Thorns: idle regen; 15 dmg reflect.";
	case SeedType::SEED_SEASHROOM:
		return "\n\n[BRUTAL] Frost Scale: 39% freeze eater on death.";
	case SeedType::SEED_PLANTERN:
		return "\n\n[BRUTAL] Dawn Will: nearby shooters fire faster.";
	case SeedType::SEED_CACTUS:
		return "\n\n[BRUTAL] Spined Body: faster fire rate.";
	case SeedType::SEED_BLOVER:
		return "\n\n[BRUTAL] Storm: 60 dmg to all + knock row back.";
	case SeedType::SEED_SPLITPEA:
		return "\n\n[BRUTAL] Twin Nirvana: front fire, back ice.";
	case SeedType::SEED_STARFRUIT:
		return "\n\n[BRUTAL] Emperor's Wrath: lower per-hit, hits shield+body.";
	case SeedType::SEED_PUMPKINSHELL:
		return "\n\n[BRUTAL] Rage Burst: explodes on death.";
	case SeedType::SEED_MAGNETSHROOM:
		return "\n\n[BRUTAL] Still removes metal; critical vs buckets/football.";
	case SeedType::SEED_CABBAGEPULT:
		return "\n\n[BRUTAL] Braver: fire-rate stacks while fighting.";
	case SeedType::SEED_FLOWERPOT:
		return "\n\n[BRUTAL] Roof support plant.";
	case SeedType::SEED_KERNELPULT:
		return "\n\n[BRUTAL] Khrushchev's Rage: butter after 15 dry shots.";
	case SeedType::SEED_COFFEEBEAN:
		return "\n\n[BRUTAL] Wakes night plants as usual.";
	case SeedType::SEED_GARLIC:
		return "\n\n[BRUTAL] Stench: poison aura to nearby zombies.";
	case SeedType::SEED_UMBRELLA:
		return "\n\n[BRUTAL] Blocks bungees as usual.";
	case SeedType::SEED_MARIGOLD:
		return "\n\n[BRUTAL] Coin plant; still useful for economy.";
	case SeedType::SEED_MELONPULT:
		return "\n\n[BRUTAL] Extra smash: 17% row-wide bonus hit.";
	case SeedType::SEED_GATLINGPEA:
		return "\n\n[BRUTAL] Fire-rate stacks on each volley.";
	case SeedType::SEED_TWINSUNFLOWER:
		return "\n\n[BRUTAL] Sun House: 12% extra small sun.";
	case SeedType::SEED_GLOOMSHROOM:
		return "\n\n[BRUTAL] Heavy area DPS under Brutal pressure.";
	case SeedType::SEED_CATTAIL:
		return "\n\n[BRUTAL] Sea Hymn: 3% heavy strike.";
	case SeedType::SEED_WINTERMELON:
		return "\n\n[BRUTAL] Icefall: 17% row-wide chilled bonus hit.";
	case SeedType::SEED_GOLD_MAGNET:
		return "\n\n[BRUTAL] Runaway Current: same row/col zaps zombies.";
	case SeedType::SEED_SPIKEROCK:
		return "\n\n[BRUTAL] Soul Strike + durable spikes.";
	case SeedType::SEED_COBCANNON:
		return "\n\n[BRUTAL] Overload: faster first load and reload.";
	case SeedType::SEED_IMITATER:
		return "\n\n[BRUTAL] Copies the chosen plant's Brutal rules.";
	default:
		return "\n\n[BRUTAL] Subject to Brutal Mode rules.";
	}
}

std::string BrutalZombieAlmanacExtra(ZombieType type)
{
	switch (type)
	{
	case ZombieType::ZOMBIE_NORMAL:
		return "\n\n[BRUTAL] 2 forms: Normal | Letterhead (2x HP, much faster, walks through plants).";
	case ZombieType::ZOMBIE_FLAG:
		return "\n\n[BRUTAL] 2 forms: Normal (sun drain) | Night Horn (strong drain).";
	case ZombieType::ZOMBIE_TRAFFIC_CONE:
		return "\n\n[BRUTAL] 3 forms: Normal | Gramophone (full heal pulse 6.5s 3x5) | Dancing/MJ (death: 4 dancers).";
	case ZombieType::ZOMBIE_POLEVAULTER:
		return "\n\n[BRUTAL] Single form: after vault, leaves a gravestone.";
	case ZombieType::ZOMBIE_PAIL:
		return "\n\n[BRUTAL] 2 forms: Normal | Armorer (gifts buckets every 6.5s).";
	case ZombieType::ZOMBIE_NEWSPAPER:
		return "\n\n[BRUTAL] Single form: huge rage speed after newspaper breaks.";
	case ZombieType::ZOMBIE_DOOR:
		return "\n\n[BRUTAL] Single form: reflects horizontal peas/puff/snowpea (not fireballs).";
	case ZombieType::ZOMBIE_FOOTBALL:
		return "\n\n[BRUTAL] Single form: higher HP and sprint pressure.";
	case ZombieType::ZOMBIE_DANCER:
		return "\n\n[BRUTAL] MJ-style: faster/double summons; backup can become new dancer.";
	case ZombieType::ZOMBIE_BACKUP_DANCER:
		return "\n\n[BRUTAL] Can inherit the crown when the Dancer dies.";
	case ZombieType::ZOMBIE_DUCKY_TUBE:
		return "\n\n[BRUTAL] 2 forms: Normal | Letterhead-style tough/fast in pool.";
	case ZombieType::ZOMBIE_SNORKEL:
		return "\n\n[BRUTAL] Single form: higher water pressure / speed.";
	case ZombieType::ZOMBIE_ZAMBONI:
		return "\n\n[BRUTAL] Single form: slows nearby plants' firing.";
	case ZombieType::ZOMBIE_BOBSLED:
		return "\n\n[BRUTAL] Team pressure with Zamboni ice.";
	case ZombieType::ZOMBIE_DOLPHIN_RIDER:
		return "\n\n[BRUTAL] Single form: high charge speed.";
	case ZombieType::ZOMBIE_JACK_IN_THE_BOX:
		return "\n\n[BRUTAL] Single form: shorter fuse + seed CD pressure.";
	case ZombieType::ZOMBIE_BALLOON:
		return "\n\n[BRUTAL] Single form: keeps high air speed.";
	case ZombieType::ZOMBIE_DIGGER:
		return "\n\n[BRUTAL] Single form: damages plants while tunneling.";
	case ZombieType::ZOMBIE_POGO:
		return "\n\n[BRUTAL] Single form: instant vault (no long charge).";
	case ZombieType::ZOMBIE_YETI:
		return "\n\n[BRUTAL] Single form: global HP/speed pressure.";
	case ZombieType::ZOMBIE_BUNGEE:
		return "\n\n[BRUTAL] Single form: faster dive phases.";
	case ZombieType::ZOMBIE_LADDER:
		return "\n\n[BRUTAL] Single form: chews plants ~5x faster.";
	case ZombieType::ZOMBIE_CATAPULT:
		return "\n\n[BRUTAL] Single form: Basketball Faith under half HP.";
	case ZombieType::ZOMBIE_GARGANTUAR:
	case ZombieType::ZOMBIE_REDEYE_GARGANTUAR:
		return "\n\n[BRUTAL] Single form: throws Imp earlier under half HP.";
	case ZombieType::ZOMBIE_IMP:
		return "\n\n[BRUTAL] Fast after throw; global pressure.";
	case ZombieType::ZOMBIE_PEA_HEAD:
		return "\n\n[BRUTAL] Cone helm + faster pea shots.";
	case ZombieType::ZOMBIE_WALLNUT_HEAD:
		return "\n\n[BRUTAL] Much tougher nut head.";
	case ZombieType::ZOMBIE_JALAPENO_HEAD:
		return "\n\n[BRUTAL] Door+cone armor.";
	case ZombieType::ZOMBIE_GATLING_HEAD:
		return "\n\n[BRUTAL] Bucket helm; heavy fire.";
	case ZombieType::ZOMBIE_SQUASH_HEAD:
		return "\n\n[BRUTAL] Door+cone armor.";
	case ZombieType::ZOMBIE_TALLNUT_HEAD:
		return "\n\n[BRUTAL] Spirit Regen: heals over time.";
	case ZombieType::ZOMBIE_BOSS:
		return "\n\n[BRUTAL] Boss HP increased; not variant-split.";
	default:
		return "\n\n[BRUTAL] Global HP x1.85 / speed x1.25 pressure.";
	}
}
