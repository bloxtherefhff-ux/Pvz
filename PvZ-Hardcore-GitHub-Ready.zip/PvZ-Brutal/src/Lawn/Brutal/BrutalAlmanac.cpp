#include "BrutalAlmanac.h"

// Unnamed (无名) skill blurbs for Almanac — matches fanon wiki rules we implemented
std::string BrutalPlantAlmanacExtra(SeedType seed)
{
	switch (seed)
	{
	case SeedType::SEED_PEASHOOTER:
		return "\n\n[UNNAMED] Attack speed stacks up to +50% (1% per shot).";
	case SeedType::SEED_SUNFLOWER:
		return "\n\n[UNNAMED] Small chance of +15 bonus sun.";
	case SeedType::SEED_TWINSUNFLOWER:
		return "\n\n[UNNAMED] Chance of +25 or +50 bonus sun.";
	case SeedType::SEED_CHERRYBOMB:
		return "\n\n[UNNAMED] 20% chance to leave a Potato Mine on explode.";
	case SeedType::SEED_WALLNUT:
		return "\n\n[UNNAMED] Full heal if not bitten for ~48s.";
	case SeedType::SEED_POTATOMINE:
		return "\n\n[UNNAMED] Costs 50; arms instantly; 1x3 blast.";
	case SeedType::SEED_SNOWPEA:
		return "\n\n[UNNAMED] 22% double-damage fire peas (still chill).";
	case SeedType::SEED_CHOMPER:
		return "\n\n[UNNAMED] Faster digest; refunds sun by prey HP.";
	case SeedType::SEED_REPEATER:
	case SeedType::SEED_GATLINGPEA:
		return "\n\n[UNNAMED] 33% chance of extra diagonal peas.";
	case SeedType::SEED_PUFFSHROOM:
	case SeedType::SEED_SEASHROOM:
		return "\n\n[UNNAMED] Chance to freeze zombies eating it.";
	case SeedType::SEED_SUNSHROOM:
		return "\n\n[UNNAMED] Full-size: chance of +15 bonus sun.";
	case SeedType::SEED_FUMESHROOM:
		return "\n\n[UNNAMED] Cost 100; pierces with long range.";
	case SeedType::SEED_GRAVEBUSTER:
		return "\n\n[UNNAMED] Refunds 50 sun (1/3 chance +25 more).";
	case SeedType::SEED_HYPNOSHROOM:
		return "\n\n[UNNAMED] Cost 100; browncoats gain a bucket when hypno'd.";
	case SeedType::SEED_SCAREDYSHROOM:
		return "\n\n[UNNAMED] Cost 125; dual spores; 1500 HP wall-shooter.";
	case SeedType::SEED_DOOMSHROOM:
		return "\n\n[UNNAMED] Cost 150; full-lawn blast.";
	case SeedType::SEED_SQUASH:
		return "\n\n[UNNAMED] 27% chance to squash a second time.";
	case SeedType::SEED_THREEPEATER:
		return "\n\n[UNNAMED] Cost 350; mixes flame + snow peas.";
	case SeedType::SEED_TANGLEKELP:
		return "\n\n[UNNAMED] Cost 50; drags up to 3 zombies.";
	case SeedType::SEED_JALAPENO:
		return "\n\n[UNNAMED] Afterburn fireballs; rare full freeze.";
	case SeedType::SEED_SPIKEWEED:
	case SeedType::SEED_SPIKEROCK:
		return "\n\n[UNNAMED] Chance to stun walkers; Spikerock more often.";
	case SeedType::SEED_TORCHWOOD:
		return "\n\n[UNNAMED] Stack up to 3 (2x / 3x / 4x fire damage).";
	case SeedType::SEED_TALLNUT:
		return "\n\n[UNNAMED] Passive regen + thorns vs eaters; blocks vaults.";
	case SeedType::SEED_PLANTERN:
		return "\n\n[UNNAMED] Cost 150; clears fog; +50% fire-rate nearby.";
	case SeedType::SEED_CACTUS:
		return "\n\n[UNNAMED] Cost 175; dual spikes / pierce.";
	case SeedType::SEED_BLOVER:
		return "\n\n[UNNAMED] Cost 125; chill all + push lane (Hurrikale-style).";
	case SeedType::SEED_SPLITPEA:
		return "\n\n[UNNAMED] Cost 175; flame forward, dual snow back.";
	case SeedType::SEED_STARFRUIT:
		return "\n\n[UNNAMED] Cost 175; piercing stars.";
	case SeedType::SEED_PUMPKINSHELL:
		return "\n\n[UNNAMED] Cost 200; Cherry-Bomb explode on death.";
	case SeedType::SEED_MAGNETSHROOM:
		return "\n\n[UNNAMED] Cost 125; full-lawn metal pull (not Football).";
	case SeedType::SEED_KERNELPULT:
		return "\n\n[UNNAMED] Butter can stack; rare Cob-like lob.";
	case SeedType::SEED_GARLIC:
		return "\n\n[UNNAMED] Cost 100; lane divert + 3x3 chip + chill eater.";
	case SeedType::SEED_MARIGOLD:
		return "\n\n[UNNAMED] Cost 150; insta-cut target to 1/4 HP.";
	case SeedType::SEED_MELONPULT:
	case SeedType::SEED_WINTERMELON:
		return "\n\n[UNNAMED] Chance to lob at whole lane.";
	case SeedType::SEED_CATTAIL:
		return "\n\n[UNNAMED] Cost 200; pierce + rare Cob shots.";
	case SeedType::SEED_GOLD_MAGNET:
		return "\n\n[UNNAMED] Electric current between magnets.";
	case SeedType::SEED_COBCANNON:
		return "\n\n[UNNAMED] Slightly faster reload.";
	case SeedType::SEED_LILYPAD:
	case SeedType::SEED_FLOWERPOT:
		return "\n\n[UNNAMED] 5-second recharge.";
	default:
		return "";
	}
}

std::string BrutalZombieAlmanacExtra(ZombieType type)
{
	switch (type)
	{
	case ZombieType::ZOMBIE_NORMAL:
		return "\n\n[UNNAMED] Variant: Letterhead — much tougher (not faster).";
	case ZombieType::ZOMBIE_TRAFFIC_CONE:
		return "\n\n[UNNAMED] Variants: Gramophone (heal aura) | Dancing/MJ (death dancers).";
	case ZombieType::ZOMBIE_PAIL:
		return "\n\n[UNNAMED] Variant: Armorer/Pumpkin — gifts pails to allies.";
	case ZombieType::ZOMBIE_FLAG:
		return "\n\n[UNNAMED] Variant: Night Horn — drains sun.";
	case ZombieType::ZOMBIE_NEWSPAPER:
		return "\n\n[UNNAMED] Rage is much faster; avoid pea-triggering.";
	case ZombieType::ZOMBIE_DOOR:
		return "\n\n[UNNAMED] Harder screen-door; Tall-Nut door variants exist.";
	case ZombieType::ZOMBIE_FOOTBALL:
		return "\n\n[UNNAMED] ~2x health; Hypno is best answer.";
	case ZombieType::ZOMBIE_POLEVAULTER:
		return "\n\n[UNNAMED] Can plant graves after vault; block with Tall-Nut.";
	case ZombieType::ZOMBIE_POGO:
		return "\n\n[UNNAMED] Faster hops; rare Chocolate/Garlic variants.";
	case ZombieType::ZOMBIE_BALLOON:
		return "\n\n[UNNAMED] Resists Blover; needs damage or multiple Blovers.";
	case ZombieType::ZOMBIE_DIGGER:
		return "\n\n[UNNAMED] Cone HP; eats walls/spikes underground.";
	case ZombieType::ZOMBIE_BUNGEE:
		return "\n\n[UNNAMED] Variants: Wheelbarrow shield | Jack-box deploy.";
	case ZombieType::ZOMBIE_LADDER:
		return "\n\n[UNNAMED] Shovel variant unplants; red variant summons Bungee.";
	case ZombieType::ZOMBIE_CATAPULT:
		return "\n\n[UNNAMED] Nearly immortal until balls run out.";
	case ZombieType::ZOMBIE_GARGANTUAR:
	case ZombieType::ZOMBIE_REDEYE_GARGANTUAR:
		return "\n\n[UNNAMED] Standard crush + Imp; World7 variants exist.";
	case ZombieType::ZOMBIE_BOSS:
		return "\n\n[UNNAMED] Extra HP on later fights; wider summons.";
	case ZombieType::ZOMBIE_DANCER:
		return "\n\n[UNNAMED] Ambush summons; king death promotes backups.";
	case ZombieType::ZOMBIE_SNORKEL:
		return "\n\n[UNNAMED] Lily-Pad snorkel needs instants.";
	case ZombieType::ZOMBIE_DOLPHIN_RIDER:
		return "\n\n[UNNAMED] Attacks two zones after leap; Tall-Nut blocks.";
	case ZombieType::ZOMBIE_ZAMBONI:
		return "\n\n[UNNAMED] Spikeweed/Jalapeno answers; freezes less absolute.";
	case ZombieType::ZOMBIE_PEA_HEAD:
		return "\n\n[UNNAMED] Cone HP; counts like basic spawn weight.";
	case ZombieType::ZOMBIE_WALLNUT_HEAD:
		return "\n\n[UNNAMED] Can regenerate if left alone.";
	case ZombieType::ZOMBIE_TALLNUT_HEAD:
		return "\n\n[UNNAMED] Accelerating self-heal if not focused.";
	case ZombieType::ZOMBIE_JALAPENO_HEAD:
	case ZombieType::ZOMBIE_SQUASH_HEAD:
	case ZombieType::ZOMBIE_GATLING_HEAD:
		return "\n\n[UNNAMED] Heavy armor; treat as elite plant-heads.";
	default:
		return "\n\n[UNNAMED] Brutal pressure + possible special form.";
	}
}
