#include "BrutalMode.h"
#include "BrutalSecrets.h"
#include "../../LawnApp.h"
#include "../Zombie.h"
#include "../Board.h"
#include "../Plant.h"
#include "../../ConstEnums.h"
#include "../../LawnApp.h"
#include "../../SexyAppFramework/Common.h"
#include <algorithm>

namespace BrutalMode
{
namespace
{
constexpr EvoPlantInfo kEvoPlants[] =
{
	{ BrutalEvoType::SHADOW_PEASHOOTER,  SeedType::SEED_PEASHOOTER,    "Evo Peashooter",     "Shadow plant: ice peas; powered mode becomes a piercing fume-style attack." },
	{ BrutalEvoType::PRIMAL_SUNFLOWER,   SeedType::SEED_SUNFLOWER,     "Evo Sunflower",      "Makes 40-sun drops faster and produces an extra small sun burst." },
	{ BrutalEvoType::SHRAPNEL_CHERRY,   SeedType::SEED_CHERRYBOMB,    "Evo Cherry Bomb",    "Explodes over 3x3 and throws shrapnel; the blast hits nearby zombies twice." },
	{ BrutalEvoType::BOWLING_WALLNUT,   SeedType::SEED_WALLNUT,       "Evo Wall-nut",       "Rolls with a periodic lane slam that damages and knocks zombies back." },
	{ BrutalEvoType::FIRE_DRAGON,       SeedType::SEED_CHOMPER,       "Evo Chomper",        "Acts like a fire dragon: a fast bite-cone burns nearby zombies." },
	{ BrutalEvoType::POISON_PUFFSHROOM, SeedType::SEED_PUFFSHROOM,    "Evo Puff-shroom",   "A zombie that eats it is poisoned and takes heavy retaliation damage." },
	{ BrutalEvoType::GOLD_SUNSHROOM,    SeedType::SEED_SUNSHROOM,     "Evo Sun-shroom",    "Grows into a short-lived gold form that spits out three large suns." },
	{ BrutalEvoType::EVO_GRAVEBUSTER,   SeedType::SEED_GRAVEBUSTER,   "Evo Grave Buster",  "Consumes graves for an extra reward and a chance at bonus seed loot." },
	{ BrutalEvoType::EVO_HYPNOSHROOM,   SeedType::SEED_HYPNOSHROOM,   "Evo Hypno-shroom",  "On eating, hypnotizes the attacker and can spread the hypnosis nearby." },
	{ BrutalEvoType::EVO_SCAREDYSHROOM, SeedType::SEED_SCAREDYSHROOM, "Evo Scaredy-shroom", "Fires a powerful 120-damage prism pulse and becomes much tankier." },
	{ BrutalEvoType::ENCHANTED_TALLNUT, SeedType::SEED_TALLNUT,       "Evo Tall-nut",      "Every 1200 damage absorbed summons a hypnotized defender." },
	{ BrutalEvoType::EVO_PLANTERN,      SeedType::SEED_PLANTERN,      "Evo Plantern",      "Creates suns and powers nearby Evo shadow plants into alternate forms." },
	{ BrutalEvoType::REVERSE_BLOVER,    SeedType::SEED_BLOVER,        "Evo Blover",         "Sends living zombies back to the far right without healing them." },
	{ BrutalEvoType::PHANTOM_STARFRUIT, SeedType::SEED_STARFRUIT,     "Evo Starfruit",      "Each volley rolls a random phantom effect: freeze, push, hypnosis, or burst." },
	{ BrutalEvoType::SHADOW_CABBAGE,    SeedType::SEED_CABBAGEPULT,   "Evo Cabbage-pult",  "Shadow form gains splash; powered mode attacks three lanes at once." },
	{ BrutalEvoType::BUTTER_THROWER,    SeedType::SEED_KERNELPULT,    "Evo Kernel-pult",   "Every shot is butter and locks targets down more reliably." },
	{ BrutalEvoType::EVO_COFFEEBEAN,    SeedType::SEED_INSTANT_COFFEE,"Evo Coffee Bean",   "Wakes every plant in a 3x3 area instead of only one sleeping plant." },
	{ BrutalEvoType::EVO_UMBRELLA,      SeedType::SEED_UMBRELLA,       "Evo Umbrella",     "Automatically opens on a cycle and reflects incoming projectiles." },
	{ BrutalEvoType::EVO_GATLINGPEA,   SeedType::SEED_GATLINGPEA,    "Evo Gatling Pea",  "Every few seconds fires a 500-damage execution burst at the strongest zombie." },
	{ BrutalEvoType::EVO_GLOOMSHROOM,   SeedType::SEED_GLOOMSHROOM,   "Evo Gloom-shroom", "Alternates fire and ice aura modes, scorching or chilling nearby zombies." }
};
}

int GetEvoCount()
{
	return static_cast<int>(sizeof(kEvoPlants) / sizeof(kEvoPlants[0]));
}

const EvoPlantInfo& GetEvoInfo(int theIndex)
{
	PVZP_ASSERT(theIndex >= 0 && theIndex < GetEvoCount());
	return kEvoPlants[theIndex];
}

const EvoPlantInfo* GetEvoInfo(BrutalEvoType theType)
{
	for (const EvoPlantInfo& info : kEvoPlants)
	{
		if (info.mType == theType)
			return &info;
	}
	return nullptr;
}

BrutalEvoType DefaultEvoForBase(SeedType theSeedType)
{
	for (const EvoPlantInfo& info : kEvoPlants)
	{
		if (info.mBaseSeed == theSeedType)
			return info.mType;
	}
	return BrutalEvoType::NONE;
}

SeedType GetEvoBaseSeed(BrutalEvoType theType)
{
	const EvoPlantInfo* info = GetEvoInfo(theType);
	return info ? info->mBaseSeed : SeedType::SEED_NONE;
}

bool IsEvoTypeValid(BrutalEvoType theType)
{
	return theType != BrutalEvoType::NONE && GetEvoInfo(theType) != nullptr;
}

int GetEvoCost(BrutalEvoType theType)
{
	switch (theType)
	{
	case BrutalEvoType::SHADOW_PEASHOOTER:   return 150;
	case BrutalEvoType::PRIMAL_SUNFLOWER:    return 75;
	case BrutalEvoType::SHRAPNEL_CHERRY:     return 250;
	case BrutalEvoType::BOWLING_WALLNUT:     return 50;
	case BrutalEvoType::FIRE_DRAGON:         return 250;
	case BrutalEvoType::POISON_PUFFSHROOM:   return 25;
	case BrutalEvoType::GOLD_SUNSHROOM:      return 100;
	case BrutalEvoType::EVO_GRAVEBUSTER:     return 50;
	case BrutalEvoType::EVO_HYPNOSHROOM:     return 50;
	case BrutalEvoType::EVO_SCAREDYSHROOM:   return 50;
	case BrutalEvoType::ENCHANTED_TALLNUT:   return 225;
	case BrutalEvoType::EVO_PLANTERN:        return 100;
	case BrutalEvoType::REVERSE_BLOVER:      return 75;
	case BrutalEvoType::PHANTOM_STARFRUIT:   return 375;
	case BrutalEvoType::SHADOW_CABBAGE:      return 200;
	case BrutalEvoType::BUTTER_THROWER:      return 175;
	case BrutalEvoType::EVO_COFFEEBEAN:      return 150;
	case BrutalEvoType::EVO_UMBRELLA:        return 25;
	case BrutalEvoType::EVO_GATLINGPEA:      return 350;
	case BrutalEvoType::EVO_GLOOMSHROOM:   return 325;
	default:                                return 0;
	}
}


int BrutalZombieForm(Zombie* z) { return z ? z->mBrutalForm : 0; }


static void ScaleHP(int& cur, int& maxv, float mul)
{
	if (maxv > 0)
	{
		maxv = static_cast<int>(maxv * mul + 0.5f);
		cur = maxv;
	}
	else if (cur > 0)
	{
		cur = static_cast<int>(cur * mul + 0.5f);
		maxv = cur;
	}
}

void ApplyToZombie(Zombie* zombie)
{
	if (!kEnabled || !zombie)
		return;

	const bool isBoss = (zombie->mZombieType == ZombieType::ZOMBIE_BOSS);
	float healthMul = isBoss ? 1.30f : kZombieHealthMul;
	float speedMul = isBoss ? 1.0f : kZombieSpeedMul;

	// Secret: Giant Trouble
	if (zombie->mApp && zombie->mApp->mBrutalSecretId == BRUTAL_SECRET_GIANT && !isBoss)
	{
		healthMul *= 4.0f;
		speedMul *= 0.5f;
		zombie->mScaleZombie *= 2.0f;
	}
	// Secret: Heisenberg — speed jitter
	if (zombie->mApp && zombie->mApp->mBrutalSecretId == BRUTAL_SECRET_CERTAIN && !isBoss)
	{
		speedMul *= (0.7f + (Sexy::Rand(60) / 100.0f));
	}

	switch (zombie->mZombieType)
	{
	case ZombieType::ZOMBIE_TRAFFIC_CONE:
		healthMul *= 1.15f;
		break;
	case ZombieType::ZOMBIE_PAIL:
		healthMul *= 1.25f;
		speedMul *= 0.90f; // Unnamed bucket abilityForm slower / tankier
		break;
	case ZombieType::ZOMBIE_DOOR:
		healthMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_FOOTBALL:
		healthMul *= 1.35f;
		speedMul *= kFootballSpeedMul;
		break;
	case ZombieType::ZOMBIE_GARGANTUAR:
	case ZombieType::ZOMBIE_REDEYE_GARGANTUAR:
		healthMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_NEWSPAPER:
		healthMul *= 1.30f;
		break;
	case ZombieType::ZOMBIE_POLEVAULTER:
		speedMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_FLAG:
		healthMul *= 1.40f; // 大动员
		break;
	case ZombieType::ZOMBIE_POGO:
		speedMul *= 1.15f;
		break;
	case ZombieType::ZOMBIE_BALLOON:
		healthMul *= 1.40f; // resists Blover — needs more hits
		speedMul *= 1.25f;
		break;
	case ZombieType::ZOMBIE_DOLPHIN_RIDER:
		speedMul *= 1.25f;
		break;
	case ZombieType::ZOMBIE_SNORKEL:
		speedMul *= 1.15f;
		break;
	case ZombieType::ZOMBIE_ZAMBONI:
		healthMul *= 1.30f;
		speedMul *= 1.10f; // 一往无前 feel
		break;
	case ZombieType::ZOMBIE_CATAPULT:
		// HP set after ScaleHP to 90000 while balls remain (see below)
		break;
	case ZombieType::ZOMBIE_DIGGER:
		healthMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_BUNGEE:
		healthMul *= 1.50f;
		break;
	case ZombieType::ZOMBIE_IMP:
		speedMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_PEA_HEAD:
		// 全副武装: cone helm
		healthMul *= 1.25f;
		break;
	case ZombieType::ZOMBIE_WALLNUT_HEAD:
		healthMul *= 1.50f;
		break;
	case ZombieType::ZOMBIE_JALAPENO_HEAD:
		healthMul *= 1.35f;
		break;
	case ZombieType::ZOMBIE_GATLING_HEAD:
		healthMul *= 1.40f;
		break;
	case ZombieType::ZOMBIE_SQUASH_HEAD:
		healthMul *= 1.35f;
		break;
	case ZombieType::ZOMBIE_TALLNUT_HEAD:
		healthMul *= 1.60f;
		break;
	default:
		break;
	}


	ScaleHP(zombie->mBodyHealth, zombie->mBodyMaxHealth, healthMul);
	ScaleHP(zombie->mHelmHealth, zombie->mHelmMaxHealth, healthMul);
	ScaleHP(zombie->mShieldHealth, zombie->mShieldMaxHealth, healthMul);
	ScaleHP(zombie->mFlyingHealth, zombie->mFlyingMaxHealth, healthMul);

	if (zombie->mVelX > 0.0f)
		zombie->mVelX *= speedMul;

	// ===== Exactly 2 forms where split: NORMAL + ability (never 3) =====
	// Cone: Normal | Gramophone healer
	// Bucket: Normal | Armorer (gift pails)
	// Flag: Normal | Night Horn (extra sun drain)
	// Basic/Ducky: Normal | Letterhead (2x HP, normal speed)
	// Dancer / others: single Brutal-tuned behavior (no second form)
	zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
	zombie->mVariant = false;
	if (!isBoss)
	{
		const int roll = Sexy::Rand(100);
		switch (zombie->mZombieType)
		{
		case ZombieType::ZOMBIE_TRAFFIC_CONE:
			// Unnamed: Normal | Gramophone (heal) | Dancing/MJ (death → dancers)
			if (roll < 45)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else if (roll < 75)
			{
				zombie->mBrutalForm = BRUTAL_CONE_GRAMOPHONE;
				zombie->mVariant = true;
			}
			else
			{
				zombie->mBrutalForm = BRUTAL_CONE_DANCING;
				zombie->mVariant = true;
			}
			break;
		case ZombieType::ZOMBIE_PAIL:
			if (roll < 65)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else
			{
				zombie->mBrutalForm = BRUTAL_BUCKET_ARMORER;
				zombie->mVariant = true;
			}
			break;
		case ZombieType::ZOMBIE_FLAG:
			if (roll < 60)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else
			{
				zombie->mBrutalForm = BRUTAL_FLAG_HORN;
				zombie->mVariant = true;
			}
			break;
		case ZombieType::ZOMBIE_NORMAL:
			// Unnamed Letterhead: tougher, NOT 2x speed
			if (roll < 89)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else
			{
				zombie->mBrutalForm = BRUTAL_BASIC_LETTERHEAD;
				zombie->mVariant = true;
				ScaleHP(zombie->mBodyHealth, zombie->mBodyMaxHealth, 2.0f);
				if (zombie->mVelX > 0.0f) zombie->mVelX *= 4.0f;
			}
			break;
		case ZombieType::ZOMBIE_DANCER:
			zombie->mVariant = true; // single MJ-style form
			break;
		default:
			break;
		}
	}

	// Plant-head zombies: force armor like Unnamed "全副武装"
	if (zombie->mZombieType == ZombieType::ZOMBIE_PEA_HEAD && zombie->mHelmType == HelmType::HELMTYPE_NONE)
	{
		zombie->mHelmType = HelmType::HELMTYPE_TRAFFIC_CONE;
		zombie->mHelmMaxHealth = 370;
		zombie->mHelmHealth = 370;
	}
	else if (zombie->mZombieType == ZombieType::ZOMBIE_GATLING_HEAD && zombie->mHelmType == HelmType::HELMTYPE_NONE)
	{
		zombie->mHelmType = HelmType::HELMTYPE_PAIL;
		zombie->mHelmMaxHealth = 1100;
		zombie->mHelmHealth = 1100;
	}
	else if ((zombie->mZombieType == ZombieType::ZOMBIE_JALAPENO_HEAD || zombie->mZombieType == ZombieType::ZOMBIE_SQUASH_HEAD)
		&& zombie->mShieldType == ShieldType::SHIELDTYPE_NONE)
	{
		zombie->mShieldType = ShieldType::SHIELDTYPE_DOOR;
		zombie->mShieldMaxHealth = 1100;
		zombie->mShieldHealth = 1100;
		zombie->mHelmType = HelmType::HELMTYPE_TRAFFIC_CONE;
		zombie->mHelmMaxHealth = 370;
		zombie->mHelmHealth = 370;
	}
	else if (zombie->mZombieType == ZombieType::ZOMBIE_TALLNUT_HEAD)
	{
		// 魂灵再生 handled in OnZombieUpdate
		zombie->mBodyMaxHealth = static_cast<int>(zombie->mBodyMaxHealth * 1.2f);
		zombie->mBodyHealth = zombie->mBodyMaxHealth;
	}

	// Catapult: 90k HP while balls remain; drops to normal when empty
	if (zombie->mZombieType == ZombieType::ZOMBIE_CATAPULT)
	{
		zombie->mBodyMaxHealth = 90000;
		zombie->mBodyHealth = 90000;
	}
}

void OnNewspaperWentMad(Zombie* zombie)
{
	if (!kEnabled || !zombie)
		return;
	// 狂暴：大幅提升移速 (abilityForm = even madder)
	if (zombie->mVelX > 0.0f)
		zombie->mVelX *= kNewspaperMadSpeedMul;
	else
		zombie->mVelX = 0.95f * kNewspaperMadSpeedMul;
}

void OnZombieUpdate(Zombie* zombie)
{
	if (!kEnabled || !zombie || zombie->mDead || !zombie->mBoard)
		return;

	LawnApp* app = zombie->mApp;
	if (!app)
		return;

	const bool abilityForm = (zombie->mBrutalForm != BRUTAL_FORM_NORMAL);

	// ===== Elite / type abilities (match Unnamed Brutal rules) =====

	// Gramophone cone: heal aura every 6.5s (3x5)
	if (zombie->mZombieType == ZombieType::ZOMBIE_TRAFFIC_CONE &&
		zombie->mBrutalForm == BRUTAL_CONE_GRAMOPHONE &&
		(app->mAppCounter % kConeHealInterval) == 0)
	{
		for (Zombie* z : zombie->mBoard->mZombies)
		{
			if (!z || z->mDead) continue;
			if (std::abs(z->mRow - zombie->mRow) > 1) continue;
			float dx = z->mPosX - zombie->mPosX;
			if (dx < -120.0f || dx > 200.0f) continue;
			// Gramophone: strong heal (near-full pulse every 6.5s in 3x5)
			if (z->mBodyMaxHealth > 0)
				z->mBodyHealth = z->mBodyMaxHealth;
			if (z->mHelmMaxHealth > 0 && z->mHelmType != HelmType::HELMTYPE_NONE)
				z->mHelmHealth = z->mHelmMaxHealth;
			if (z->mShieldMaxHealth > 0 && z->mShieldType != ShieldType::SHIELDTYPE_NONE)
				z->mShieldHealth = z->mShieldMaxHealth;
		}
	}

	// Dancing/MJ cone: dancers on DEATH only (see DieNoLoot)

	// Bucket abilityForm: gift pails to nearby bare zombies every 6.5s
	if (zombie->mZombieType == ZombieType::ZOMBIE_PAIL &&
		zombie->mBrutalForm == BRUTAL_BUCKET_ARMORER &&
		(app->mAppCounter % kConeHealInterval) == 0)
	{
		for (Zombie* z : zombie->mBoard->mZombies)
		{
			if (!z || z->mDead) continue;
			if (std::abs(z->mRow - zombie->mRow) > 1) continue;
			float dx = z->mPosX - zombie->mPosX;
			if (dx < -120.0f || dx > 200.0f) continue;
			if (z->mHelmType == HelmType::HELMTYPE_NONE &&
				(z->mZombieType == ZombieType::ZOMBIE_NORMAL || z->mZombieType == ZombieType::ZOMBIE_FLAG ||
				 z->mZombieType == ZombieType::ZOMBIE_TRAFFIC_CONE || z->mZombieType == ZombieType::ZOMBIE_NEWSPAPER ||
				 z->mZombieType == ZombieType::ZOMBIE_DOOR || z->mZombieType == ZombieType::ZOMBIE_DUCKY_TUBE))
			{
				z->mHelmType = HelmType::HELMTYPE_PAIL;
				z->mHelmMaxHealth = 1100;
				z->mHelmHealth = 1100;
			}
		}
		if (zombie->mBodyMaxHealth > 0)
			zombie->mBodyHealth = std::min(zombie->mBodyHealth + 80, zombie->mBodyMaxHealth);
		if (zombie->mHelmMaxHealth > 0)
			zombie->mHelmHealth = zombie->mHelmMaxHealth;
	}

	// Flag: drain sun while alive (stronger if abilityForm)
	if (zombie->mZombieType == ZombieType::ZOMBIE_FLAG &&
		(app->mAppCounter % kFlagSunDrainInterval) == 0)
	{
		int drain = (zombie->mBrutalForm == BRUTAL_FLAG_HORN) ? kFlagSunDrainAmount * 2 : kFlagSunDrainAmount;
		if (zombie->mBoard->mSunMoney > 0)
			zombie->mBoard->mSunMoney = std::max(0, zombie->mBoard->mSunMoney - drain);
	}

	// Zamboni (single version): slow nearby plant fire
	if (zombie->mZombieType == ZombieType::ZOMBIE_ZAMBONI &&
		(app->mAppCounter % 50) == 0)
	{
		int rowR = 1;
		float maxDx = 120.0f;
		int pad = 15;
		for (Plant* pl : zombie->mBoard->mPlants)
		{
			if (!pl || pl->mDead) continue;
			if (std::abs(pl->mRow - zombie->mRow) > rowR) continue;
			float dx = static_cast<float>(pl->mX) - zombie->mPosX;
			if (dx < -80.0f || dx > maxDx) continue;
			if (pl->mLaunchCounter > 0)
				pl->mLaunchCounter += pad;
		}
	}

	// Football abilityForm: keep sprinting harder
	if (zombie->mZombieType == ZombieType::ZOMBIE_FOOTBALL && zombie->mVelX > 0.0f)
	{
		if (zombie->mVelX < 0.85f)
			zombie->mVelX = 0.85f;
	}

	// Balloon abilityForm: stay fast in air
	if (zombie->mZombieType == ZombieType::ZOMBIE_BALLOON && zombie->mVelX > 0.0f &&
		zombie->mZombiePhase != ZombiePhase::PHASE_BALLOON_POPPING)
	{
		if (zombie->mVelX < 0.9f)
			zombie->mVelX = 0.9f;
	}

	// Snorkel / dolphin abilityForm: higher water speed
	if ((zombie->mZombieType == ZombieType::ZOMBIE_SNORKEL ||
		zombie->mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER) && zombie->mVelX > 0.0f)
	{
		zombie->mVelX = std::max(zombie->mVelX, zombie->mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER ? 0.95f : 0.7f);
	}

	// Digger abilityForm: while tunneling, damage plants above occasionally
	if (zombie->mZombieType == ZombieType::ZOMBIE_DIGGER &&
		zombie->mZombiePhase == ZombiePhase::PHASE_DIGGER_TUNNELING &&
		(app->mAppCounter % 40) == 0)
	{
		int gx = zombie->mBoard->PixelToGridX(static_cast<int>(zombie->mPosX), static_cast<int>(zombie->mPosY));
		Plant* pl = zombie->mBoard->GetTopPlantAt(gx, zombie->mRow, PlantPriority::TOPPLANT_ONLY_NORMAL_POSITION);
		if (pl && !pl->mDead)
			pl->mPlantHealth = std::max(0, pl->mPlantHealth - 40);
	}

	// Bungee abilityForm: slightly faster drop phase
	if (zombie->mZombieType == ZombieType::ZOMBIE_BUNGEE && zombie->mPhaseCounter > 5)
	{
		if (zombie->mZombiePhase == ZombiePhase::PHASE_BUNGEE_DIVING ||
			zombie->mZombiePhase == ZombiePhase::PHASE_BUNGEE_DIVING_SCREAMING)
			zombie->mPhaseCounter = std::max(1, zombie->mPhaseCounter - 1);
	}

	// Jack abilityForm: shorter fuse
	if (zombie->mZombieType == ZombieType::ZOMBIE_JACK_IN_THE_BOX &&
		zombie->mPhaseCounter > 30 && zombie->mZombiePhase == ZombiePhase::PHASE_JACK_IN_THE_BOX_RUNNING)
	{
		if ((app->mAppCounter % 10) == 0)
			zombie->mPhaseCounter = std::max(20, zombie->mPhaseCounter - 5);
	}

	// Imp abilityForm: after landing keep high speed
	if (zombie->mZombieType == ZombieType::ZOMBIE_IMP && zombie->mVelX > 0.0f)
		zombie->mVelX = std::max(zombie->mVelX, 0.65f);

	// Newspaper / Ladder: single version only

	// Door abilityForm: passive — reflect handled in Projectile::DoImpact for all doors
	// Pole abilityForm: grave on land handled in pole vault code

	// Tall-nut head: spirit regen
	if (zombie->mZombieType == ZombieType::ZOMBIE_TALLNUT_HEAD &&
		(app->mAppCounter % 50) == 0 && zombie->mBodyHealth < zombie->mBodyMaxHealth)
	{
		int regen = (zombie->mJustGotShotCounter <= 0) ? 40 : 20;
		
		zombie->mBodyHealth = std::min(zombie->mBodyHealth + regen, zombie->mBodyMaxHealth);
	}

	// Garg abilityForm: already early throw under half HP in Update; keep pressure
	// Garg: single version

	// Heisenberg secret: randomize speed for all
	if (app->mBrutalSecretId == BRUTAL_SECRET_CERTAIN && zombie->mVelX > 0.05f &&
		(app->mAppCounter % 30) == 0)
	{
		float f = 0.6f + (Sexy::Rand(80) / 100.0f);
		zombie->mVelX *= f;
	}
}


void ApplyEvoPlant(Plant* plant)
{
	if (!plant || !IsEvoTypeValid(plant->mBrutalEvoType))
		return;

	switch (plant->mBrutalEvoType)
	{
	case BrutalEvoType::SHADOW_PEASHOOTER:
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(35, plant->mLaunchRate * 3 / 4);
		break;
	case BrutalEvoType::PRIMAL_SUNFLOWER:
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(250, plant->mLaunchRate * 3 / 4);
		break;
	case BrutalEvoType::SHRAPNEL_CHERRY:
		plant->mPlantHealth = plant->mPlantMaxHealth = 450;
		break;
	case BrutalEvoType::BOWLING_WALLNUT:
		plant->mPlantHealth = plant->mPlantMaxHealth = 4500;
		break;
	case BrutalEvoType::FIRE_DRAGON:
		plant->mPlantHealth = plant->mPlantMaxHealth = 450;
		if (plant->mLaunchRate > 0) plant->mLaunchRate = 60;
		break;
	case BrutalEvoType::POISON_PUFFSHROOM:
		plant->mPlantHealth = plant->mPlantMaxHealth = 350;
		break;
	case BrutalEvoType::GOLD_SUNSHROOM:
		plant->mPlantHealth = plant->mPlantMaxHealth = 500;
		break;
	case BrutalEvoType::EVO_GRAVEBUSTER:
		plant->mPlantHealth = plant->mPlantMaxHealth = 500;
		break;
	case BrutalEvoType::EVO_HYPNOSHROOM:
		plant->mPlantHealth = plant->mPlantMaxHealth = 500;
		break;
	case BrutalEvoType::EVO_SCAREDYSHROOM:
		plant->mPlantHealth = plant->mPlantMaxHealth = 1500;
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(40, plant->mLaunchRate * 2 / 3);
		break;
	case BrutalEvoType::ENCHANTED_TALLNUT:
		plant->mPlantHealth = plant->mPlantMaxHealth = 8000;
		plant->mBrutalEvoLastHealth = plant->mPlantHealth;
		break;
	case BrutalEvoType::EVO_PLANTERN:
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(100, plant->mLaunchRate * 4 / 5);
		break;
	case BrutalEvoType::REVERSE_BLOVER:
		break;
	case BrutalEvoType::PHANTOM_STARFRUIT:
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(45, plant->mLaunchRate * 3 / 4);
		break;
	case BrutalEvoType::SHADOW_CABBAGE:
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(45, plant->mLaunchRate * 3 / 4);
		break;
	case BrutalEvoType::BUTTER_THROWER:
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(45, plant->mLaunchRate * 4 / 5);
		break;
	case BrutalEvoType::EVO_COFFEEBEAN:
		plant->mPlantHealth = plant->mPlantMaxHealth = 250;
		break;
	case BrutalEvoType::EVO_UMBRELLA:
		plant->mPlantHealth = plant->mPlantMaxHealth = 1200;
		break;
	case BrutalEvoType::EVO_GATLINGPEA:
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(25, plant->mLaunchRate * 2 / 3);
		break;
	case BrutalEvoType::EVO_GLOOMSHROOM:
		plant->mPlantHealth = plant->mPlantMaxHealth = 800;
		break;
	default:
		break;
	}
}

void OnPlantInitialized(Plant* plant)
{
	if (!kEnabled || !plant)
		return;

	switch (plant->mSeedType)
	{
	case SeedType::SEED_SCAREDYSHROOM:
		// 英雄奇迹：300 → 1500
		plant->mPlantHealth = 1500;
		plant->mPlantMaxHealth = 1500;
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(40, plant->mLaunchRate * 2 / 3);
		break;
	case SeedType::SEED_GARLIC:
		plant->mPlantHealth = static_cast<int>(plant->mPlantHealth * 1.5f);
		plant->mPlantMaxHealth = plant->mPlantHealth;
		break;
	case SeedType::SEED_POTATOMINE:
		// 极速启动：无需准备
		plant->mStateCountdown = 0;
		plant->mState = PlantState::STATE_POTATO_ARMED;
		break;
	case SeedType::SEED_SUNFLOWER:
	case SeedType::SEED_TWINSUNFLOWER:
	case SeedType::SEED_SUNSHROOM:
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = static_cast<int>(plant->mLaunchRate * 0.90f);
		break;
	case SeedType::SEED_TALLNUT:
		// already high HP in vanilla
		break;
	case SeedType::SEED_WALLNUT:
		break;
	case SeedType::SEED_COBCANNON:
		// 过载填装: faster first load / cooldown
		if (plant->mStateCountdown > 0)
			plant->mStateCountdown = std::max(100, plant->mStateCountdown / 5);
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(1000, plant->mLaunchRate * 32 / 35);
		break;
	case SeedType::SEED_CACTUS:
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(40, plant->mLaunchRate * 3 / 4);
		break;
	case SeedType::SEED_TANGLEKELP:
		plant->mLaunchCounter = 3; // 3 grabs
		break;
	case SeedType::SEED_STARFRUIT:
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(40, plant->mLaunchRate * 4 / 5);
		break;
	default:
		break;
	}

}

void OnPlantFire(Plant* plant)
{
	if (!kEnabled || !plant)
		return;

	if (plant->mBrutalEvo && plant->mBoard)
	{
		switch (plant->mBrutalEvoType)
		{
		case BrutalEvoType::SHADOW_PEASHOOTER:
			if ((++plant->mBrutalEvoCounter % 3) == 0)
				plant->DoRowAreaDamage(35, plant->GetDamageRangeFlags(PlantWeapon::WEAPON_PRIMARY));
			break;
		case BrutalEvoType::SHADOW_CABBAGE:
			if (++plant->mBrutalEvoCounter % 3 == 0)
			{
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || z->mRow != plant->mRow) continue;
					if (z->mPosX >= static_cast<float>(plant->mX) && z->mPosX <= static_cast<float>(plant->mX + 320))
						z->TakeDamage(100, 0U);
				}
			}
			if (plant->mBrutalEvoPowered)
			{
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || std::abs(z->mRow - plant->mRow) > 1) continue;
					if (z->mPosX >= static_cast<float>(plant->mX) && z->mPosX <= static_cast<float>(plant->mX + 300))
						z->TakeDamage(30, 0U);
				}
			}
			break;
		case BrutalEvoType::EVO_SCAREDYSHROOM:
			plant->DoRowAreaDamage(120, plant->GetDamageRangeFlags(PlantWeapon::WEAPON_PRIMARY));
			break;
		case BrutalEvoType::EVO_GATLINGPEA:
			break;
		case BrutalEvoType::BUTTER_THROWER:
			// Actual projectile is converted to butter in Plant::Fire.
			break;
		default:
			break;
		}
	}

	const SeedType t = plant->mSeedType;
	const bool peaFamily =
		t == SeedType::SEED_PEASHOOTER || t == SeedType::SEED_SNOWPEA ||
		t == SeedType::SEED_REPEATER || t == SeedType::SEED_GATLINGPEA ||
		t == SeedType::SEED_THREEPEATER || t == SeedType::SEED_SPLITPEA ||
		t == SeedType::SEED_LEFTPEATER || t == SeedType::SEED_CABBAGEPULT ||
		t == SeedType::SEED_KERNELPULT || t == SeedType::SEED_MELONPULT;

	if (!peaFamily)
		return;

	// 最初的梦想 / 愈战愈勇：概率提升攻速，最多 50%
	const PlantDefinition& def = GetPlantDefinition(t);
	int base = def.mLaunchRate;
	if (base <= 0)
		return;
	int minRate = static_cast<int>(base * (1.0f - kPeaMaxFireBoost));
	if (plant->mLaunchRate <= minRate)
		return;

	// boosts used approx from rate drop
	int boosts = (base - plant->mLaunchRate) * 50 / std::max(1, base - minRate);
	int chancePct = std::max(5, 100 - boosts * 2); // higher early
	if (Sexy::Rand(100) < chancePct)
	{
		plant->mLaunchRate = std::max(minRate, plant->mLaunchRate - std::max(3, base / 40));
	}
}

void OnPlantProducedSun(Plant* plant)
{
	if (!kEnabled || !plant || !plant->mBoard)
		return;

	if (plant->mBrutalEvo && plant->mBrutalEvoType == BrutalEvoType::PRIMAL_SUNFLOWER)
	{
		plant->mBoard->AddCoin(plant->mX + 18, plant->mY + 5, CoinType::COIN_SMALLSUN, CoinMotion::COIN_MOTION_FROM_PLANT);
	}

	// 阳光满屋：12% 额外小阳光
	if (plant->mSeedType == SeedType::SEED_SUNFLOWER ||
		plant->mSeedType == SeedType::SEED_TWINSUNFLOWER)
	{
		if (Sexy::Rand(100) < 12)
		{
			plant->mBoard->AddCoin(plant->mX + 10, plant->mY, CoinType::COIN_SMALLSUN,
				CoinMotion::COIN_MOTION_FROM_PLANT);
		}
	}
	// 阳光菇完全体同样
	if (plant->mSeedType == SeedType::SEED_SUNSHROOM &&
		plant->mState == PlantState::STATE_SUNSHROOM_BIG)
	{
		if (Sexy::Rand(100) < 12)
		{
			plant->mBoard->AddCoin(plant->mX + 10, plant->mY, CoinType::COIN_SMALLSUN,
				CoinMotion::COIN_MOTION_FROM_PLANT);
		}
	}
}

void OnPlantUpdate(Plant* plant)
{
	if (!kEnabled || !plant || plant->mDead || !plant->mApp)
		return;

	LawnApp* app = plant->mApp;

	if (plant->mBrutalEvo && plant->mBoard &&
		(plant->mBrutalEvoType == BrutalEvoType::SHADOW_PEASHOOTER ||
		 plant->mBrutalEvoType == BrutalEvoType::POISON_PUFFSHROOM ||
		 plant->mBrutalEvoType == BrutalEvoType::SHADOW_CABBAGE))
	{
		plant->mBrutalEvoPowered = false;
		for (Plant* other : plant->mBoard->mPlants)
		{
			if (!other || other == plant || other->mDead || !other->mBrutalEvo) continue;
			if (other->mBrutalEvoType != BrutalEvoType::EVO_PLANTERN) continue;
			if (std::abs(other->mPlantCol - plant->mPlantCol) <= 1 && std::abs(other->mRow - plant->mRow) <= 1)
			{
				plant->mBrutalEvoPowered = true;
				break;
			}
		}
	}

	if (plant->mBrutalEvo && plant->mBoard)
	{
		switch (plant->mBrutalEvoType)
		{
		case BrutalEvoType::EVO_UMBRELLA:
			if (++plant->mBrutalEvoCounter >= 300 && plant->mState == PlantState::STATE_NOTREADY)
			{
				plant->mBrutalEvoCounter = 0;
				plant->DoSpecial();
			}
			break;
		case BrutalEvoType::EVO_GATLINGPEA:
			if (++plant->mBrutalEvoCounter >= 300)
			{
				plant->mBrutalEvoCounter = 0;
				Zombie* strongest = nullptr;
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || z->mMindControlled || z->mZombieType == ZombieType::ZOMBIE_BOSS) continue;
					int hp = z->mBodyHealth + z->mHelmHealth + z->mShieldHealth;
					if (!strongest || hp > strongest->mBodyHealth + strongest->mHelmHealth + strongest->mShieldHealth) strongest = z;
				}
				if (strongest) strongest->TakeDamage(500, 0U);
			}
			break;
		case BrutalEvoType::EVO_GLOOMSHROOM:
			if (++plant->mBrutalEvoCounter >= 100)
			{
				plant->mBrutalEvoCounter = 0;
				plant->mBrutalEvoAltMode = !plant->mBrutalEvoAltMode;
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || z->mMindControlled) continue;
					if (std::abs(z->mRow - plant->mRow) <= 1 && std::abs(z->mPosX - static_cast<float>(plant->mX)) <= 220.0f)
					{
						z->TakeDamage(plant->mBrutalEvoAltMode ? 35 : 55, 0U);
						if (plant->mBrutalEvoAltMode) z->ApplyChill(false); else z->ApplyBurn();
					}
				}
			}
			break;
		case BrutalEvoType::EVO_PLANTERN:
			if ((app->mAppCounter % 90) == 0)
			{
				bool hasShadow = false;
				for (Plant* other : plant->mBoard->mPlants)
				{
					if (!other || other == plant || other->mDead || !other->mBrutalEvo) continue;
					if (std::abs(other->mPlantCol - plant->mPlantCol) > 1 || std::abs(other->mRow - plant->mRow) > 1) continue;
					if (other->mBrutalEvoType == BrutalEvoType::SHADOW_PEASHOOTER ||
						other->mBrutalEvoType == BrutalEvoType::POISON_PUFFSHROOM ||
						other->mBrutalEvoType == BrutalEvoType::SHADOW_CABBAGE)
					{
						other->mBrutalEvoPowered = true;
						hasShadow = true;
					}
				}
				plant->mBoard->AddCoin(plant->mX + 10, plant->mY, hasShadow ? CoinType::COIN_SUN : CoinType::COIN_SMALLSUN, CoinMotion::COIN_MOTION_FROM_PLANT);
			}
			break;
		case BrutalEvoType::BOWLING_WALLNUT:
			if (++plant->mBrutalEvoCounter >= 150)
			{
				plant->mBrutalEvoCounter = 0;
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || z->mRow != plant->mRow || z->mMindControlled) continue;
					float dx = z->mPosX - static_cast<float>(plant->mX);
					if (dx >= -20.0f && dx <= 360.0f)
					{
						z->TakeDamage(140, 0U);
						z->mPosX = std::min(z->mPosX + 55.0f, 780.0f);
						z->mX = static_cast<int>(z->mPosX);
					}
				}
			}
			break;
		case BrutalEvoType::FIRE_DRAGON:
			if (++plant->mBrutalEvoCounter >= 45)
			{
				plant->mBrutalEvoCounter = 0;
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || z->mRow != plant->mRow || z->mMindControlled) continue;
					float dx = z->mPosX - static_cast<float>(plant->mX);
					if (dx >= 0.0f && dx <= 190.0f)
					{
						z->TakeDamage(45, 0U);
						z->ApplyBurn();
					}
				}
			}
			break;
		case BrutalEvoType::GOLD_SUNSHROOM:
			if (++plant->mBrutalEvoCounter >= 50)
			{
				plant->mBrutalEvoCounter = 0;
				plant->mBoard->AddCoin(plant->mX + 10, plant->mY, CoinType::COIN_LARGESUN, CoinMotion::COIN_MOTION_FROM_PLANT);
				if (++plant->mBrutalEvoDamageTaken >= 3) plant->Die();
			}
			break;
		case BrutalEvoType::ENCHANTED_TALLNUT:
			if (plant->mBrutalEvoLastHealth > plant->mPlantHealth)
				plant->mBrutalEvoDamageTaken += plant->mBrutalEvoLastHealth - plant->mPlantHealth;
			plant->mBrutalEvoLastHealth = plant->mPlantHealth;
			while (plant->mBrutalEvoDamageTaken >= 1200)
			{
				plant->mBrutalEvoDamageTaken -= 1200;
				ZombieType summonType = ZombieType::ZOMBIE_NEWSPAPER;
				int roll = Sexy::Rand(3);
				if (roll == 1) summonType = ZombieType::ZOMBIE_FOOTBALL;
				else if (roll == 2) summonType = ZombieType::ZOMBIE_GARGANTUAR;
				Zombie* ally = plant->mBoard->AddZombieInRow(summonType, plant->mRow, 0);
				if (ally) ally->mMindControlled = true;
			}
			break;
		case BrutalEvoType::REVERSE_BLOVER:
			if (++plant->mBrutalEvoCounter >= 1)
			{
				plant->mBrutalEvoCounter = 0;
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || z->IsDeadOrDying() || z->mMindControlled) continue;
					z->mPosX = static_cast<float>(plant->mBoard->GridToPixelX(MAX_GRID_SIZE_X - 1, z->mRow));
					z->mX = static_cast<int>(z->mPosX);
				}
				plant->Die();
			}
			break;
		default:
			break;
		}
	}

	// 高坚果 肉体再生 75/s when not being eaten
	if (plant->mSeedType == SeedType::SEED_TALLNUT && plant->mPlantHealth > 0 &&
		plant->mPlantHealth < plant->mPlantMaxHealth && plant->mRecentlyEatenCountdown <= 0)
	{
		if ((app->mAppCounter % 10) == 0) // ~10 ticks ≈ 0.1s → +7.5 ≈ 75/s
			plant->mPlantHealth = std::min(plant->mPlantHealth + 8, plant->mPlantMaxHealth);
	}

	// 坚果 治愈心法：长时间未受伤回满
	if (plant->mSeedType == SeedType::SEED_WALLNUT && plant->mPlantHealth > 0 &&
		plant->mPlantHealth < plant->mPlantMaxHealth && plant->mRecentlyEatenCountdown <= 0)
	{
		// use mAnimCounter as idle timer proxy after last eat
		if (plant->mAnimCounter > 0 && (plant->mAnimCounter % kWallNutFullHealIdleCs) == 0)
			plant->mPlantHealth = plant->mPlantMaxHealth;
		else if ((app->mAppCounter % 60) == 0)
			plant->mPlantHealth = std::min(plant->mPlantHealth + 15, plant->mPlantMaxHealth);
	}

	// 大蒜 恶臭弥漫：周围中毒
	if (plant->mSeedType == SeedType::SEED_GARLIC && plant->mBoard &&
		(app->mAppCounter % kGarlicPoisonInterval) == 0)
	{
		for (Zombie* z : plant->mBoard->mZombies)
		{
			if (!z || z->mDead)
				continue;
			if (std::abs(z->mRow - plant->mRow) > 1)
				continue;
			float dx = z->mPosX - static_cast<float>(plant->mX);
			if (dx < -60.0f || dx > 100.0f)
				continue;
			z->TakeDamage(kGarlicPoisonDmg, 0U);
		}
	}



	// 吸金磁 暴走电流
	if (plant->mSeedType == SeedType::SEED_GOLD_MAGNET && plant->mBoard &&
		(app->mAppCounter % 40) == 0)
	{
		for (Plant* other : plant->mBoard->mPlants)
		{
			if (!other || other->mDead || other == plant) continue;
			if (other->mSeedType != SeedType::SEED_GOLD_MAGNET) continue;
			bool sameRow = other->mRow == plant->mRow;
			bool sameCol = other->mPlantCol == plant->mPlantCol;
			if (!sameRow && !sameCol) continue;
			int minC = std::min(plant->mPlantCol, other->mPlantCol);
			int maxC = std::max(plant->mPlantCol, other->mPlantCol);
			int minR = std::min(plant->mRow, other->mRow);
			int maxR = std::max(plant->mRow, other->mRow);
			for (Zombie* z : plant->mBoard->mZombies)
			{
				if (!z || z->mDead) continue;
				if (z->mZombieType == ZombieType::ZOMBIE_BOSS) continue;
				if (z->mZombiePhase == ZombiePhase::PHASE_DIGGER_TUNNELING) continue;
				int gx = plant->mBoard->PixelToGridX((int)z->mPosX, (int)z->mPosY);
				if (sameRow && z->mRow == plant->mRow && gx >= minC && gx <= maxC)
				{
					z->TakeDamage(24, 0U);
					z->ApplyChill(false);
				}
				else if (sameCol && gx == plant->mPlantCol && z->mRow >= minR && z->mRow <= maxR)
				{
					z->TakeDamage(24, 0U);
					z->ApplyChill(false);
				}
			}
		}
	}

	// 路灯花 黎明斗志: nearby shooters fire faster
	if (plant->mSeedType == SeedType::SEED_PLANTERN && plant->mBoard &&
		(app->mAppCounter % 100) == 0)
	{
		for (Plant* other : plant->mBoard->mPlants)
		{
			if (!other || other->mDead || other == plant)
				continue;
			if (std::abs(other->mRow - plant->mRow) > 1)
				continue;
			float dx = static_cast<float>(other->mX) - static_cast<float>(plant->mX);
			if (dx < -120.0f || dx > 120.0f)
				continue;
			if (other->mLaunchRate > 40)
				other->mLaunchRate = std::max(40, other->mLaunchRate * 9 / 10);
		}
	}

	// Marigold combat pulse (portable extra)
	if (plant->mSeedType == SeedType::SEED_MARIGOLD && plant->mBoard &&
		(app->mAppCounter % 200) == 0 && Sexy::Rand(1000) < 80)
	{
		for (Zombie* z : plant->mBoard->mZombies)
		{
			if (!z || z->mDead)
				continue;
			if (z->mRow < plant->mRow - 1 || z->mRow > plant->mRow + 1)
				continue;
			float dx = z->mPosX - static_cast<float>(plant->mX);
			if (dx < -80.0f || dx > 120.0f)
				continue;
			int dmg = std::max(50, z->mBodyMaxHealth / 4);
			z->TakeDamage(dmg, 0U);
		}
	}
}

void OnZombieEatPlant(Zombie* zombie, Plant* plant)
{
	if (!kEnabled || !zombie || !plant)
		return;

	if (plant->mBrutalEvo && plant->mBoard)
	{
		if (plant->mBrutalEvoType == BrutalEvoType::POISON_PUFFSHROOM)
		{
			zombie->TakeDamage(180, 0U);
			zombie->ApplyChill(false);
		}
		else if (plant->mBrutalEvoType == BrutalEvoType::EVO_HYPNOSHROOM)
		{
			zombie->mMindControlled = true;
			for (Zombie* other : plant->mBoard->mZombies)
			{
				if (!other || other == zombie || other->mDead || std::abs(other->mRow - zombie->mRow) > 1) continue;
				if (std::abs(other->mPosX - zombie->mPosX) <= 80.0f && Sexy::Rand(100) < 20)
					other->mMindControlled = true;
			}
		}
	}

	// 高坚果 反伤荆棘
	if (plant->mSeedType == SeedType::SEED_TALLNUT)
		zombie->TakeDamage(kTallNutThornDmg, 0U);

	// Secret Air Raid: shove plant back / delete
	if (zombie->mApp && zombie->mApp->mBrutalSecretId == BRUTAL_SECRET_ESCAPE && plant->mBoard)
	{
		if (Sexy::Rand(100) < 40)
		{
			plant->mX = std::max(0, plant->mX - 40);
			plant->mPlantCol = plant->mBoard->PixelToGridX(plant->mX, plant->mY);
			if (plant->mPlantCol < 0)
				plant->Die();
		}
	}
}

int GetShooterLaunchRate(Plant* plant, int baseRate)
{
	if (!kEnabled || !plant || baseRate <= 0)
		return baseRate;
	// already modified mLaunchRate via OnPlantFire stacks
	// Keep firing stable (Wikipedia plants still shoot; stacks only speed them up a bit)
	int rate = plant->mLaunchRate > 0 ? plant->mLaunchRate : baseRate;
	return std::max(55, std::min(baseRate, rate));
}

int GetChomperDigestTicks(int swallowedBodyHealth)
{
	if (!kEnabled)
		return 4000;
	// Unnamed: T = 2h+1000 (h<=1500) else h/2+3250
	int h = std::max(0, swallowedBodyHealth);
	if (h <= 1500)
		return 2 * h + 1000;
	return h / 2 + 3250;
}

float GetWaveHealthTriggerMul()
{
	return kEnabled ? kWaveHealthTriggerMul : 1.0f;
}

int GetExtraZombiesPerWave()
{
	return kEnabled ? kExtraZombiesPerWave : 0;
}

} // namespace BrutalMode
