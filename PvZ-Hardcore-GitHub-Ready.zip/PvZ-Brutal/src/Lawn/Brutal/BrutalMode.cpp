#include "BrutalMode.h"
#include "BrutalSecrets.h"
#include "../../LawnApp.h"
#include "../Zombie.h"
#include "../Board.h"
#include "../Plant.h"
#include "../../ConstEnums.h"
#include "../../LawnApp.h"
#include "../../SexyAppFramework/Common.h"
#include <algorithm>

namespace BrutalMode
{

int BrutalZombieForm(Zombie* z) { return z ? z->mBrutalForm : 0; }


static void ScaleHP(int& cur, int& maxv, float mul)
{
	if (maxv > 0)
	{
		maxv = static_cast<int>(maxv * mul + 0.5f);
		cur = maxv;
	}
	else if (cur > 0)
	{
		cur = static_cast<int>(cur * mul + 0.5f);
		maxv = cur;
	}
}

void ApplyToZombie(Zombie* zombie)
{
	if (!kEnabled || !zombie)
		return;

	const bool isBoss = (zombie->mZombieType == ZombieType::ZOMBIE_BOSS);
	float healthMul = isBoss ? 1.30f : kZombieHealthMul;
	float speedMul = isBoss ? 1.0f : kZombieSpeedMul;

	// Secret: Giant Trouble
	if (zombie->mApp && zombie->mApp->mBrutalSecretId == BRUTAL_SECRET_GIANT && !isBoss)
	{
		healthMul *= 4.0f;
		speedMul *= 0.5f;
		zombie->mScaleZombie *= 2.0f;
	}
	// Secret: Heisenberg — speed jitter
	if (zombie->mApp && zombie->mApp->mBrutalSecretId == BRUTAL_SECRET_CERTAIN && !isBoss)
	{
		speedMul *= (0.7f + (Sexy::Rand(60) / 100.0f));
	}

	switch (zombie->mZombieType)
	{
	case ZombieType::ZOMBIE_TRAFFIC_CONE:
		healthMul *= 1.15f;
		break;
	case ZombieType::ZOMBIE_PAIL:
		healthMul *= 1.25f;
		speedMul *= 0.90f; // Unnamed bucket abilityForm slower / tankier
		break;
	case ZombieType::ZOMBIE_DOOR:
		healthMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_FOOTBALL:
		healthMul *= 1.35f;
		speedMul *= kFootballSpeedMul;
		break;
	case ZombieType::ZOMBIE_GARGANTUAR:
	case ZombieType::ZOMBIE_REDEYE_GARGANTUAR:
		healthMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_NEWSPAPER:
		healthMul *= 1.30f;
		break;
	case ZombieType::ZOMBIE_POLEVAULTER:
		speedMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_FLAG:
		healthMul *= 1.40f; // 大动员
		break;
	case ZombieType::ZOMBIE_POGO:
		speedMul *= 1.15f;
		break;
	case ZombieType::ZOMBIE_BALLOON:
		healthMul *= 1.40f; // resists Blover — needs more hits
		speedMul *= 1.25f;
		break;
	case ZombieType::ZOMBIE_DOLPHIN_RIDER:
		speedMul *= 1.25f;
		break;
	case ZombieType::ZOMBIE_SNORKEL:
		speedMul *= 1.15f;
		break;
	case ZombieType::ZOMBIE_ZAMBONI:
		healthMul *= 1.30f;
		speedMul *= 1.10f; // 一往无前 feel
		break;
	case ZombieType::ZOMBIE_CATAPULT:
		// HP set after ScaleHP to 90000 while balls remain (see below)
		break;
	case ZombieType::ZOMBIE_DIGGER:
		healthMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_BUNGEE:
		healthMul *= 1.50f;
		break;
	case ZombieType::ZOMBIE_IMP:
		speedMul *= 1.20f;
		break;
	case ZombieType::ZOMBIE_PEA_HEAD:
		// 全副武装: cone helm
		healthMul *= 1.25f;
		break;
	case ZombieType::ZOMBIE_WALLNUT_HEAD:
		healthMul *= 1.50f;
		break;
	case ZombieType::ZOMBIE_JALAPENO_HEAD:
		healthMul *= 1.35f;
		break;
	case ZombieType::ZOMBIE_GATLING_HEAD:
		healthMul *= 1.40f;
		break;
	case ZombieType::ZOMBIE_SQUASH_HEAD:
		healthMul *= 1.35f;
		break;
	case ZombieType::ZOMBIE_TALLNUT_HEAD:
		healthMul *= 1.60f;
		break;
	default:
		break;
	}


	ScaleHP(zombie->mBodyHealth, zombie->mBodyMaxHealth, healthMul);
	ScaleHP(zombie->mHelmHealth, zombie->mHelmMaxHealth, healthMul);
	ScaleHP(zombie->mShieldHealth, zombie->mShieldMaxHealth, healthMul);
	ScaleHP(zombie->mFlyingHealth, zombie->mFlyingMaxHealth, healthMul);

	if (zombie->mVelX > 0.0f)
		zombie->mVelX *= speedMul;

	// ===== Exactly 2 forms where split: NORMAL + ability (never 3) =====
	// Cone: Normal | Gramophone healer
	// Bucket: Normal | Armorer (gift pails)
	// Flag: Normal | Night Horn (extra sun drain)
	// Basic/Ducky: Normal | Letterhead (2x HP, normal speed)
	// Dancer / others: single Brutal-tuned behavior (no second form)
	zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
	zombie->mVariant = false;
	if (!isBoss)
	{
		const int roll = Sexy::Rand(100);
		switch (zombie->mZombieType)
		{
		case ZombieType::ZOMBIE_TRAFFIC_CONE:
			// Unnamed: Normal | Gramophone (heal) | Dancing/MJ (death → dancers)
			if (roll < 45)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else if (roll < 75)
			{
				zombie->mBrutalForm = BRUTAL_CONE_GRAMOPHONE;
				zombie->mVariant = true;
			}
			else
			{
				zombie->mBrutalForm = BRUTAL_CONE_DANCING;
				zombie->mVariant = true;
			}
			break;
		case ZombieType::ZOMBIE_PAIL:
			if (roll < 65)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else
			{
				zombie->mBrutalForm = BRUTAL_BUCKET_ARMORER;
				zombie->mVariant = true;
			}
			break;
		case ZombieType::ZOMBIE_FLAG:
			if (roll < 60)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else
			{
				zombie->mBrutalForm = BRUTAL_FLAG_HORN;
				zombie->mVariant = true;
			}
			break;
		case ZombieType::ZOMBIE_NORMAL:
			// Unnamed Letterhead: tougher, NOT 2x speed
			if (roll < 89)
				zombie->mBrutalForm = BRUTAL_FORM_NORMAL;
			else
			{
				zombie->mBrutalForm = BRUTAL_BASIC_LETTERHEAD;
				zombie->mVariant = true;
				ScaleHP(zombie->mBodyHealth, zombie->mBodyMaxHealth, 2.0f);
				if (zombie->mVelX > 0.0f) zombie->mVelX *= 4.0f;
			}
			break;
		case ZombieType::ZOMBIE_DANCER:
			zombie->mVariant = true; // single MJ-style form
			break;
		default:
			break;
		}
	}

	// Original Brutal Mode Zombotany equipment (Beta 5.40 footage notes):
	// Peashooter, Wall-nut, Squash and Tall-nut heads carry screen doors;
	// Gatling Pea and Squash heads carry buckets; Jalapeno heads carry cones.
	// Do not give every plant-headed zombie the same generic cone/door combo.
	const bool hasOriginalScreenDoor =
		zombie->mZombieType == ZombieType::ZOMBIE_PEA_HEAD ||
		zombie->mZombieType == ZombieType::ZOMBIE_WALLNUT_HEAD ||
		zombie->mZombieType == ZombieType::ZOMBIE_SQUASH_HEAD ||
		zombie->mZombieType == ZombieType::ZOMBIE_TALLNUT_HEAD;
	if (hasOriginalScreenDoor)
	{
		zombie->mShieldType = ShieldType::SHIELDTYPE_DOOR;
		zombie->mShieldMaxHealth = 1100;
		zombie->mShieldHealth = 1100;
	}

	const bool hasBucketHelmet =
		zombie->mZombieType == ZombieType::ZOMBIE_GATLING_HEAD ||
		zombie->mZombieType == ZombieType::ZOMBIE_SQUASH_HEAD;
	if (hasBucketHelmet && zombie->mHelmType == HelmType::HELMTYPE_NONE)
	{
		zombie->mHelmType = HelmType::HELMTYPE_PAIL;
		zombie->mHelmMaxHealth = 1100;
		zombie->mHelmHealth = 1100;
	}

	if (zombie->mZombieType == ZombieType::ZOMBIE_JALAPENO_HEAD && zombie->mHelmType == HelmType::HELMTYPE_NONE)
	{
		zombie->mHelmType = HelmType::HELMTYPE_TRAFFIC_CONE;
		zombie->mHelmMaxHealth = 370;
		zombie->mHelmHealth = 370;
	}

	if (zombie->mZombieType == ZombieType::ZOMBIE_TALLNUT_HEAD)
	{
		// 魂灵再生 handled in OnZombieUpdate
		zombie->mBodyMaxHealth = static_cast<int>(zombie->mBodyMaxHealth * 1.2f);
		zombie->mBodyHealth = zombie->mBodyMaxHealth;
	}

	// Catapult: 90k HP while balls remain; drops to normal when empty
	if (zombie->mZombieType == ZombieType::ZOMBIE_CATAPULT)
	{
		zombie->mBodyMaxHealth = 90000;
		zombie->mBodyHealth = 90000;
	}
}

void OnNewspaperWentMad(Zombie* zombie)
{
	if (!kEnabled || !zombie)
		return;
	// 狂暴：大幅提升移速 (abilityForm = even madder)
	if (zombie->mVelX > 0.0f)
		zombie->mVelX *= kNewspaperMadSpeedMul;
	else
		zombie->mVelX = 0.95f * kNewspaperMadSpeedMul;
}

void OnZombieUpdate(Zombie* zombie)
{
	if (!kEnabled || !zombie || zombie->mDead || !zombie->mBoard)
		return;

	LawnApp* app = zombie->mApp;
	if (!app)
		return;

	const bool abilityForm = (zombie->mBrutalForm != BRUTAL_FORM_NORMAL);

	// ===== Elite / type abilities (match Unnamed Brutal rules) =====

	// Gramophone cone: heal aura every 6.5s (3x5)
	if (zombie->mZombieType == ZombieType::ZOMBIE_TRAFFIC_CONE &&
		zombie->mBrutalForm == BRUTAL_CONE_GRAMOPHONE &&
		(app->mAppCounter % kConeHealInterval) == 0)
	{
		for (Zombie* z : zombie->mBoard->mZombies)
		{
			if (!z || z->mDead) continue;
			if (std::abs(z->mRow - zombie->mRow) > 1) continue;
			float dx = z->mPosX - zombie->mPosX;
			if (dx < -120.0f || dx > 200.0f) continue;
			// Gramophone: strong heal (near-full pulse every 6.5s in 3x5)
			if (z->mBodyMaxHealth > 0)
				z->mBodyHealth = z->mBodyMaxHealth;
			if (z->mHelmMaxHealth > 0 && z->mHelmType != HelmType::HELMTYPE_NONE)
				z->mHelmHealth = z->mHelmMaxHealth;
			if (z->mShieldMaxHealth > 0 && z->mShieldType != ShieldType::SHIELDTYPE_NONE)
				z->mShieldHealth = z->mShieldMaxHealth;
		}
	}

	// Dancing/MJ cone: dancers on DEATH only (see DieNoLoot)

	// Bucket abilityForm: gift pails to nearby bare zombies every 6.5s
	if (zombie->mZombieType == ZombieType::ZOMBIE_PAIL &&
		zombie->mBrutalForm == BRUTAL_BUCKET_ARMORER &&
		(app->mAppCounter % kConeHealInterval) == 0)
	{
		for (Zombie* z : zombie->mBoard->mZombies)
		{
			if (!z || z->mDead) continue;
			if (std::abs(z->mRow - zombie->mRow) > 1) continue;
			float dx = z->mPosX - zombie->mPosX;
			if (dx < -120.0f || dx > 200.0f) continue;
			if (z->mHelmType == HelmType::HELMTYPE_NONE &&
				(z->mZombieType == ZombieType::ZOMBIE_NORMAL || z->mZombieType == ZombieType::ZOMBIE_FLAG ||
				 z->mZombieType == ZombieType::ZOMBIE_TRAFFIC_CONE || z->mZombieType == ZombieType::ZOMBIE_NEWSPAPER ||
				 z->mZombieType == ZombieType::ZOMBIE_DOOR || z->mZombieType == ZombieType::ZOMBIE_DUCKY_TUBE))
			{
				z->mHelmType = HelmType::HELMTYPE_PAIL;
				z->mHelmMaxHealth = 1100;
				z->mHelmHealth = 1100;
			}
		}
		if (zombie->mBodyMaxHealth > 0)
			zombie->mBodyHealth = std::min(zombie->mBodyHealth + 80, zombie->mBodyMaxHealth);
		if (zombie->mHelmMaxHealth > 0)
			zombie->mHelmHealth = zombie->mHelmMaxHealth;
	}

	// Flag: drain sun while alive (stronger if abilityForm)
	if (zombie->mZombieType == ZombieType::ZOMBIE_FLAG &&
		(app->mAppCounter % kFlagSunDrainInterval) == 0)
	{
		int drain = (zombie->mBrutalForm == BRUTAL_FLAG_HORN) ? kFlagSunDrainAmount * 2 : kFlagSunDrainAmount;
		if (zombie->mBoard->mSunMoney > 0)
			zombie->mBoard->mSunMoney = std::max(0, zombie->mBoard->mSunMoney - drain);
	}

	// Zamboni (single version): slow nearby plant fire
	if (zombie->mZombieType == ZombieType::ZOMBIE_ZAMBONI &&
		(app->mAppCounter % 50) == 0)
	{
		int rowR = 1;
		float maxDx = 120.0f;
		int pad = 15;
		for (Plant* pl : zombie->mBoard->mPlants)
		{
			if (!pl || pl->mDead) continue;
			if (std::abs(pl->mRow - zombie->mRow) > rowR) continue;
			float dx = static_cast<float>(pl->mX) - zombie->mPosX;
			if (dx < -80.0f || dx > maxDx) continue;
			if (pl->mLaunchCounter > 0)
				pl->mLaunchCounter += pad;
		}
	}

	// Football abilityForm: keep sprinting harder
	if (zombie->mZombieType == ZombieType::ZOMBIE_FOOTBALL && zombie->mVelX > 0.0f)
	{
		if (zombie->mVelX < 0.85f)
			zombie->mVelX = 0.85f;
	}

	// Balloon abilityForm: stay fast in air
	if (zombie->mZombieType == ZombieType::ZOMBIE_BALLOON && zombie->mVelX > 0.0f &&
		zombie->mZombiePhase != ZombiePhase::PHASE_BALLOON_POPPING)
	{
		if (zombie->mVelX < 0.9f)
			zombie->mVelX = 0.9f;
	}

	// Snorkel / dolphin abilityForm: higher water speed
	if ((zombie->mZombieType == ZombieType::ZOMBIE_SNORKEL ||
		zombie->mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER) && zombie->mVelX > 0.0f)
	{
		zombie->mVelX = std::max(zombie->mVelX, zombie->mZombieType == ZombieType::ZOMBIE_DOLPHIN_RIDER ? 0.95f : 0.7f);
	}

	// Digger abilityForm: while tunneling, damage plants above occasionally
	if (zombie->mZombieType == ZombieType::ZOMBIE_DIGGER &&
		zombie->mZombiePhase == ZombiePhase::PHASE_DIGGER_TUNNELING &&
		(app->mAppCounter % 40) == 0)
	{
		int gx = zombie->mBoard->PixelToGridX(static_cast<int>(zombie->mPosX), static_cast<int>(zombie->mPosY));
		Plant* pl = zombie->mBoard->GetTopPlantAt(gx, zombie->mRow, PlantPriority::TOPPLANT_ONLY_NORMAL_POSITION);
		if (pl && !pl->mDead)
			pl->mPlantHealth = std::max(0, pl->mPlantHealth - 40);
	}

	// Bungee abilityForm: slightly faster drop phase
	if (zombie->mZombieType == ZombieType::ZOMBIE_BUNGEE && zombie->mPhaseCounter > 5)
	{
		if (zombie->mZombiePhase == ZombiePhase::PHASE_BUNGEE_DIVING ||
			zombie->mZombiePhase == ZombiePhase::PHASE_BUNGEE_DIVING_SCREAMING)
			zombie->mPhaseCounter = std::max(1, zombie->mPhaseCounter - 1);
	}

	// Jack abilityForm: shorter fuse
	if (zombie->mZombieType == ZombieType::ZOMBIE_JACK_IN_THE_BOX &&
		zombie->mPhaseCounter > 30 && zombie->mZombiePhase == ZombiePhase::PHASE_JACK_IN_THE_BOX_RUNNING)
	{
		if ((app->mAppCounter % 10) == 0)
			zombie->mPhaseCounter = std::max(20, zombie->mPhaseCounter - 5);
	}

	// Imp abilityForm: after landing keep high speed
	if (zombie->mZombieType == ZombieType::ZOMBIE_IMP && zombie->mVelX > 0.0f)
		zombie->mVelX = std::max(zombie->mVelX, 0.65f);

	// Newspaper / Ladder: single version only

	// Door abilityForm: passive — reflect handled in Projectile::DoImpact for all doors
	// Pole abilityForm: grave on land handled in pole vault code

	// Tall-nut head: spirit regen
	if (zombie->mZombieType == ZombieType::ZOMBIE_TALLNUT_HEAD &&
		(app->mAppCounter % 50) == 0 && zombie->mBodyHealth < zombie->mBodyMaxHealth)
	{
		int regen = (zombie->mJustGotShotCounter <= 0) ? 40 : 20;
		
		zombie->mBodyHealth = std::min(zombie->mBodyHealth + regen, zombie->mBodyMaxHealth);
	}

	// Garg abilityForm: already early throw under half HP in Update; keep pressure
	// Garg: single version

	// Heisenberg secret: randomize speed for all
	if (app->mBrutalSecretId == BRUTAL_SECRET_CERTAIN && zombie->mVelX > 0.05f &&
		(app->mAppCounter % 30) == 0)
	{
		float f = 0.6f + (Sexy::Rand(80) / 100.0f);
		zombie->mVelX *= f;
	}
}


void ApplyEvoPlant(Plant* plant)
{
	if (!plant || !plant->mBrutalEvo)
		return;

	// The Unnamed Evo roster is a small subset, not every vanilla plant.
	// Resolve Imitater to its copied plant. Do not apply a blanket stat buff to
	// plants for which no Evo variant is documented.
	const SeedType t = plant->mSeedType == SeedType::SEED_IMITATER ? plant->mImitaterType : plant->mSeedType;
	switch (t)
	{
	case SeedType::SEED_PEASHOOTER: // Evo Peashooter: quicker launch; snow projectile selected in Plant::Fire.
	case SeedType::SEED_CABBAGEPULT: // Evo Cabbage-pult: attack speed profile; splash/power state handled separately.
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(30, plant->mLaunchRate * 2 / 3);
		break;
	case SeedType::SEED_SUNFLOWER: // Evo Sunflower's first production is accelerated.
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(400, plant->mLaunchRate * 2 / 3);
		break;
	case SeedType::SEED_SCAREDYSHROOM:
		plant->mPlantHealth = plant->mPlantMaxHealth = 1500;
		if (plant->mLaunchRate > 0) plant->mLaunchRate = std::max(30, plant->mLaunchRate * 2 / 3);
		break;
	case SeedType::SEED_KERNELPULT: // butter selection is forced in Plant::UpdateShooter.
	case SeedType::SEED_CHERRYBOMB:
	case SeedType::SEED_WALLNUT:
	case SeedType::SEED_CHOMPER:
	case SeedType::SEED_PUFFSHROOM:
	case SeedType::SEED_SUNSHROOM:
	case SeedType::SEED_GRAVEBUSTER:
	case SeedType::SEED_HYPNOSHROOM:
	case SeedType::SEED_TALLNUT:
	case SeedType::SEED_PLANTERN:
	case SeedType::SEED_BLOVER:
	case SeedType::SEED_STARFRUIT:
	case SeedType::SEED_INSTANT_COFFEE:
	case SeedType::SEED_UMBRELLA:
	case SeedType::SEED_GATLINGPEA:
	case SeedType::SEED_GLOOMSHROOM:
		break; // effects use their normal per-frame / projectile hooks, never fake generic stats.
	default:
		break;
	}
}

void OnPlantInitialized(Plant* plant)
{
	if (!kEnabled || !plant)
		return;

	if (plant->mBrutalEvo && plant->mBoard)
	{
		const SeedType evoType = plant->mSeedType == SeedType::SEED_IMITATER ? plant->mImitaterType : plant->mSeedType;
		if (evoType == SeedType::SEED_SUNSHROOM)
		{
			// Gold-Bloom-like burst. The plant still follows its normal sunshroom lifecycle.
			plant->mBoard->AddSunMoney(100 + Sexy::Rand(101));
		}
		else if (evoType == SeedType::SEED_BLOVER)
		{
			// Evo Hurrikale: return living zombies to the far-right column and heal them.
			for (Zombie* z : plant->mBoard->mZombies)
			{
				if (!z || z->mDead || z->IsDeadOrDying()) continue;
				z->mPosX = static_cast<float>(plant->mBoard->GridToPixelX(MAX_GRID_SIZE_X - 1, z->mRow));
				z->mX = static_cast<int>(z->mPosX);
				if (z->mBodyMaxHealth > 0) z->mBodyHealth = z->mBodyMaxHealth;
				if (z->mHelmMaxHealth > 0 && z->mHelmType != HelmType::HELMTYPE_NONE) z->mHelmHealth = z->mHelmMaxHealth;
				if (z->mShieldMaxHealth > 0 && z->mShieldType != ShieldType::SHIELDTYPE_NONE) z->mShieldHealth = z->mShieldMaxHealth;
			}
		}
	}

	switch (plant->mSeedType)
	{
	case SeedType::SEED_SCAREDYSHROOM:
		// 英雄奇迹：300 → 1500
		plant->mPlantHealth = 1500;
		plant->mPlantMaxHealth = 1500;
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(40, plant->mLaunchRate * 2 / 3);
		break;
	case SeedType::SEED_GARLIC:
		plant->mPlantHealth = static_cast<int>(plant->mPlantHealth * 1.5f);
		plant->mPlantMaxHealth = plant->mPlantHealth;
		break;
	case SeedType::SEED_POTATOMINE:
		// 极速启动：无需准备
		plant->mStateCountdown = 0;
		plant->mState = PlantState::STATE_POTATO_ARMED;
		break;
	case SeedType::SEED_SUNFLOWER:
	case SeedType::SEED_TWINSUNFLOWER:
	case SeedType::SEED_SUNSHROOM:
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = static_cast<int>(plant->mLaunchRate * 0.90f);
		break;
	case SeedType::SEED_TALLNUT:
		// already high HP in vanilla
		break;
	case SeedType::SEED_WALLNUT:
		break;
	case SeedType::SEED_COBCANNON:
		// 过载填装: faster first load / cooldown
		if (plant->mStateCountdown > 0)
			plant->mStateCountdown = std::max(100, plant->mStateCountdown / 5);
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(1000, plant->mLaunchRate * 32 / 35);
		break;
	case SeedType::SEED_CACTUS:
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(40, plant->mLaunchRate * 3 / 4);
		break;
	case SeedType::SEED_TANGLEKELP:
		plant->mLaunchCounter = 3; // 3 grabs
		break;
	case SeedType::SEED_STARFRUIT:
		if (plant->mLaunchRate > 0)
			plant->mLaunchRate = std::max(40, plant->mLaunchRate * 4 / 5);
		break;
	default:
		break;
	}

}

void OnPlantFire(Plant* plant)
{
	if (!kEnabled || !plant)
		return;

	const SeedType t = plant->mSeedType;
	const bool peaFamily =
		t == SeedType::SEED_PEASHOOTER || t == SeedType::SEED_SNOWPEA ||
		t == SeedType::SEED_REPEATER || t == SeedType::SEED_GATLINGPEA ||
		t == SeedType::SEED_THREEPEATER || t == SeedType::SEED_SPLITPEA ||
		t == SeedType::SEED_LEFTPEATER || t == SeedType::SEED_CABBAGEPULT ||
		t == SeedType::SEED_KERNELPULT || t == SeedType::SEED_MELONPULT;

	if (!peaFamily)
		return;

	// 最初的梦想 / 愈战愈勇：概率提升攻速，最多 50%
	const PlantDefinition& def = GetPlantDefinition(t);
	int base = def.mLaunchRate;
	if (base <= 0)
		return;
	int minRate = static_cast<int>(base * (1.0f - kPeaMaxFireBoost));
	if (plant->mLaunchRate <= minRate)
		return;

	// boosts used approx from rate drop
	int boosts = (base - plant->mLaunchRate) * 50 / std::max(1, base - minRate);
	int chancePct = std::max(5, 100 - boosts * 2); // higher early
	if (Sexy::Rand(100) < chancePct)
	{
		plant->mLaunchRate = std::max(minRate, plant->mLaunchRate - std::max(3, base / 40));
	}
}

void OnPlantProducedSun(Plant* plant)
{
	if (!kEnabled || !plant || !plant->mBoard)
		return;

	// 阳光满屋：12% 额外小阳光
	if (plant->mSeedType == SeedType::SEED_SUNFLOWER ||
		plant->mSeedType == SeedType::SEED_TWINSUNFLOWER)
	{
		if (Sexy::Rand(100) < 12)
		{
			plant->mBoard->AddCoin(plant->mX + 10, plant->mY, CoinType::COIN_SMALLSUN,
				CoinMotion::COIN_MOTION_FROM_PLANT);
		}
	}
	// 阳光菇完全体同样
	if (plant->mSeedType == SeedType::SEED_SUNSHROOM &&
		plant->mState == PlantState::STATE_SUNSHROOM_BIG)
	{
		if (Sexy::Rand(100) < 12)
		{
			plant->mBoard->AddCoin(plant->mX + 10, plant->mY, CoinType::COIN_SMALLSUN,
				CoinMotion::COIN_MOTION_FROM_PLANT);
		}
	}
}

void OnPlantUpdate(Plant* plant)
{
	if (!kEnabled || !plant || plant->mDead || !plant->mApp)
		return;

	LawnApp* app = plant->mApp;

	if (plant->mBrutalEvo && plant->mBoard)
	{
		const SeedType evoType = plant->mSeedType == SeedType::SEED_IMITATER ? plant->mImitaterType : plant->mSeedType;
		if (evoType == SeedType::SEED_GATLINGPEA)
		{
			if (++plant->mBrutalEvoCounter >= 300)
			{
				plant->mBrutalEvoCounter = 0;
				Zombie* target = nullptr;
				for (Zombie* z : plant->mBoard->mZombies)
				{
					if (!z || z->mDead || z->IsDeadOrDying() || z->mMindControlled) continue;
					int total = std::max(0, z->mBodyHealth) + std::max(0, z->mHelmHealth) + std::max(0, z->mShieldHealth);
					int best = target ? std::max(0, target->mBodyHealth) + std::max(0, target->mHelmHealth) + std::max(0, target->mShieldHealth) : -1;
					if (!target || total > best) target = z;
				}
				if (target) target->TakeDamage(500, 0U);
			}
		}
		if (evoType == SeedType::SEED_TALLNUT)
		{
			if (plant->mBrutalEvoLastHealth > plant->mPlantHealth)
				plant->mBrutalEvoDamageTaken += plant->mBrutalEvoLastHealth - plant->mPlantHealth;
			plant->mBrutalEvoLastHealth = plant->mPlantHealth;
			while (plant->mBrutalEvoDamageTaken >= 1200)
			{
				plant->mBrutalEvoDamageTaken -= 1200;
				ZombieType summonType = ZombieType::ZOMBIE_NEWSPAPER;
				int roll = Sexy::Rand(3);
				if (roll == 1) summonType = ZombieType::ZOMBIE_FOOTBALL;
				else if (roll == 2) summonType = ZombieType::ZOMBIE_GARGANTUAR;
				Zombie* ally = plant->mBoard->AddZombieInRow(summonType, plant->mRow, 0);
				if (ally) ally->mMindControlled = true;
			}
		}
	}

	// 高坚果 肉体再生 75/s when not being eaten
	if (plant->mSeedType == SeedType::SEED_TALLNUT && plant->mPlantHealth > 0 &&
		plant->mPlantHealth < plant->mPlantMaxHealth && plant->mRecentlyEatenCountdown <= 0)
	{
		if ((app->mAppCounter % 10) == 0) // ~10 ticks ≈ 0.1s → +7.5 ≈ 75/s
			plant->mPlantHealth = std::min(plant->mPlantHealth + 8, plant->mPlantMaxHealth);
	}

	// 坚果 治愈心法：长时间未受伤回满
	if (plant->mSeedType == SeedType::SEED_WALLNUT && plant->mPlantHealth > 0 &&
		plant->mPlantHealth < plant->mPlantMaxHealth && plant->mRecentlyEatenCountdown <= 0)
	{
		// use mAnimCounter as idle timer proxy after last eat
		if (plant->mAnimCounter > 0 && (plant->mAnimCounter % kWallNutFullHealIdleCs) == 0)
			plant->mPlantHealth = plant->mPlantMaxHealth;
		else if ((app->mAppCounter % 60) == 0)
			plant->mPlantHealth = std::min(plant->mPlantHealth + 15, plant->mPlantMaxHealth);
	}

	// 大蒜 恶臭弥漫：周围中毒
	if (plant->mSeedType == SeedType::SEED_GARLIC && plant->mBoard &&
		(app->mAppCounter % kGarlicPoisonInterval) == 0)
	{
		for (Zombie* z : plant->mBoard->mZombies)
		{
			if (!z || z->mDead)
				continue;
			if (std::abs(z->mRow - plant->mRow) > 1)
				continue;
			float dx = z->mPosX - static_cast<float>(plant->mX);
			if (dx < -60.0f || dx > 100.0f)
				continue;
			z->TakeDamage(kGarlicPoisonDmg, 0U);
		}
	}



	// 吸金磁 暴走电流
	if (plant->mSeedType == SeedType::SEED_GOLD_MAGNET && plant->mBoard &&
		(app->mAppCounter % 40) == 0)
	{
		for (Plant* other : plant->mBoard->mPlants)
		{
			if (!other || other->mDead || other == plant) continue;
			if (other->mSeedType != SeedType::SEED_GOLD_MAGNET) continue;
			bool sameRow = other->mRow == plant->mRow;
			bool sameCol = other->mPlantCol == plant->mPlantCol;
			if (!sameRow && !sameCol) continue;
			int minC = std::min(plant->mPlantCol, other->mPlantCol);
			int maxC = std::max(plant->mPlantCol, other->mPlantCol);
			int minR = std::min(plant->mRow, other->mRow);
			int maxR = std::max(plant->mRow, other->mRow);
			for (Zombie* z : plant->mBoard->mZombies)
			{
				if (!z || z->mDead) continue;
				if (z->mZombieType == ZombieType::ZOMBIE_BOSS) continue;
				if (z->mZombiePhase == ZombiePhase::PHASE_DIGGER_TUNNELING) continue;
				int gx = plant->mBoard->PixelToGridX((int)z->mPosX, (int)z->mPosY);
				if (sameRow && z->mRow == plant->mRow && gx >= minC && gx <= maxC)
				{
					z->TakeDamage(24, 0U);
					z->ApplyChill(false);
				}
				else if (sameCol && gx == plant->mPlantCol && z->mRow >= minR && z->mRow <= maxR)
				{
					z->TakeDamage(24, 0U);
					z->ApplyChill(false);
				}
			}
		}
	}

	// 路灯花 黎明斗志: nearby shooters fire faster
	if (plant->mSeedType == SeedType::SEED_PLANTERN && plant->mBoard &&
		(app->mAppCounter % 100) == 0)
	{
		for (Plant* other : plant->mBoard->mPlants)
		{
			if (!other || other->mDead || other == plant)
				continue;
			if (std::abs(other->mRow - plant->mRow) > 1)
				continue;
			float dx = static_cast<float>(other->mX) - static_cast<float>(plant->mX);
			if (dx < -120.0f || dx > 120.0f)
				continue;
			if (other->mLaunchRate > 40)
				other->mLaunchRate = std::max(40, other->mLaunchRate * 9 / 10);
		}
	}

	// Marigold combat pulse (portable extra)
	if (plant->mSeedType == SeedType::SEED_MARIGOLD && plant->mBoard &&
		(app->mAppCounter % 200) == 0 && Sexy::Rand(1000) < 80)
	{
		for (Zombie* z : plant->mBoard->mZombies)
		{
			if (!z || z->mDead)
				continue;
			if (z->mRow < plant->mRow - 1 || z->mRow > plant->mRow + 1)
				continue;
			float dx = z->mPosX - static_cast<float>(plant->mX);
			if (dx < -80.0f || dx > 120.0f)
				continue;
			int dmg = std::max(50, z->mBodyMaxHealth / 4);
			z->TakeDamage(dmg, 0U);
		}
	}
}

void OnZombieEatPlant(Zombie* zombie, Plant* plant)
{
	if (!kEnabled || !zombie || !plant)
		return;

	// 高坚果 反伤荆棘
	if (plant->mSeedType == SeedType::SEED_TALLNUT)
		zombie->TakeDamage(kTallNutThornDmg, 0U);

	// Secret Air Raid: shove plant back / delete
	if (zombie->mApp && zombie->mApp->mBrutalSecretId == BRUTAL_SECRET_ESCAPE && plant->mBoard)
	{
		if (Sexy::Rand(100) < 40)
		{
			plant->mX = std::max(0, plant->mX - 40);
			plant->mPlantCol = plant->mBoard->PixelToGridX(plant->mX, plant->mY);
			if (plant->mPlantCol < 0)
				plant->Die();
		}
	}
}

int GetShooterLaunchRate(Plant* plant, int baseRate)
{
	if (!kEnabled || !plant || baseRate <= 0)
		return baseRate;
	// already modified mLaunchRate via OnPlantFire stacks
	// Keep firing stable (Wikipedia plants still shoot; stacks only speed them up a bit)
	int rate = plant->mLaunchRate > 0 ? plant->mLaunchRate : baseRate;
	return std::max(55, std::min(baseRate, rate));
}

int GetChomperDigestTicks(int swallowedBodyHealth)
{
	if (!kEnabled)
		return 4000;
	// Unnamed: T = 2h+1000 (h<=1500) else h/2+3250
	int h = std::max(0, swallowedBodyHealth);
	if (h <= 1500)
		return 2 * h + 1000;
	return h / 2 + 3250;
}

float GetWaveHealthTriggerMul()
{
	return kEnabled ? kWaveHealthTriggerMul : 1.0f;
}

int GetExtraZombiesPerWave()
{
	return kEnabled ? kExtraZombiesPerWave : 0;
}

// Explicit original-Brutal plant economy profile. Every real PlantDefinition is
// covered below; zero-cost utility plants remain free when that is their base rule.
// The deliberately expensive high-impact plants are balanced against cheaper
// alternatives, and the Imitater pays a small surcharge on its copied plant.
int GetBalancedPlantCost(SeedType theSeedType, int baseCost, bool isImitater)
{
	if (!kEnabled) return baseCost;
	int cost = baseCost;
	switch (theSeedType)
	{
	case SeedType::SEED_PEASHOOTER: cost = 125; break;
	case SeedType::SEED_SUNFLOWER: cost = 75; break;
	case SeedType::SEED_CHERRYBOMB: cost = 175; break;
	case SeedType::SEED_WALLNUT: cost = 75; break;
	case SeedType::SEED_POTATOMINE: cost = 75; break;
	case SeedType::SEED_SNOWPEA: cost = 200; break;
	case SeedType::SEED_CHOMPER: cost = 125; break;
	case SeedType::SEED_REPEATER: cost = 225; break;
	case SeedType::SEED_PUFFSHROOM: cost = 0; break; // remains the free early defender
	case SeedType::SEED_SUNSHROOM: cost = 50; break;
	case SeedType::SEED_FUMESHROOM: cost = 125; break;
	case SeedType::SEED_GRAVEBUSTER: cost = 50; break;
	case SeedType::SEED_HYPNOSHROOM: cost = 125; break;
	case SeedType::SEED_SCAREDYSHROOM: cost = 100; break;
	case SeedType::SEED_ICESHROOM: cost = 100; break;
	case SeedType::SEED_DOOMSHROOM: cost = 200; break;
	case SeedType::SEED_LILYPAD: cost = 50; break;
	case SeedType::SEED_SQUASH: cost = 75; break;
	case SeedType::SEED_THREEPEATER: cost = 300; break;
	case SeedType::SEED_TANGLEKELP: cost = 75; break;
	case SeedType::SEED_JALAPENO: cost = 150; break;
	case SeedType::SEED_SPIKEWEED: cost = 150; break;
	case SeedType::SEED_TORCHWOOD: cost = 200; break;
	case SeedType::SEED_TALLNUT: cost = 150; break;
	case SeedType::SEED_SEASHROOM: cost = 0; break; // remains free, but its recharge is tuned below
	case SeedType::SEED_PLANTERN: cost = 125; break;
	case SeedType::SEED_CACTUS: cost = 150; break;
	case SeedType::SEED_BLOVER: cost = 150; break;
	case SeedType::SEED_SPLITPEA: cost = 150; break;
	case SeedType::SEED_STARFRUIT: cost = 200; break;
	case SeedType::SEED_PUMPKINSHELL: cost = 225; break;
	case SeedType::SEED_MAGNETSHROOM: cost = 100; break;
	case SeedType::SEED_CABBAGEPULT: cost = 125; break;
	case SeedType::SEED_FLOWERPOT: cost = 50; break;
	case SeedType::SEED_KERNELPULT: cost = 125; break;
	case SeedType::SEED_INSTANT_COFFEE: cost = 100; break;
	case SeedType::SEED_GARLIC: cost = 75; break;
	case SeedType::SEED_UMBRELLA: cost = 125; break;
	case SeedType::SEED_MARIGOLD: cost = 200; break;
	case SeedType::SEED_MELONPULT: cost = 350; break;
	case SeedType::SEED_GATLINGPEA: cost = 300; break;
	case SeedType::SEED_TWINSUNFLOWER: cost = 200; break;
	case SeedType::SEED_GLOOMSHROOM: cost = 175; break;
	case SeedType::SEED_CATTAIL: cost = 250; break;
	case SeedType::SEED_WINTERMELON: cost = 275; break;
	case SeedType::SEED_GOLD_MAGNET: cost = 75; break;
	case SeedType::SEED_SPIKEROCK: cost = 175; break;
	case SeedType::SEED_COBCANNON: cost = 600; break;
	case SeedType::SEED_IMITATER: cost = baseCost; break; // normally resolved to the copied plant
	case SeedType::SEED_EXPLODE_O_NUT: cost = baseCost; break; // bowling-only special plant
	case SeedType::SEED_GIANT_WALLNUT: cost = baseCost; break; // bowling-only special plant
	case SeedType::SEED_SPROUT: cost = baseCost; break; // Zen Garden growth item, not a battle seed
	case SeedType::SEED_LEFTPEATER: cost = 175; break;
	default: break;
	}
	if (isImitater) cost += 25;
	return std::max(0, cost);
}

// Cooldown profile covers all defined plant types and intentionally varies by role:
// reliable basics cycle faster, economy and instant-clear plants take longer, and
// several underused utility plants become more practical. Values are engine ticks.
int GetBalancedPlantRefreshTime(SeedType theSeedType, int baseRefreshTime, bool isImitater)
{
	if (!kEnabled) return baseRefreshTime;
	int refresh = baseRefreshTime;
	switch (theSeedType)
	{
	case SeedType::SEED_PEASHOOTER: refresh = 650; break;
	case SeedType::SEED_SUNFLOWER: refresh = 900; break;
	case SeedType::SEED_CHERRYBOMB: refresh = 5500; break;
	case SeedType::SEED_WALLNUT: refresh = 2700; break;
	case SeedType::SEED_POTATOMINE: refresh = 2500; break;
	case SeedType::SEED_SNOWPEA: refresh = 900; break;
	case SeedType::SEED_CHOMPER: refresh = 650; break;
	case SeedType::SEED_REPEATER: refresh = 900; break;
	case SeedType::SEED_PUFFSHROOM: refresh = 600; break;
	case SeedType::SEED_SUNSHROOM: refresh = 900; break;
	case SeedType::SEED_FUMESHROOM: refresh = 900; break;
	case SeedType::SEED_GRAVEBUSTER: refresh = 600; break;
	case SeedType::SEED_HYPNOSHROOM: refresh = 3500; break;
	case SeedType::SEED_SCAREDYSHROOM: refresh = 650; break;
	case SeedType::SEED_ICESHROOM: refresh = 5500; break;
	case SeedType::SEED_DOOMSHROOM: refresh = 6000; break;
	case SeedType::SEED_LILYPAD: refresh = 600; break;
	case SeedType::SEED_SQUASH: refresh = 2500; break;
	case SeedType::SEED_THREEPEATER: refresh = 900; break;
	case SeedType::SEED_TANGLEKELP: refresh = 2500; break;
	case SeedType::SEED_JALAPENO: refresh = 5500; break;
	case SeedType::SEED_SPIKEWEED: refresh = 900; break;
	case SeedType::SEED_TORCHWOOD: refresh = 900; break;
	case SeedType::SEED_TALLNUT: refresh = 3500; break;
	case SeedType::SEED_SEASHROOM: refresh = 2500; break;
	case SeedType::SEED_PLANTERN: refresh = 2500; break;
	case SeedType::SEED_CACTUS: refresh = 650; break;
	case SeedType::SEED_BLOVER: refresh = 900; break;
	case SeedType::SEED_SPLITPEA: refresh = 700; break;
	case SeedType::SEED_STARFRUIT: refresh = 900; break;
	case SeedType::SEED_PUMPKINSHELL: refresh = 3500; break;
	case SeedType::SEED_MAGNETSHROOM: refresh = 700; break;
	case SeedType::SEED_CABBAGEPULT: refresh = 700; break;
	case SeedType::SEED_FLOWERPOT: refresh = 600; break;
	case SeedType::SEED_KERNELPULT: refresh = 700; break;
	case SeedType::SEED_INSTANT_COFFEE: refresh = 900; break;
	case SeedType::SEED_GARLIC: refresh = 650; break;
	case SeedType::SEED_UMBRELLA: refresh = 900; break;
	case SeedType::SEED_MARIGOLD: refresh = 2500; break;
	case SeedType::SEED_MELONPULT: refresh = 900; break;
	case SeedType::SEED_GATLINGPEA: refresh = 6000; break;
	case SeedType::SEED_TWINSUNFLOWER: refresh = 5500; break;
	case SeedType::SEED_GLOOMSHROOM: refresh = 6000; break;
	case SeedType::SEED_CATTAIL: refresh = 6000; break;
	case SeedType::SEED_WINTERMELON: refresh = 6500; break;
	case SeedType::SEED_GOLD_MAGNET: refresh = 4500; break;
	case SeedType::SEED_SPIKEROCK: refresh = 5500; break;
	case SeedType::SEED_COBCANNON: refresh = 6500; break;
	case SeedType::SEED_IMITATER: refresh = baseRefreshTime; break; // resolved before call
	case SeedType::SEED_EXPLODE_O_NUT: refresh = 2500; break;
	case SeedType::SEED_GIANT_WALLNUT: refresh = 3500; break;
	case SeedType::SEED_SPROUT: refresh = baseRefreshTime; break;
	case SeedType::SEED_LEFTPEATER: refresh = 700; break;
	default: break;
	}
	if (isImitater) refresh += 750;
	return std::max(0, refresh);
}

} // namespace BrutalMode
