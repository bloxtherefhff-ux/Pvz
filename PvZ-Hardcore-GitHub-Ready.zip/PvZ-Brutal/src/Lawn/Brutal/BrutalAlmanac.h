#pragma once
#include <string>
#include "../../ConstEnums.h"

// Brutal skill lines appended in Almanac
std::string BrutalPlantAlmanacExtra(SeedType seed);
std::string BrutalZombieAlmanacExtra(ZombieType type);
