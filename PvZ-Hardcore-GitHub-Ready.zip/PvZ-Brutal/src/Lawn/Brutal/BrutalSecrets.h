#pragma once
#include <string>

// Unnamed 1.1.0 secret-level ids (mechanical approximations)
enum BrutalSecretId : int
{
	BRUTAL_SECRET_NONE = 0,
	BRUTAL_SECRET_STORM = 1,      // 阳光风暴
	BRUTAL_SECRET_CLOSE = 2,      // 请勿戏水
	BRUTAL_SECRET_LONG = 3,       // 持久战
	BRUTAL_SECRET_VISUAL = 4,     // 视觉失调
	BRUTAL_SECRET_ESCAPE = 5,     // 法国进口植物 / 空袭
	BRUTAL_SECRET_FRIGHT = 6,     // 黑夜惊魂
	BRUTAL_SECRET_SINGLE = 7,     // 单枪匹马
	BRUTAL_SECRET_SLOT = 8,       // 卡槽危机
	BRUTAL_SECRET_OVERCAST = 9,   // 阴雨天
	BRUTAL_SECRET_CERTAIN = 10,   // 海森堡的僵尸
	BRUTAL_SECRET_GUARDIAN = 11,  // 隐形守护者
	BRUTAL_SECRET_GIANT = 12,     // 大僵尸小麻烦
	BRUTAL_SECRET_REPRISAL = 13,  // 以牙还牙
	BRUTAL_SECRET_COUNT
};

struct BrutalSecretInfo
{
	BrutalSecretId id;
	const char* code;   // short id for cheats
	const char* title;
	const char* desc;
	int startLevel;     // adventure level to load (1-50)
};

const BrutalSecretInfo* BrutalSecretGetInfo(int id);
int BrutalSecretCount();
// Parse name codes: "11" -> level 1-1, "53" -> 5-3. Returns level or -1.
int BrutalParseNameLevelCode(const std::string& name);

class Board;
void BrutalSecretApplyToBoard(Board* board);
