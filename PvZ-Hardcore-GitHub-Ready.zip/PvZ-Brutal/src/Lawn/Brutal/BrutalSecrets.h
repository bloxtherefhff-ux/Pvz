#pragma once
#include <string>
#include "../../ConstEnums.h"

// Unnamed-style secret ids — mechanical + map onto real minigame modes when possible
enum BrutalSecretId : int
{
	BRUTAL_SECRET_NONE = 0,
	BRUTAL_SECRET_STORM = 1,      // Sunshine Storm → stormy night
	BRUTAL_SECRET_CLOSE = 2,      // No Swimming → pool level 3-1
	BRUTAL_SECRET_LONG = 3,       // War of Attrition
	BRUTAL_SECRET_VISUAL = 4,     // Visual Distortion → invisighoul
	BRUTAL_SECRET_ESCAPE = 5,     // Air Raid → air raid challenge
	BRUTAL_SECRET_FRIGHT = 6,     // Night Fright → grave danger
	BRUTAL_SECRET_SINGLE = 7,     // Lone Gun — 3 slots
	BRUTAL_SECRET_SLOT = 8,       // Slot Crisis → slot machine
	BRUTAL_SECRET_OVERCAST = 9,   // Overcast — no sky sun
	BRUTAL_SECRET_CERTAIN = 10,   // Heisenberg
	BRUTAL_SECRET_GUARDIAN = 11,  // Invisible Guardians → invisighoul hard
	BRUTAL_SECRET_GIANT = 12,     // Giant Trouble
	BRUTAL_SECRET_REPRISAL = 13,  // Zomboss pressure
	BRUTAL_SECRET_COUNT
};

struct BrutalSecretInfo
{
	BrutalSecretId id;
	const char* code;
	const char* title;
	const char* desc;
	int startLevel;           // adventure level 1-50 if using adventure
	GameMode challengeMode;   // NUM_GAME_MODES = use adventure with modifiers only
};

const BrutalSecretInfo* BrutalSecretGetInfo(int id);
int BrutalSecretCount();
int BrutalParseNameLevelCode(const std::string& name);

class Board;
void BrutalSecretApplyToBoard(Board* board);
// Call after seed bank exists (StartLevel) so slot secrets stick
void BrutalSecretApplyLate(Board* board);
