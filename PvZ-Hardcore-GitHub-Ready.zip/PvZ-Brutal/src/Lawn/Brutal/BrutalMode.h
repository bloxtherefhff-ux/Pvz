/*
 * PvZ Brutal Mode — portable reimplementation of Unnamed 1.1.0 skill *rules*
 * (from 改版内容详解.xlsx). Not the Unnamed EXE; different code, same ideas.
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */
#pragma once

class Zombie;
class Board;
class Plant;

namespace BrutalMode
{
// Brutal Mod zombie forms (mBrutalForm; separate from portal state). Source: Brutal Mod / 无名版 skill lists.
// Cone: 0 normal, 1 Gramophone (healer), 2 Dancing/MJ (death dancers)
// Bucket: 0 normal, 1 Pumpkin/Armorer (gift pails)
// Flag: 0 normal, 1 Night Horn (strong drain) — always mild drain in Brutal
// Basic: 0 normal, 1 Letterhead (tougher HP, ignores plants; NOT 2x speed)
constexpr int BRUTAL_FORM_NORMAL = 0;
constexpr int BRUTAL_CONE_GRAMOPHONE = 1;
constexpr int BRUTAL_CONE_DANCING = 2;
constexpr int BRUTAL_BUCKET_ARMORER = 1;
constexpr int BRUTAL_FLAG_HORN = 1;
constexpr int BRUTAL_BASIC_LETTERHEAD = 1;
// Generic "has extra skill" for types with only one special form
constexpr int BRUTAL_FORM_ABILITY = 1;
// BrutalZombieForm defined in .cpp (needs full Zombie type)
int BrutalZombieForm(Zombie* z);

	constexpr bool kEnabled = true;

	// Global pressure (always on)
	constexpr float kZombieHealthMul = 1.85f; // unchanged — zombie body rules stay
	constexpr float kZombieSpeedMul = 1.25f;
	constexpr float kWaveHealthTriggerMul = 0.28f; // waves pile on much sooner
	constexpr int   kExtraZombiesPerWave = 12; // ~4x denser pads per PutZombieInWave
	constexpr int   kMaxZombiesInWave = 50; // must be <= Board.h MAX_ZOMBIES_IN_WAVE
	constexpr int   kEliteChancePercent = 12;
	constexpr float kEliteHealthMul = 1.40f;
	constexpr float kEliteSpeedMul = 1.15f;

	// Unnamed plant rules (approx)
	constexpr int kChomperDigestBase = 1000;
	constexpr int kTallNutHealPerSec = 75;      // 肉体再生
	constexpr int kTallNutThornDmg = 15;        // 反伤
	constexpr int kWallNutFullHealIdleCs = 4800; // 治愈心法 ~48s
	constexpr int kGarlicPoisonInterval = 40;
	constexpr int kGarlicPoisonDmg = 2;
	constexpr int kConeHealInterval = 650;      // 6.5s
	constexpr int kConeHealAmount = 50;
	constexpr int kFlagSunDrainInterval = 50;
	constexpr int kFlagSunDrainAmount = 5;
	constexpr float kNewspaperMadSpeedMul = 1.70f;
	constexpr float kFootballSpeedMul = 1.40f;
	constexpr float kPeaMaxFireBoost = 0.50f;   // 最多提升50%
	constexpr int kPotatoNoPrep = 1;            // 极速启动

	void ApplyToZombie(Zombie* zombie);
	void OnNewspaperWentMad(Zombie* zombie);
	void OnZombieUpdate(Zombie* zombie);
	void OnPlantInitialized(Plant* plant);
	void ApplyEvoPlant(Plant* plant);
	void OnPlantFire(Plant* plant);
	void OnPlantProducedSun(Plant* plant);
	void OnPlantUpdate(Plant* plant);
	void OnZombieEatPlant(Zombie* zombie, Plant* plant);
	int  GetShooterLaunchRate(Plant* plant, int baseRate);
	int  GetChomperDigestTicks(int swallowedBodyHealth);
	float GetWaveHealthTriggerMul();
	int  GetExtraZombiesPerWave();
}
