#pragma once

#include "LawnDialog.h"

class BrutalEvoDialog : public LawnDialog
{
public:
	BrutalEvoDialog();
	~BrutalEvoDialog() override = default;

	int HitTest(int x, int y) const;
	void Draw(Graphics* g) override;
	void MouseDown(int x, int y, int theClickCount) override;
	void KeyDown(KeyCode theKey) override;
};
