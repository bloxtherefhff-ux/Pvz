#include "BrutalPickDialog.h"
#include "../../LawnApp.h"
#include "../Brutal/BrutalSecrets.h"
#include "GameButton.h"
#include "../../ConstEnums.h"
#include "widget/WidgetManager.h"

BrutalPickDialog::BrutalPickDialog(LawnApp* theApp, BrutalPickMode mode)
	: LawnDialog(theApp, Dialogs::DIALOG_BRUTAL_PICK, true,
		mode == BrutalPickMode::Secrets ? "SECRETS — TAP ONE" : "CHEATS — TAP ONE",
		"", "", Dialog::BUTTONS_NONE)
	, mApp(theApp)
	, mMode(mode)
{
	mVerticalCenterText = false;

	auto addBtn = [this](int id, const std::string& label)
	{
		mButtons.push_back(MakeButton(id, this, label));
	};

	if (mMode == BrutalPickMode::Cheats)
	{
		addBtn(Btn_InfSun, "Infinite Sun");
		addBtn(Btn_NoCd, "No Cooldown");
		addBtn(Btn_Coins, "Max Coins");
		addBtn(Btn_Skip, "Skip Level");
		addBtn(Btn_Unlock, "Unlock Modes");
		addBtn(Btn_Best, "Beat Everything");
		// level shortcuts
		addBtn(Btn_SecretBase + 100, "Jump 1-1");
		addBtn(Btn_SecretBase + 101, "Jump 2-1");
		addBtn(Btn_SecretBase + 102, "Jump 3-1");
		addBtn(Btn_SecretBase + 103, "Jump 4-1");
		addBtn(Btn_SecretBase + 104, "Jump 5-1");
	}
	else
	{
		for (int i = 1; i <= BrutalSecretCount(); i++)
		{
			const BrutalSecretInfo* info = BrutalSecretGetInfo(i);
			if (!info) continue;
			std::string lab = std::to_string(i) + ". " + info->title;
			addBtn(Btn_SecretBase + i, lab);
		}
	}
	addBtn(Btn_Close, "Close");
	if (mMode == BrutalPickMode::Secrets)
		CalcSize(360, 320);
	else
		CalcSize(300, 20 + (int)mButtons.size() * 42);
}

BrutalPickDialog::~BrutalPickDialog() = default;

void BrutalPickDialog::AddedToManager(Sexy::WidgetManager* theWidgetManager)
{
	LawnDialog::AddedToManager(theWidgetManager);
	for (auto& b : mButtons)
		AddWidget(b.get());
}

void BrutalPickDialog::RemovedFromManager(Sexy::WidgetManager* theWidgetManager)
{
	for (auto& b : mButtons)
		RemoveWidget(b.get());
	LawnDialog::RemovedFromManager(theWidgetManager);
}

void BrutalPickDialog::Resize(int theX, int theY, int theWidth, int theHeight)
{
	LawnDialog::Resize(theX, theY, theWidth, theHeight);
	const int top = 48;
	const int bh = 34;
	const int gap = 6;
	if (mMode == BrutalPickMode::Secrets && mButtons.size() > 8)
	{
		// two columns so all secrets fit on phone
		int cols = 2;
		int colW = (mWidth - 50) / cols;
		int n = (int)mButtons.size();
		// last button is Close — full width at bottom
		for (int i = 0; i < n; i++)
		{
			if (i == n - 1)
			{
				mButtons[i]->Resize(20, mHeight - 50, mWidth - 40, 36);
				continue;
			}
			int col = i % cols;
			int row = i / cols;
			mButtons[i]->Resize(20 + col * (colW + 10), top + row * (bh + gap), colW, bh);
		}
	}
	else
	{
		int y = top;
		int w = mWidth - 40;
		for (auto& b : mButtons)
		{
			b->Resize(20, y, w, bh);
			y += bh + gap;
		}
	}
}

void BrutalPickDialog::ButtonDepress(int theId)
{
	if (theId == Btn_Close)
	{
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	}

	if (mMode == BrutalPickMode::Cheats)
	{
		switch (theId)
		{
		case Btn_InfSun:
			mApp->BrutalEnableInGameCheats(true, false, false);
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_NoCd:
			mApp->BrutalEnableInGameCheats(false, true, true);
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Coins:
			if (mApp->mPlayerInfo)
			{
				mApp->mPlayerInfo->AddCoins(99999);
				mApp->WriteCurrentUserConfig();
			}
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Skip:
		{
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			if (!mApp->mPlayerInfo) return;
			int lvl = mApp->mPlayerInfo->GetLevel() + 1;
			if (lvl > 50) lvl = 50;
			mApp->mPlayerInfo->SetLevel(lvl);
			mApp->mPlayerInfo->mFinishedAdventure = 0;
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			mApp->mBrutalCheatJump = true;
			mApp->WriteCurrentUserConfig();
			mApp->BrutalSafeRestartAdventure();
			return;
		}
		case Btn_Unlock:
			if (mApp->mPlayerInfo)
			{
				mApp->mPlayerInfo->mHasUnlockedMinigames = 1;
				mApp->mPlayerInfo->mHasUnlockedPuzzleMode = 1;
				mApp->mPlayerInfo->mHasUnlockedSurvivalMode = 1;
				mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
				mApp->WriteCurrentUserConfig();
			}
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Best:
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->BrutalBeatEverything();
			return;
		default:
			break;
		}
		// Jump area starts: Btn_SecretBase+100 = 1-1, +101 = 2-1 ...
		if (theId >= Btn_SecretBase + 100 && theId <= Btn_SecretBase + 104)
		{
			int area = theId - (Btn_SecretBase + 100) + 1;
			int lvl = (area - 1) * 10 + 1;
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			if (!mApp->mPlayerInfo) return;
			mApp->mPlayerInfo->SetLevel(lvl);
			mApp->mPlayerInfo->mFinishedAdventure = 0;
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			mApp->mBrutalCheatJump = true;
			mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
			mApp->WriteCurrentUserConfig();
			mApp->BrutalSafeRestartAdventure();
			return;
		}
	}
	else
	{
		// secret pick
		int sid = theId - Btn_SecretBase;
		const BrutalSecretInfo* info = BrutalSecretGetInfo(sid);
		if (info && mApp->mPlayerInfo)
		{
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			int slvl = info->startLevel;
			if (slvl < 1) slvl = 1;
			if (slvl > 50) slvl = 50;
			mApp->mBrutalSecretId = sid;
			mApp->mPlayerInfo->SetLevel(slvl);
			mApp->mPlayerInfo->mFinishedAdventure = 0;
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			mApp->mBrutalCheatJump = true;
			mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
			mApp->WriteCurrentUserConfig();
			mApp->BrutalSafeRestartAdventure();
			return;
		}
	}
}
