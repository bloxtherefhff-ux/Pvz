#include "BrutalPickDialog.h"
#include "../../LawnApp.h"
#include "../System/PlayerInfo.h"
#include "../Brutal/BrutalSecrets.h"
#include "GameButton.h"
#include "../../ConstEnums.h"
#include "widget/WidgetManager.h"
#include "../Zombie.h"
#include <cctype>

BrutalPickDialog::BrutalPickDialog(LawnApp* theApp, BrutalPickMode mode)
	: LawnDialog(theApp, Dialogs::DIALOG_BRUTAL_PICK, true,
		mode == BrutalPickMode::Secrets ? "SECRETS — TAP ONE" : (mode == BrutalPickMode::Admin ? "ADMIN — SPAWN ZOMBIE" : "CHEATS — TAP ONE"),
		"", "", Dialog::BUTTONS_NONE)
	, mApp(theApp)
	, mMode(mode)
{
	mVerticalCenterText = false;

	auto addBtn = [this](int id, const std::string& label)
	{
		mButtons.push_back(MakeButton(id, this, label));
	};

	if (mMode == BrutalPickMode::Admin)
	{
		static const char* zombieNames[NUM_ZOMBIE_TYPES] = {
			"Normal", "Flag", "Conehead", "Pole Vaulter", "Buckethead", "Newspaper", "Screen Door", "Football",
			"Dancer", "Backup Dancer", "Ducky Tube", "Snorkel", "Zamboni", "Bobsled Team", "Dolphin Rider",
			"Jack-in-the-Box", "Balloon", "Digger", "Pogo", "Yeti", "Bungee", "Ladder", "Catapult",
			"Gargantuar", "Imp", "Dr. Zomboss", "Pea Head", "Wall-nut Head", "Jalapeno Head", "Gatling Head",
			"Squash Head", "Tall-nut Head", "Red-eye Gargantuar"
		};
		for (int i = 0; i < NUM_ZOMBIE_TYPES; ++i)
			addBtn(Btn_AdminBase + i, zombieNames[i]);
	}
	else if (mMode == BrutalPickMode::Cheats)
	{
		addBtn(Btn_InfSun, "Infinite Sun");
		addBtn(Btn_NoCd, "No Cooldown");
		addBtn(Btn_Coins, "Max Coins");
		addBtn(Btn_Skip, "Skip Level");
		addBtn(Btn_Unlock, "Unlock Modes");
		addBtn(Btn_Best, "Beat Everything");
		addBtn(Btn_Evo, "Evo Plants ON/OFF");
	}
	else
	{
		for (int i = 1; i <= BrutalSecretCount(); i++)
		{
			const BrutalSecretInfo* info = BrutalSecretGetInfo(i);
			if (!info) continue;
			std::string lab = std::to_string(i) + ". " + info->title;
			addBtn(Btn_SecretBase + i, lab);
		}
	}
	addBtn(Btn_Close, "Close");
	if (mMode == BrutalPickMode::Secrets)
		CalcSize(360, 320);
	else if (mMode == BrutalPickMode::Admin)
		CalcSize(520, 560);
	else
		CalcSize(300, 20 + (int)mButtons.size() * 42);
}

BrutalPickDialog::~BrutalPickDialog() = default;

void BrutalPickDialog::AddedToManager(Sexy::WidgetManager* theWidgetManager)
{
	LawnDialog::AddedToManager(theWidgetManager);
	for (auto& b : mButtons)
		AddWidget(b.get());
}

void BrutalPickDialog::RemovedFromManager(Sexy::WidgetManager* theWidgetManager)
{
	for (auto& b : mButtons)
		RemoveWidget(b.get());
	LawnDialog::RemovedFromManager(theWidgetManager);
}

void BrutalPickDialog::Resize(int theX, int theY, int theWidth, int theHeight)
{
	LawnDialog::Resize(theX, theY, theWidth, theHeight);
	const int top = 48;
	const int bh = 34;
	const int gap = 6;
	if ((mMode == BrutalPickMode::Secrets || mMode == BrutalPickMode::Admin) && mButtons.size() > 8)
	{
		// Three columns for the admin zombie catalogue keep the whole picker usable on phones.
		const int cols = (mMode == BrutalPickMode::Admin) ? 3 : 2;
		const int colW = (mWidth - 50) / cols;
		const int n = (int)mButtons.size();
		for (int i = 0; i < n; i++)
		{
			if (i == n - 1)
			{
				mButtons[i]->Resize(20, mHeight - 46, mWidth - 40, 36);
				continue;
			}
			const int col = i % cols;
			const int row = i / cols;
			mButtons[i]->Resize(20 + col * (colW + 5), top + row * (bh + gap), colW, bh);
		}
	}
	else
	{
		int y = top;
		int w = mWidth - 40;
		for (auto& b : mButtons)
		{
			b->Resize(20, y, w, bh);
			y += bh + gap;
		}
	}
}

void BrutalPickDialog::ButtonDepress(int theId)
{
	if (theId == Btn_Close)
	{
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	}

	if (mMode == BrutalPickMode::Admin)
	{
		const int zombieIndex = theId - Btn_AdminBase;
		if (zombieIndex >= 0 && zombieIndex < NUM_ZOMBIE_TYPES && mApp->mPlayerInfo)
		{
			mApp->mBrutalAdminZombieToSpawn = zombieIndex;
			mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
			int level = mApp->mPlayerInfo->GetLevel();
			if (level < 1 || level > 70) level = 1;
			mApp->mPlayerInfo->SetLevel(level);
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			mApp->WriteCurrentUserConfig();
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->BrutalSafeRestartAdventure();
		}
		return;
	}
	if (mMode == BrutalPickMode::Cheats)
	{
		switch (theId)
		{
		case Btn_InfSun:
			mApp->BrutalEnableInGameCheats(true, false, false);
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_NoCd:
			mApp->BrutalEnableInGameCheats(false, true, true);
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Coins:
			if (mApp->mPlayerInfo)
			{
				mApp->mPlayerInfo->AddCoins(99999);
				mApp->WriteCurrentUserConfig();
			}
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Skip:
		{
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			if (!mApp->mPlayerInfo) return;
			int lvl = mApp->mPlayerInfo->GetLevel() + 1;
			if (lvl > 70) lvl = 70;
			mApp->mPlayerInfo->SetLevel(lvl);
			mApp->mPlayerInfo->mFinishedAdventure = 0;
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			mApp->mBrutalCheatJump = true;
			mApp->WriteCurrentUserConfig();
			mApp->BrutalSafeRestartAdventure();
			return;
		}
		case Btn_Unlock:
			if (mApp->mPlayerInfo)
			{
				mApp->mPlayerInfo->mHasUnlockedMinigames = 1;
				mApp->mPlayerInfo->mHasUnlockedPuzzleMode = 1;
				mApp->mPlayerInfo->mHasUnlockedSurvivalMode = 1;
				mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
				mApp->WriteCurrentUserConfig();
			}
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Best:
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->BrutalBeatEverything();
			return;
		case Btn_Evo:
			mApp->mBrutalEvoPlanting = !mApp->mBrutalEvoPlanting;
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->DoDialog(Dialogs::DIALOG_INFO, true, "Evo Plants",
				mApp->mBrutalEvoPlanting
					? "EVO ON — next plants use Evo rules (same art, stronger)."
					: "EVO OFF — normal plants.",
				"[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return;
		default:
			break;
		}

	}
	else
	{
		// secret pick — start real minigame OR modified adventure
		int sid = theId - Btn_SecretBase;
		const BrutalSecretInfo* info = BrutalSecretGetInfo(sid);
		if (!info || !mApp->mPlayerInfo)
			return;

		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		mApp->mBrutalSecretId = sid;
		mApp->mBrutalCheatJump = true;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mPlayerInfo->mFinishedAdventure = 0;

		if (info->challengeMode != GameMode::NUM_GAME_MODES)
		{
			// Hidden minigame-style secret (like original PvZ bonus games)
			mApp->mGameMode = info->challengeMode;
		}
		else
		{
			int slvl = info->startLevel;
			if (slvl < 1) slvl = 1;
			if (slvl > 70) slvl = 70;
			mApp->mPlayerInfo->SetLevel(slvl);
			mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
		}
		mApp->WriteCurrentUserConfig();
		mApp->BrutalSafeRestartAdventure();
	}
}

