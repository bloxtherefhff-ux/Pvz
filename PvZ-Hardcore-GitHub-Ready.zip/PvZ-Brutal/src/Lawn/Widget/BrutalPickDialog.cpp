#include "BrutalPickDialog.h"
#include "../../LawnApp.h"
#include "../System/PlayerInfo.h"
#include "../Brutal/BrutalSecrets.h"
#include "GameButton.h"
#include "../../ConstEnums.h"
#include "../Board.h"
#include "../Zombie.h"
#include "widget/WidgetManager.h"

BrutalPickDialog::BrutalPickDialog(LawnApp* theApp, BrutalPickMode mode)
	: LawnDialog(theApp, Dialogs::DIALOG_BRUTAL_PICK, true,
		mode == BrutalPickMode::Secrets ? "SECRETS — TAP ONE" : (mode == BrutalPickMode::Admin ? "ADMIN — SPAWN ZOMBIE" : "CHEATS — TAP ONE"),
		"", "", Dialog::BUTTONS_NONE)
	, mApp(theApp)
	, mMode(mode)
{
	mVerticalCenterText = false;

	auto addBtn = [this](int id, const std::string& label)
	{
		mButtons.push_back(MakeButton(id, this, label));
	};

	if (mMode == BrutalPickMode::Admin)
	{
		static const char* names[NUM_ZOMBIE_TYPES] = {
			"Normal", "Flag", "Conehead", "Pole Vaulter", "Buckethead", "Newspaper", "Screen Door", "Football", "Dancer", "Backup Dancer", "Ducky Tube", "Snorkel", "Zamboni", "Bobsled", "Dolphin Rider", "Jack-in-the-Box", "Balloon", "Digger", "Pogo", "Yeti", "Bungee", "Ladder", "Catapult", "Gargantuar", "Imp", "Dr. Zomboss", "Peashooter Head", "Wall-nut Head", "Jalapeno Head", "Gatling Head", "Squash Head", "Tall-nut Head", "Red-eye Gargantuar"
		};
		for (int i = 0; i < NUM_ZOMBIE_TYPES; ++i) addBtn(Btn_AdminZombieBase + i, names[i]);
	}
	else if (mMode == BrutalPickMode::Cheats)
	{
		addBtn(Btn_InfSun, "Infinite Sun");
		addBtn(Btn_NoCd, "No Cooldown");
		addBtn(Btn_FreePlant, "Free Planting");
		addBtn(Btn_Coins, "Max Coins");
		addBtn(Btn_Unlock, "Unlock Modes");
		addBtn(Btn_Best, "Beat Everything");
	}
	else
	{
		for (int i = 1; i <= BrutalSecretCount(); i++)
		{
			const BrutalSecretInfo* info = BrutalSecretGetInfo(i);
			if (!info) continue;
			std::string lab = std::to_string(i) + ". " + info->title;
			addBtn(Btn_SecretBase + i, lab);
		}
	}
	addBtn(Btn_Close, "Close");
	if (mMode == BrutalPickMode::Secrets)
		CalcSize(360, 320);
	else if (mMode == BrutalPickMode::Admin)
		CalcSize(440, 600);
	else
		CalcSize(300, 20 + (int)mButtons.size() * 42);
}

BrutalPickDialog::~BrutalPickDialog() = default;

void BrutalPickDialog::AddedToManager(Sexy::WidgetManager* theWidgetManager)
{
	LawnDialog::AddedToManager(theWidgetManager);
	for (auto& b : mButtons)
		AddWidget(b.get());
}

void BrutalPickDialog::RemovedFromManager(Sexy::WidgetManager* theWidgetManager)
{
	for (auto& b : mButtons)
		RemoveWidget(b.get());
	LawnDialog::RemovedFromManager(theWidgetManager);
}

void BrutalPickDialog::Resize(int theX, int theY, int theWidth, int theHeight)
{
	LawnDialog::Resize(theX, theY, theWidth, theHeight);
	const int top = 48;
	const int bh = 34;
	const int gap = 6;
	if ((mMode == BrutalPickMode::Secrets && mButtons.size() > 8) || (mMode == BrutalPickMode::Admin && mButtons.size() > 8))
	{
		// two columns so all secrets fit on phone
		int cols = 2;
		int colW = (mWidth - 50) / cols;
		int n = (int)mButtons.size();
		int useBh = mMode == BrutalPickMode::Admin ? 26 : bh;
		int useGap = mMode == BrutalPickMode::Admin ? 2 : gap;
		// last button is Close — full width at bottom
		for (int i = 0; i < n; i++)
		{
			if (i == n - 1)
			{
				mButtons[i]->Resize(20, mHeight - 50, mWidth - 40, 36);
				continue;
			}
			int col = i % cols;
			int row = i / cols;
			mButtons[i]->Resize(20 + col * (colW + 10), top + row * (useBh + useGap), colW, useBh);
		}
	}
	else
	{
		int y = top;
		int w = mWidth - 40;
		for (auto& b : mButtons)
		{
			b->Resize(20, y, w, bh);
			y += bh + gap;
		}
	}
}

void BrutalPickDialog::ButtonDepress(int theId)
{
	if (theId == Btn_Close)
	{
		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		return;
	}

	if (mMode == BrutalPickMode::Admin)
	{
		int idx = theId - Btn_AdminZombieBase;
		if (idx >= 0 && idx < NUM_ZOMBIE_TYPES && mApp->mBoard)
		{
			mApp->mBoard->AddZombie(static_cast<ZombieType>(idx), Zombie::ZOMBIE_WAVE_DEBUG);
			mApp->PlaySample(Sexy::SOUND_PAUSE);
		}
		return;
	}
	if (mMode == BrutalPickMode::Cheats)
	{
		switch (theId)
		{
		case Btn_InfSun:
			mApp->BrutalEnableInGameCheats(true, false, false);
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_NoCd:
			mApp->BrutalEnableInGameCheats(false, true, false);
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_FreePlant:
			mApp->BrutalEnableInGameCheats(false, false, true);
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Coins:
			if (mApp->mPlayerInfo)
			{
				mApp->mPlayerInfo->AddCoins(99999);
				mApp->WriteCurrentUserConfig();
			}
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Unlock:
			if (mApp->mPlayerInfo)
			{
				mApp->mPlayerInfo->mHasUnlockedMinigames = 1;
				mApp->mPlayerInfo->mHasUnlockedPuzzleMode = 1;
				mApp->mPlayerInfo->mHasUnlockedSurvivalMode = 1;
				mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
				mApp->WriteCurrentUserConfig();
			}
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			return;
		case Btn_Best:
			mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
			mApp->BrutalBeatEverything();
			return;
		default:
			break;
		}

	}
	else
	{
		// secret pick — start real minigame OR modified adventure
		int sid = theId - Btn_SecretBase;
		const BrutalSecretInfo* info = BrutalSecretGetInfo(sid);
		if (!info || !mApp->mPlayerInfo)
			return;

		mApp->KillDialog(Dialogs::DIALOG_BRUTAL_PICK);
		mApp->mBrutalSecretId = sid;
		mApp->mBrutalCheatJump = true;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mPlayerInfo->mFinishedAdventure = 0;

		if (info->challengeMode != GameMode::NUM_GAME_MODES)
		{
			// Hidden minigame-style secret (like original PvZ bonus games)
			mApp->mGameMode = info->challengeMode;
		}
		else
		{
			int slvl = info->startLevel;
			if (slvl < 1) slvl = 1;
			if (slvl > 70) slvl = 70;
			mApp->mPlayerInfo->SetLevel(slvl);
			mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
		}
		mApp->WriteCurrentUserConfig();
		mApp->BrutalSafeRestartAdventure();
	}
}

