#pragma once
#include "LawnDialog.h"
#include <memory>
#include <vector>

class LawnApp;
class LawnStoneButton;

enum class BrutalPickMode
{
	Cheats,
	Secrets,
	Admin
};

class BrutalPickDialog : public LawnDialog
{
public:
	enum
	{
		// button ids offset from dialog base
		Btn_Close = 1000,
		Btn_InfSun = 1001,
		Btn_NoCd = 1002,
		Btn_Coins = 1003,
		Btn_Skip = 1004,
		Btn_Unlock = 1005,
		Btn_Best = 1006,
		Btn_Evo = 1007,
		Btn_SecretBase = 1100, // + secret id 1..N
		Btn_AdminBase = 1300 // + ZombieType numeric value
	};

	LawnApp* mApp;
	BrutalPickMode mMode;
	std::vector<std::unique_ptr<LawnStoneButton>> mButtons;

	BrutalPickDialog(LawnApp* theApp, BrutalPickMode mode);
	~BrutalPickDialog() override;

	void AddedToManager(Sexy::WidgetManager* theWidgetManager) override;
	void RemovedFromManager(Sexy::WidgetManager* theWidgetManager) override;
	void Resize(int theX, int theY, int theWidth, int theHeight) override;
	void ButtonDepress(int theId) override;
};
