#include "BrutalEvoDialog.h"

#include "SeedChooserScreen.h"
#include "ToolTipWidget.h"
#include "GameButton.h"
#include "widget/WidgetManager.h"
#include "../SeedPacket.h"
#include "../Plant.h"
#include "../Brutal/BrutalMode.h"
#include "../../LawnApp.h"
#include "../../GameConstants.h"
#include "../../Resources.h"

namespace
{
constexpr int kDialogWidth = 760;
constexpr int kDialogHeight = 570;
constexpr int kColumns = 4;
constexpr int kCellWidth = 180;
constexpr int kCellHeight = 96;
constexpr int kLeft = 18;
constexpr int kTop = 82;
}

BrutalEvoDialog::BrutalEvoDialog() :
	LawnDialog(gLawnApp, Dialogs::DIALOG_BRUTAL_EVO, true, "BRUTAL EVO PLANTS", "", "", Dialog::BUTTONS_NONE)
{
	CalcSize(kDialogWidth - mWidth, kDialogHeight - mHeight);
	mClip = false;
}

int BrutalEvoDialog::HitTest(int x, int y) const
{
	for (int i = 0; i < BrutalMode::GetEvoCount(); ++i)
	{
		int col = i % kColumns;
		int row = i / kColumns;
		Rect r(kLeft + col * kCellWidth, kTop + row * kCellHeight, kCellWidth - 8, kCellHeight - 8);
		if (r.Contains(x, y))
			return i;
	}
	return -1;
}

void BrutalEvoDialog::Draw(Graphics* g)
{
	LawnDialog::Draw(g);
	g->SetLinearBlend(true);

	PvzpDrawString(g, "Choose one Evo", mWidth / 2, 58, Sexy::FONT_BRIANNETOD12, Color(235, 210, 135), DS_ALIGN_CENTER);

	for (int i = 0; i < BrutalMode::GetEvoCount(); ++i)
	{
		const auto& info = BrutalMode::GetEvoInfo(i);
		int col = i % kColumns;
		int row = i / kColumns;
		int x = kLeft + col * kCellWidth;
		int y = kTop + row * kCellHeight;
		bool unavailable = !mApp->HasSeedType(info.mBaseSeed) || mApp->mSeedChooserScreen->PickedPlantType(info.mBaseSeed);
		int gray = unavailable ? 90 : 255;

		DrawSeedPacket(g, x + 4, y, info.mBaseSeed, SeedType::SEED_NONE, 0, gray, true, false, info.mType);
		PvzpDrawString(g, info.mName, x + 68, y + 20, Sexy::FONT_BRIANNETOD12, unavailable ? Color(115, 115, 115) : Color(235, 210, 135), DS_ALIGN_LEFT);
		PvzpDrawString(g, "EVO", x + 68, y + 39, Sexy::FONT_BRIANNETOD12, unavailable ? Color(100, 100, 100) : Color(235, 190, 70), DS_ALIGN_LEFT);

		std::string ability = info.mAbility;
		const int maxChars = 21;
		if (ability.size() > maxChars)
		{
			std::size_t split = ability.rfind(' ', maxChars);
			if (split == std::string::npos) split = maxChars;
			PvzpDrawString(g, std::string_view(ability).substr(0, split), x + 68, y + 61, Sexy::FONT_BRIANNETOD12,
						unavailable ? Color(100, 100, 100) : Color(205, 205, 190), DS_ALIGN_LEFT);
			if (split < ability.size())
				PvzpDrawString(g, std::string_view(ability).substr(split + (ability[split] == ' ' ? 1 : 0)), x + 68, y + 76,
						Sexy::FONT_BRIANNETOD12, unavailable ? Color(100, 100, 100) : Color(205, 205, 190), DS_ALIGN_LEFT);
		}
		else
		{
			PvzpDrawString(g, ability, x + 68, y + 64, Sexy::FONT_BRIANNETOD12,
						unavailable ? Color(100, 100, 100) : Color(205, 205, 190), DS_ALIGN_LEFT);
		}
	}
}

void BrutalEvoDialog::MouseDown(int x, int y, int theClickCount)
{
	if (theClickCount < 0)
		return;

	int index = HitTest(x, y);
	if (index >= 0)
	{
		const auto& info = BrutalMode::GetEvoInfo(index);
		SeedChooserScreen* chooser = mApp->mSeedChooserScreen.get();
		if (mApp->HasSeedType(info.mBaseSeed) && !chooser->PickedPlantType(info.mBaseSeed))
		{
			chooser->AddEvoToBank(info.mType);
			mApp->KillDialog(mId);
		}
		else
		{
			mApp->PlaySample(Sexy::SOUND_BUZZER);
		}
		return;
	}

	Widget::MouseDown(x, y, theClickCount);
}

void BrutalEvoDialog::KeyDown(KeyCode theKey)
{
	if (theKey == KeyCode::KEYCODE_ESCAPE)
	{
		mApp->KillDialog(mId);
		return;
	}
	LawnDialog::KeyDown(theKey);
}
