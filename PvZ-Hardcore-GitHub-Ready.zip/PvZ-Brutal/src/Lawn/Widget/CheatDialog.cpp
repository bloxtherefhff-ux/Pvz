/*
 * Copyright (C) 2026 Zhou Qiankang <wszqkzqk@qq.com>
 *
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * This file is part of PvZ-Portable.
 *
 * PvZ-Portable is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PvZ-Portable is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with PvZ-Portable. If not, see <https://www.gnu.org/licenses/>.
 */

#include "CheatDialog.h"
#include "../../LawnApp.h"
#include "../LawnCommon.h"
#include "ChallengeScreen.h"
#include "../../Resources.h"
#include "../../GameConstants.h"
#include "../System/PlayerInfo.h"
#include "../Brutal/BrutalSecrets.h"
#include "../../LawnApp.h"
#include "widget/WidgetManager.h"
#include <algorithm>
#include <format>

CheatDialog::CheatDialog(LawnApp* theApp) : LawnDialog(theApp, Dialogs::DIALOG_CHEAT, true, "CHEAT / SECRETS", "1-1 | sun | nocd | skip | free | coin | unlock | secret 1-13", "", Dialog::BUTTONS_OK_CANCEL)
{
	mApp = theApp;
	mVerticalCenterText = false;
	mLevelEditWidget = CreateEditWidget(0, this, this);
	mLevelEditWidget->mMaxChars = 12;
	mLevelEditWidget->AddWidthCheckFont(FONT_BRIANNETOD12, 220);

	std::string aCheatStr;
	if (mApp->mGameMode != GameMode::GAMEMODE_ADVENTURE)
	{
		aCheatStr = std::format("C{}", static_cast<int>(mApp->mGameMode));
	}
	else if (mApp->HasFinishedAdventure())
	{
		aCheatStr = std::format("F{}", mApp->GetStageString(mApp->mPlayerInfo->GetLevel()));
	}
	else
	{
		aCheatStr = mApp->GetStageString(mApp->mPlayerInfo->GetLevel());
	}
	mLevelEditWidget->SetText(aCheatStr, true);

	CalcSize(110, 40);
}

CheatDialog::~CheatDialog() = default;

int CheatDialog::GetPreferredHeight(int theWidth)
{
	return LawnDialog::GetPreferredHeight(theWidth);
}

void CheatDialog::Resize(int theX, int theY, int theWidth, int theHeight)
{
	LawnDialog::Resize(theX, theY, theWidth, theHeight);
	mLevelEditWidget->Resize(mContentInsets.mLeft + 12, mHeight - 155, mWidth - mContentInsets.mLeft - mContentInsets.mRight - 24, 28);
}

void CheatDialog::AddedToManager(WidgetManager* theWidgetManager)
{
	LawnDialog::AddedToManager(theWidgetManager);
	AddWidget(mLevelEditWidget.get());
	theWidgetManager->SetFocus(mLevelEditWidget.get());
}

void CheatDialog::RemovedFromManager(WidgetManager* theWidgetManager)
{
	LawnDialog::RemovedFromManager(theWidgetManager);
	RemoveWidget(mLevelEditWidget.get());
}

void CheatDialog::Draw(Graphics* g)
{
	LawnDialog::Draw(g);
	DrawEditBox(g, mLevelEditWidget.get());
}

void CheatDialog::EditWidgetText([[maybe_unused]] int theId, [[maybe_unused]] const std::string& theString)
{
	mApp->ButtonDepress(mId + 2000);
}

bool CheatDialog::AllowChar([[maybe_unused]] int theId, char theChar)
{
	return isalnum(theChar) || theChar == '-' || theChar == ' ' || theChar == '_';
}

bool CheatDialog::ApplyCheat()
{
	std::string s = mLevelEditWidget->mString;
	// lower-case helper
	auto lower = [](std::string x) {
		for (char& c : x) if (c >= 'A' && c <= 'Z') c = c - 'A' + 'a';
		return x;
	};
	std::string sl = lower(s);

	// --- Brutal infinite / free cheats ---
	if (sl == "sun" || sl == "infsun")
	{
		mApp->mBrutalInfSun = true;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		return true;
	}
	if (sl == "coin" || sl == "coins" || sl == "infcoin")
	{
		mApp->mBrutalInfCoins = true;
		if (mApp->mPlayerInfo)
			mApp->mPlayerInfo->AddCoins(99999);
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->WriteCurrentUserConfig();
		return true;
	}
	if (sl == "free" || sl == "freeplant")
	{
		mApp->mBrutalFreePlant = true;
		mApp->mEasyPlantingCheat = true;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		return true;
	}
	if (sl == "skip" || sl == "next")
	{
		if (!mApp->mPlayerInfo) return false;
		int lvl = mApp->mPlayerInfo->GetLevel() + 1;
		if (lvl > 50) lvl = 50;
		mApp->mPlayerInfo->SetLevel(lvl);
		mApp->mPlayerInfo->mFinishedAdventure = 0;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mBrutalCheatJump = true;
		mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
		mApp->WriteCurrentUserConfig();
		return true; // FinishCheatDialog does safe PreNewGame
	}
	if (sl == "nocd" || sl == "cd")
	{
		mApp->BrutalEnableInGameCheats(false, true, false);
		return true;
	}
	if (sl == "best" || sl == "beat" || sl == "everything")
	{
		mApp->BrutalBeatEverything();
		return true;
	}
	if (sl == "unlock")
	{
		if (mApp->mPlayerInfo)
		{
			mApp->mPlayerInfo->mHasUnlockedMinigames = 1;
			mApp->mPlayerInfo->mHasUnlockedPuzzleMode = 1;
			mApp->mPlayerInfo->mHasUnlockedSurvivalMode = 1;
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			// do NOT set finished adventure — avoids free endless/coins from clear
			mApp->WriteCurrentUserConfig();
		}
		return true;
	}
	if (sl.rfind("secret", 0) == 0)
	{
		// "secret storm" or "secret 12"
		std::string rest = sl.size() > 6 ? sl.substr(6) : "";
		while (!rest.empty() && rest[0] == ' ') rest.erase(0, 1);
		int id = 0;
		if (!rest.empty() && rest[0] >= '0' && rest[0] <= '9')
			id = atoi(rest.c_str());
		else
		{
			for (int i = 1; i <= BrutalSecretCount(); i++)
			{
				const BrutalSecretInfo* info = BrutalSecretGetInfo(i);
				if (info && rest == info->code) { id = i; break; }
			}
		}
		const BrutalSecretInfo* info = BrutalSecretGetInfo(id);
		if (!info)
		{
			mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Secret",
				"Unknown secret. Try: secret storm | giant | close | ...",
				"[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return false;
		}
		mApp->mBrutalSecretId = id;
		mApp->mBrutalCheatJump = true;
		mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
		int slvl = info->startLevel;
		if (slvl < 1) slvl = 1;
		if (slvl > 50) slvl = 50;
		mApp->mPlayerInfo->SetLevel(slvl);
		mApp->mPlayerInfo->mFinishedAdventure = 0;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mBrutalCheatJump = true;
		mApp->WriteCurrentUserConfig();
		return true;
	}

	int aChallengeIndex;
	if (sscanf(mLevelEditWidget->mString.c_str(), "c%d", &aChallengeIndex) == 1 ||
		sscanf(mLevelEditWidget->mString.c_str(), "C%d", &aChallengeIndex) == 1)
	{
		mApp->mGameMode = (GameMode)std::clamp(aChallengeIndex, 0, NUM_CHALLENGE_MODES);
		return true;
	}

	int aLevel = -1;
	int aFinishedAdventure = 0;
	int aArea, aSubArea;
	if (sscanf(mLevelEditWidget->mString.c_str(), "f%d-%d", &aArea, &aSubArea) == 2 ||
		sscanf(mLevelEditWidget->mString.c_str(), "F%d-%d", &aArea, &aSubArea) == 2)
	{
		aLevel = (aArea - 1) * LEVELS_PER_AREA + aSubArea;
		aFinishedAdventure = 1;
	}
	else if (sscanf(mLevelEditWidget->mString.c_str(), "f%d", &aLevel) == 1 || sscanf(mLevelEditWidget->mString.c_str(), "F%d", &aLevel) == 1)
	{
		aFinishedAdventure = 1;
	}
	else if (sscanf(mLevelEditWidget->mString.c_str(), "%d-%d", &aArea, &aSubArea) == 2)
	{
		aLevel = (aArea - 1) * LEVELS_PER_AREA + aSubArea;
	}
	else
	{
		sscanf(mLevelEditWidget->mString.c_str(), "%d", &aLevel);
	}

	if (aLevel <= 0)
	{
		mApp->DoDialog(
			Dialogs::DIALOG_CHEATERROR,
			true,
			"Enter Level",
			"Invalid Level. Do 'number' or 'area-subarea' or 'Cnumber' or 'Farea-subarea'.",
			"[DIALOG_BUTTON_OK]",
			Dialog::BUTTONS_FOOTER
		);
		return false;
	}

	if (aLevel < 1) aLevel = 1;
	if (aLevel > 50) aLevel = 50;
	mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
	if (!mApp->mPlayerInfo) return false;
	mApp->mPlayerInfo->SetLevel(aLevel);
	// Name/cheat jump: never grant adventure-clear rewards
	mApp->mPlayerInfo->mFinishedAdventure = 0;
	mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
	mApp->mBrutalCheatJump = true;
	mApp->WriteCurrentUserConfig();
	return true;
}
