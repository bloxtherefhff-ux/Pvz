/*
 * Copyright (C) 2026 Zhou Qiankang <wszqkzqk@qq.com>
 *
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * This file is part of PvZ-Portable.
 *
 * PvZ-Portable is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PvZ-Portable is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with PvZ-Portable. If not, see <https://www.gnu.org/licenses/>.
 */

#include "CheatDialog.h"
#include "../../LawnApp.h"
#include "../LawnCommon.h"
#include "ChallengeScreen.h"
#include "../../Resources.h"
#include "../../GameConstants.h"
#include "../System/PlayerInfo.h"
#include "../Brutal/BrutalSecrets.h"
#include "../Board.h"
#include "../Zombie.h"
#include <sstream>
#include <utility>
#include "../../LawnApp.h"
#include "widget/WidgetManager.h"
#include <algorithm>
#include <format>

CheatDialog::CheatDialog(LawnApp* theApp) : LawnDialog(theApp, Dialogs::DIALOG_CHEAT, true, "CHEAT / SECRETS", "1-1 | sun | nocd | skip | free | coin | unlock | secret 1-13 | admin: spawn cone 3", "", Dialog::BUTTONS_OK_CANCEL)
{
	mApp = theApp;
	mVerticalCenterText = false;
	mLevelEditWidget = CreateEditWidget(0, this, this);
	mLevelEditWidget->mMaxChars = 12;
	mLevelEditWidget->AddWidthCheckFont(FONT_BRIANNETOD12, 220);

	std::string aCheatStr;
	if (mApp->mGameMode != GameMode::GAMEMODE_ADVENTURE)
	{
		aCheatStr = std::format("C{}", static_cast<int>(mApp->mGameMode));
	}
	else if (mApp->HasFinishedAdventure())
	{
		aCheatStr = std::format("F{}", mApp->GetStageString(mApp->mPlayerInfo->GetLevel()));
	}
	else
	{
		aCheatStr = mApp->GetStageString(mApp->mPlayerInfo->GetLevel());
	}
	mLevelEditWidget->SetText(aCheatStr, true);

	CalcSize(110, 40);
}

CheatDialog::~CheatDialog() = default;

int CheatDialog::GetPreferredHeight(int theWidth)
{
	return LawnDialog::GetPreferredHeight(theWidth);
}

void CheatDialog::Resize(int theX, int theY, int theWidth, int theHeight)
{
	LawnDialog::Resize(theX, theY, theWidth, theHeight);
	mLevelEditWidget->Resize(mContentInsets.mLeft + 12, mHeight - 155, mWidth - mContentInsets.mLeft - mContentInsets.mRight - 24, 28);
}

void CheatDialog::AddedToManager(WidgetManager* theWidgetManager)
{
	LawnDialog::AddedToManager(theWidgetManager);
	AddWidget(mLevelEditWidget.get());
	theWidgetManager->SetFocus(mLevelEditWidget.get());
}

void CheatDialog::RemovedFromManager(WidgetManager* theWidgetManager)
{
	LawnDialog::RemovedFromManager(theWidgetManager);
	RemoveWidget(mLevelEditWidget.get());
}

void CheatDialog::Draw(Graphics* g)
{
	LawnDialog::Draw(g);
	DrawEditBox(g, mLevelEditWidget.get());
}

void CheatDialog::EditWidgetText([[maybe_unused]] int theId, [[maybe_unused]] const std::string& theString)
{
	mApp->ButtonDepress(mId + 2000);
}

bool CheatDialog::AllowChar([[maybe_unused]] int theId, char theChar)
{
	return isalnum(theChar) || theChar == '-' || theChar == ' ' || theChar == '_';
}

bool CheatDialog::ApplyCheat()
{
	std::string s = mLevelEditWidget->mString;
	// lower-case helper
	auto lower = [](std::string x) {
		for (char& c : x) if (c >= 'A' && c <= 'Z') c = c - 'A' + 'a';
		return x;
	};
	std::string sl = lower(s);

	// Admin-only zombie spawner. The active profile must be named exactly Admin/admin (case-insensitive).
	if (sl.rfind("spawn ", 0) == 0)
	{
		std::string profileName = mApp->mPlayerInfo ? mApp->mPlayerInfo->mName : std::string();
		for (char& c : profileName) if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
		if (profileName != "admin")
		{
			mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Admin only",
				"Name this profile Admin to use zombie spawning.", "[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return false;
		}
		if (!mApp->mBoard || mApp->mGameScene != GameScenes::SCENE_PLAYING)
		{
			mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Spawn zombie",
				"Start a level first, then enter spawn <type> [row 1-6].", "[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return false;
		}
		std::istringstream input(sl.substr(6));
		std::string typeName;
		int row = 3;
		input >> typeName;
		const int maxRows = (mApp->mBoard->StageHasPool() || mApp->mBoard->StageHas6Rows()) ? 6 : 5;
		if (input >> row) row = std::clamp(row, 1, maxRows);
		else row = std::min(3, maxRows);
		const std::pair<const char*, ZombieType> types[] = {
			{"normal", ZombieType::ZOMBIE_NORMAL}, {"basic", ZombieType::ZOMBIE_NORMAL},
			{"flag", ZombieType::ZOMBIE_FLAG}, {"cone", ZombieType::ZOMBIE_TRAFFIC_CONE},
			{"pole", ZombieType::ZOMBIE_POLEVAULTER}, {"polevaulter", ZombieType::ZOMBIE_POLEVAULTER},
			{"bucket", ZombieType::ZOMBIE_PAIL}, {"newspaper", ZombieType::ZOMBIE_NEWSPAPER},
			{"door", ZombieType::ZOMBIE_DOOR}, {"football", ZombieType::ZOMBIE_FOOTBALL},
			{"dancer", ZombieType::ZOMBIE_DANCER}, {"duckytube", ZombieType::ZOMBIE_DUCKY_TUBE},
			{"snorkel", ZombieType::ZOMBIE_SNORKEL}, {"zamboni", ZombieType::ZOMBIE_ZAMBONI},
			{"bobsled", ZombieType::ZOMBIE_BOBSLED}, {"dolphin", ZombieType::ZOMBIE_DOLPHIN_RIDER},
			{"jack", ZombieType::ZOMBIE_JACK_IN_THE_BOX}, {"balloon", ZombieType::ZOMBIE_BALLOON},
			{"digger", ZombieType::ZOMBIE_DIGGER}, {"pogo", ZombieType::ZOMBIE_POGO},
			{"yeti", ZombieType::ZOMBIE_YETI}, {"bungee", ZombieType::ZOMBIE_BUNGEE},
			{"ladder", ZombieType::ZOMBIE_LADDER}, {"catapult", ZombieType::ZOMBIE_CATAPULT},
			{"gargantuar", ZombieType::ZOMBIE_GARGANTUAR}, {"imp", ZombieType::ZOMBIE_IMP},
			{"garg", ZombieType::ZOMBIE_GARGANTUAR}, {"redgarg", ZombieType::ZOMBIE_REDEYE_GARGANTUAR},
			{"redeye", ZombieType::ZOMBIE_REDEYE_GARGANTUAR}, {"boss", ZombieType::ZOMBIE_BOSS},
			{"peahead", ZombieType::ZOMBIE_PEA_HEAD}, {"wallnuthead", ZombieType::ZOMBIE_WALLNUT_HEAD},
			{"jalapenohead", ZombieType::ZOMBIE_JALAPENO_HEAD}, {"gatlinghead", ZombieType::ZOMBIE_GATLING_HEAD},
			{"squashhead", ZombieType::ZOMBIE_SQUASH_HEAD}, {"tallnuthead", ZombieType::ZOMBIE_TALLNUT_HEAD}
		};
		ZombieType type = ZombieType::ZOMBIE_INVALID;
		for (const auto& entry : types) if (typeName == entry.first) { type = entry.second; break; }
		if (type == ZombieType::ZOMBIE_INVALID)
		{
			mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Unknown zombie",
				"Use spawn normal/cone/bucket/football/dancer/snorkel/zamboni/digger/pogo/balloon/catapult/garg/redgarg/imp/boss or a zombie type name.", "[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return false;
		}
		Zombie* spawned = mApp->mBoard->AddZombieInRow(type, row - 1, 0);
		if (!spawned)
		{
			mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Spawn failed",
				"Zombie limit reached or the board rejected the spawn.", "[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return false;
		}
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		return true;
	}

	// --- Brutal infinite / free cheats ---
	if (sl == "sun" || sl == "infsun")
	{
		mApp->mBrutalInfSun = true;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		return true;
	}
	if (sl == "coin" || sl == "coins" || sl == "infcoin")
	{
		mApp->mBrutalInfCoins = true;
		if (mApp->mPlayerInfo)
			mApp->mPlayerInfo->AddCoins(99999);
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->WriteCurrentUserConfig();
		return true;
	}
	if (sl == "free" || sl == "freeplant")
	{
		mApp->mBrutalFreePlant = true;
		mApp->mEasyPlantingCheat = true;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		return true;
	}
	if (sl == "skip" || sl == "next")
	{
		if (!mApp->mPlayerInfo) return false;
		int lvl = mApp->mPlayerInfo->GetLevel() + 1;
		if (lvl > 70) lvl = 70;
		mApp->mPlayerInfo->SetLevel(lvl);
		mApp->mPlayerInfo->mFinishedAdventure = 0;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mBrutalCheatJump = true;
		mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
		mApp->WriteCurrentUserConfig();
		return true; // FinishCheatDialog does safe PreNewGame
	}
	if (sl == "nocd" || sl == "cd")
	{
		mApp->BrutalEnableInGameCheats(false, true, false);
		return true;
	}
	if (sl == "best" || sl == "beat" || sl == "everything")
	{
		mApp->BrutalBeatEverything();
		return true;
	}
	if (sl == "unlock")
	{
		if (mApp->mPlayerInfo)
		{
			mApp->mPlayerInfo->mHasUnlockedMinigames = 1;
			mApp->mPlayerInfo->mHasUnlockedPuzzleMode = 1;
			mApp->mPlayerInfo->mHasUnlockedSurvivalMode = 1;
			mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
			// do NOT set finished adventure — avoids free endless/coins from clear
			mApp->WriteCurrentUserConfig();
		}
		return true;
	}
	if (sl.rfind("secret", 0) == 0)
	{
		// "secret storm" or "secret 12"
		std::string rest = sl.size() > 6 ? sl.substr(6) : "";
		while (!rest.empty() && rest[0] == ' ') rest.erase(0, 1);
		int id = 0;
		if (!rest.empty() && rest[0] >= '0' && rest[0] <= '9')
			id = atoi(rest.c_str());
		else
		{
			for (int i = 1; i <= BrutalSecretCount(); i++)
			{
				const BrutalSecretInfo* info = BrutalSecretGetInfo(i);
				if (info && rest == info->code) { id = i; break; }
			}
		}
		const BrutalSecretInfo* info = BrutalSecretGetInfo(id);
		if (!info)
		{
			mApp->DoDialog(Dialogs::DIALOG_CHEATERROR, true, "Secret",
				"Unknown secret. Try: secret storm | giant | close | ...",
				"[DIALOG_BUTTON_OK]", Dialog::BUTTONS_FOOTER);
			return false;
		}
		mApp->mBrutalSecretId = id;
		mApp->mBrutalCheatJump = true;
		mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
		int slvl = info->startLevel;
		if (slvl < 1) slvl = 1;
		if (slvl > 70) slvl = 70;
		mApp->mPlayerInfo->SetLevel(slvl);
		mApp->mPlayerInfo->mFinishedAdventure = 0;
		mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
		mApp->mBrutalCheatJump = true;
		mApp->WriteCurrentUserConfig();
		return true;
	}

	int aChallengeIndex;
	if (sscanf(mLevelEditWidget->mString.c_str(), "c%d", &aChallengeIndex) == 1 ||
		sscanf(mLevelEditWidget->mString.c_str(), "C%d", &aChallengeIndex) == 1)
	{
		mApp->mGameMode = (GameMode)std::clamp(aChallengeIndex, 0, NUM_CHALLENGE_MODES);
		return true;
	}

	int aLevel = -1;
	int aFinishedAdventure = 0;
	int aArea, aSubArea;
	if (sscanf(mLevelEditWidget->mString.c_str(), "f%d-%d", &aArea, &aSubArea) == 2 ||
		sscanf(mLevelEditWidget->mString.c_str(), "F%d-%d", &aArea, &aSubArea) == 2)
	{
		aLevel = (aArea - 1) * LEVELS_PER_AREA + aSubArea;
		aFinishedAdventure = 1;
	}
	else if (sscanf(mLevelEditWidget->mString.c_str(), "f%d", &aLevel) == 1 || sscanf(mLevelEditWidget->mString.c_str(), "F%d", &aLevel) == 1)
	{
		aFinishedAdventure = 1;
	}
	else if (sscanf(mLevelEditWidget->mString.c_str(), "%d-%d", &aArea, &aSubArea) == 2)
	{
		aLevel = (aArea - 1) * LEVELS_PER_AREA + aSubArea;
	}
	else
	{
		sscanf(mLevelEditWidget->mString.c_str(), "%d", &aLevel);
	}

	if (aLevel <= 0)
	{
		mApp->DoDialog(
			Dialogs::DIALOG_CHEATERROR,
			true,
			"Enter Level",
			"Invalid Level. Do 'number' or 'area-subarea' or 'Cnumber' or 'Farea-subarea'.",
			"[DIALOG_BUTTON_OK]",
			Dialog::BUTTONS_FOOTER
		);
		return false;
	}

	if (aLevel < 1) aLevel = 1;
	if (aLevel > 70) aLevel = 70;
	mApp->mGameMode = GameMode::GAMEMODE_ADVENTURE;
	if (!mApp->mPlayerInfo) return false;
	mApp->mPlayerInfo->SetLevel(aLevel);
	// Name/cheat jump: never grant adventure-clear rewards
	mApp->mPlayerInfo->mFinishedAdventure = 0;
	mApp->mPlayerInfo->mHasUsedCheatKeys = 1;
	mApp->mBrutalCheatJump = true;
	mApp->WriteCurrentUserConfig();
	return true;
}
