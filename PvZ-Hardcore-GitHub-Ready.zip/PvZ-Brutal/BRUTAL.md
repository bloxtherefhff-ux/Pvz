# Brutal Mode — aligned to Brutal Mod / 无名版 sources

## Sources used
- "Every PvZ Brutal Mod zombie Explained"
- 无名版 skill descriptions (路障/铁桶/旗帜/普通精英等)
- Prior Unnamed 1.1.0 Excel mapping

## Multi-form zombies
| Type | Forms |
|------|--------|
| Cone | Normal · **Gramophone** (full-heal pulse 6.5s 3×5) · **Dancing/MJ** (death → 4 dancers) |
| Bucket | Normal · **Armorer** (gift pails + self sustain) |
| Flag | Normal · **Night Horn** (strong sun drain) |
| Basic/Ducky | Normal · **Letterhead** (2× HP, fast, **walks through plants**) |

## Single-form (skill always on)
Pole grave on land · Newspaper rage · Door reflect · Football sprint · Dancer summons · Ladder 5× · Pogo instant · Garg early throw · Zamboni plant slow · Catapult faith · Jack/Balloon/Digger/Bungee/Snorkel/Dolphin typed · Plant-heads · Boss HP

## Plants + Almanac
Full Brutal plant skill set; book shows [BRUTAL] lines.

## Global
HP×1.85 speed×1.25 · denser waves · slower sky sun · secrets/cheats/name codes

## Limits (cannot 1:1 PC EXE)
No Unnamed head sprites · no exact EXE RNG tables · no Windows LawnProject.exe on Android
