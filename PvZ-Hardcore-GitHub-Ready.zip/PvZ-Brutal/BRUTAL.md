# Brutal / Unnamed mobile — source map

Based on *Plants vs. Zombies: Unnamed* (Fanon wiki) + Portable engine limits.

## Adventure (70 levels)

| Levels | World | Background | Notes |
|--------|-------|------------|-------|
| 1-10 | 1 Day | Day | Basics → Cone → Bucket intro |
| 11-20 | 2 Night | Night | Newspaper, Football, Dancer |
| 21-30 | 3 Pool | Pool | Snorkel, Zamboni, Dolphin |
| 31-40 | 4 Fog | Fog | Jack, Balloon, Digger, Pogo |
| 41-49 | 5 Roof | Roof | Ladder, Catapult, Garg |
| 50 | 5-10 | Boss | Zomboss |
| 51-54,56-59 | **6 Night Roof** | Roof | Zombotanies + full roof roster |
| 55, 60 | **6-5 / 6-10** | Boss stage | Red-eye / Zomboss |
| 61-62 | **7** Zen | Greenhouse | Mixed pressure |
| 63-64 | **7** Aquarium | Zombiquarium | |
| 65, 70 | **7** Day | Day | 7-10 true finale + boss |
| 66 | **7** Roof | Roof | |
| 67 | **7** Fog | Fog | |
| 68 | **7** Pool | Pool | |
| 69 | **7** Night | Night | |

## World 6-7 zombies (forced + allowed)
- All normal types already unlocked
- **Zombotanies** (Pea/Wall-Nut/Jalapeno/Gatling/Squash/Tall-Nut head) from 51+
- **Gargantuar** flag waves 51+
- **Red-eye Garg** 55+
- **Boss** levels 60 and 70

## Forms
- Basic: Letterhead (2× HP, **not** 2× speed)
- Cone: Gramophone | Dancing
- Bucket: Armorer | Flag: Night Horn

## Plants
Unnamed costs + combat hooks; **Evo ON** in Cheats for Evo rules (same art).

## Spawns
Wave budget ×4 + pad extras; Catapult 90k HP until balls empty.
