# Original PvZ Brutal Mode — source map

This package targets **original PvZ Brutal Mode**, not Brutal Mode EX or EX Plus.

## Adventure campaign (60 levels)

| Levels | World | Background / special behavior |
|---|---|---|
| 1–10 | World 1 | Day; original early-game unlock progression |
| 11–20 | World 2 | Night |
| 21–30 | World 3 | Pool |
| 31–40 | World 4 | Fog |
| 41–50 | World 5 | Roof; level 5-10 is the original Zomboss finale |
| 51–59 | World 6 | Original Brutal Mode’s added zombie lineups; 6-6 uses the provided screenshot as a lineup reference |
| 60 (6-10) | World 6 finale | Dr. Zomboss, Choose Your Seeds, 4,000 starting sun; clearing it awards the trophy and completes Adventure |

**World 7 is not part of this build.** The campaign constant is 60 levels, the zombie wave and allowed-level tables are sized to 60, and level jumps/save data are clamped to 6-10.

## Secrets and hidden challenge pages

The main-menu **SECRETS** button opens a paginated picker. It contains the custom Brutal secret entries plus playable challenge definitions hidden on the Limbo and Puzzle pages. Entries launch the underlying game mode through the engine’s standard `PreNewGame` path; Upsell and Intro transitions are excluded because they are not playable levels. The Mini-Games screen’s secret banner also works from Challenge, Survival, and Puzzle pages.

## Plant variants

This is the original Brutal Mode package. **Evo plants are not selectable or activatable here**; Evo support belongs in a separate EX Plus project.

## Spawns

Original Brutal Mode’s wave-budget and zombie-variant code remains in place. The special World 6 roster filter prevents zombies outside each stage’s lineup from being selected.
