# Brutal Mode source audit — v4

## Changes in this pass

- Fixed the missing comma in the `ZOMBIE_BACKUP_DANCER` table in `src/Lawn/Challenge.h` that causes the reported `expected '}'` compiler error.
- Separated Brutal form IDs from `Zombie::mLastPortalX`. The latter is engine portal state; using it as a variant ID could break unrelated zombie movement, including the pole-vaulter. Brutal form logic now uses `mBrutalForm`, and the new field is included in portable save serialization.
- Added an Evo selector beside Imitater in the seed chooser. Tap `EVO` to choose Evo versions; tap again to return to normal selection. Selected Evo plant types are tracked per chooser selection so normal plants chosen in normal mode are not accidentally upgraded when the chooser mode changes.
- Evo plants now get an explicit `mIsBrutalEvo` marker, use the selected plant's effective type for Imitater copies, and serialize that marker with plant state. Evo-only fire-rate stacking and bonus sun now check this marker.
- Added a profile-name-gated admin spawn panel: set the profile name to `admin` or `Admin`, open the Menu from seed selection, and the panel lists all built-in zombie types. Tapping one spawns it on the current board and keeps the panel open for repeated tests.
- Added `assets/ai/README.md` clarifying that this is not an AI model-loading directory and documenting the real route for compatible custom sprite/reanimation assets.

## Triple-check record

### Pass 1 — structural checks
- ZIP integrity passed on the input archive.
- Confirmed `mIsBrutalEvo` exists only on `Plant`, not `PlantDefinition` or `PottedPlant`.
- Confirmed the Evo marker is serialized in `SyncPlantTailPortable`, and the zombie form field in `SyncZombieTailPortable`.
- Confirmed the admin method is declared and defined, and the admin dialog uses the built-in `ZombieType` range.

### Pass 2 — behavior-path checks
- Traced seed chooser click path: Evo button toggles chooser mode; clicking a seed stores its per-type Evo selection; returning a selected seed clears that selection.
- Traced plant path: `PlantInitialize` applies Evo stats only for an Evo-selected type or when the explicit global Evo cheat is enabled.
- Traced pole-vaulter path: vanilla `UpdateActions` still calls `UpdateZombiePolevaulter`; Brutal variant code no longer overwrites `mLastPortalX`.
- Traced admin path: case-insensitive `admin` profile check is in the seed chooser Menu handler; each panel choice calls `Board::AddZombie` with the current wave.

### Pass 3 — packaging and build checks
- Archive is generated with the expected `PvZ-Brutal/` root folder and passes `unzip -t`.
- Local CMake configuration was attempted, but this environment is missing `libopenmpt` (`OPENMPT_LIBRARY`), so a full compile and runtime test could not be completed here. Do not treat the static checks as proof of a successful Android build.

## Remaining verification limitation

The project uses the same existing plant/zombie art for many Evo/Brutal forms; no original Unnamed custom art is bundled. The Evo stats/effects in `BrutalMode.cpp` are this project's reimplementation, not a verified byte-for-byte reproduction of a proprietary/fan-mod build. Run the Android GitHub Actions build and test the chooser, admin spawns, pole-vaulter vault, and Evo effects in the APK before calling it fully verified.
