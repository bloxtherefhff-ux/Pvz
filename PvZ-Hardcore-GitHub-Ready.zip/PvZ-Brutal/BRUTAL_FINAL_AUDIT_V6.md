# Final static audit — Original PvZ Brutal Mode v6

- Campaign constants: 6 areas × 10 levels = 60; FINAL_LEVEL resolves to 60.
- Zombie wave table: 60 entries.
- Zombie-allowed table: 33 type rows; each regular row has 60 level flags, with special rows retaining a single disabled initializer.
- World 6 roster filter: exact cases 51–60; no cases 61–70.
- 6-10: boss type allowed, final boss route active, 4,000 starting sun, and final-level trophy award path active.
- Trophy timing: level 5-10 now gives a money-bag reward rather than prematurely awarding the campaign trophy; 6-10 is the only adventure level that awards it.
- Evo: no Evo selector/toggle and each new plant's Evo flag is reset false. Evo-specific dormant implementation details remain in the shared source but have no activation path in this package.
- Secrets: 13 custom Brutal secrets + 39 challenge modes from Limbo/Puzzle = 52 entries across 5 pages (12 slots per page). The entries route through existing game-mode launch APIs.
- Main-menu SECRETS button opens the paginated dialog. Challenge, Survival, and Puzzle page banners all open the same dialog.
- Old 70-level clamps and World 7 campaign roster cases were scanned and removed from program logic.
- ZIP integrity is checked after packaging.

## Validation boundary

This is a source/static audit, not an in-game or APK-build certification. C++ syntax-only compilation is currently blocked by the environment missing SDL development headers (`SDL.h`). Run GitHub Actions and test the resulting APK on-device before treating this build as runtime-verified.
