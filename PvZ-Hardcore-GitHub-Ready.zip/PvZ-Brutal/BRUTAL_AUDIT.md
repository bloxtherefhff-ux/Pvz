# Brutal Mode source audit — v3

## Corrected in this pass

- Brutal zombie form state now lives in `Zombie::mBrutalForm`; it no longer commandeers `mLastPortalX`, which belongs to the engine's portal logic. This avoids breaking portal coordinates when Brutal variants spawn.
- The in-game Evo toggle is now wired into plant initialization. New in-play plants receive an Evo profile only while Evo mode is enabled; plants already placed are not silently transformed when the toggle changes.
- Evo state is stored in `Plant::mBrutalEvo`, not in `mTargetX` or `mEatenFlashCountdown`. The old `mTargetX = 7777` sentinel could corrupt targeting, and reusing the flash countdown could interfere with visual/gameplay counters.
- Evo fire-rate stacking and Evo bonus-sun behavior are now limited to plants marked as Evo, rather than applying those Evo-only rewards to every normal plant.
- The generic Evo fallback is bounded to a 10% faster launch rate and 20% health increase, avoiding the prior 50% blanket health increase. Plants with dedicated profiles retain their specific values.
- Removed an unused local zombie-form flag.
- Added `assets/ai/README.md` explaining that this project uses C++ gameplay logic and does not ship a neural-network model or custom Unnamed animation assets.

## Verification performed

- ZIP archive integrity checked before editing; source tree extracted and reviewed.
- Static checks: only one `mBrutalEvo` member exists in `Plant`; Brutal logic no longer references `mLastPortalX`; Evo hook is called from plant initialization; no `mTargetX = 7777` remains.
- CMake configuration was attempted locally but stops before compilation because the environment does not have `libopenmpt` installed (`OPENMPT_LIBRARY` not found). Therefore this pass is **not** claimed to have passed a full native or Android compile. GitHub Actions remains the authoritative build check.

## Known gaps / don't mistake these for verified features

- The project is a reimplementation inspired by community/fanon descriptions, not the original proprietary Unnamed/Brutal executable. Where source rules are ambiguous, the implementation is an approximation.
- Zombie form variety is still limited to the implemented form cases. Most zombie types have stat/behavior adjustments, but they do not all have a separate custom visual form.
- Evo plants currently have a per-plant state marker and stat profiles, plus Evo-gated shooter stacking and bonus sun. This is not yet a faithful recreation of every plant-specific Evo mechanic from the source mod; exact source spreadsheets/screenshots are needed to implement undocumented effects reliably.
- Unique custom art/animation rigs are not included. The current game reuses existing legal game data/animations.
- Full Android compile/runtime playtest is still required to discover compiler, packaging, and in-game timing issues that static review cannot prove away.

## v4 targeted fixes (2026-10-04)

- Fixed the missing comma in the `ZOMBIE_BACKUP_DANCER` allowed-level initializer in `src/Lawn/Challenge.h` (the exact compiler error reported by GitHub Actions).
- World 7 / levels 61-70 now use stage-gated zombie rosters instead of the previous broad `return true` for almost every zombie: aquatic types are limited to 7-3, 7-4, 7-8, and 7-10; roof types to 7-2, 7-6, and 7-10; fog/airborne types to selected stages; Zomboss only appears on 7-10; Gargantuars ramp in later levels.
- `GetStageString` now uses explicit 1..70 clamping and modulo-based sublevel formatting.
- Restored an explicit Evo Plants ON/OFF button in the Cheats dialog with state in the label.
- Added an Admin Empty Test Board toggle to the Cheats dialog. When on, it starts Adventure 1-1 with zero zombie waves and clears wave entries so old wave data cannot leak into the sandbox.

### Verification limits
- Static audit script passed, but it is a source-level regression check, not a runtime proof.
- ZIP integrity and level-code mapping are checked after packaging.
- A complete Android compile still requires the GitHub Actions toolchain/dependencies; this environment does not contain the project's full Android SDK/NDK + SDL/vcpkg dependency setup.
- The Evo button is still a global profile toggle for newly planted plants; this does **not** yet implement a separate Evo seed-packet catalog next to Imitater. That requires dedicated packet/seed identity and chooser UI work, not just a toggle.
