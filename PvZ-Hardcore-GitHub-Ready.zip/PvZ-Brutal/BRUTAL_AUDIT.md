# Brutal Mode source audit — v3

## Corrected in this pass

- Brutal zombie form state now lives in `Zombie::mBrutalForm`; it no longer commandeers `mLastPortalX`, which belongs to the engine's portal logic. This avoids breaking portal coordinates when Brutal variants spawn.
- The in-game Evo toggle is now wired into plant initialization. New in-play plants receive an Evo profile only while Evo mode is enabled; plants already placed are not silently transformed when the toggle changes.
- Evo state is stored in `Plant::mBrutalEvo`, not in `mTargetX` or `mEatenFlashCountdown`. The old `mTargetX = 7777` sentinel could corrupt targeting, and reusing the flash countdown could interfere with visual/gameplay counters.
- Evo fire-rate stacking and Evo bonus-sun behavior are now limited to plants marked as Evo, rather than applying those Evo-only rewards to every normal plant.
- The generic Evo fallback is bounded to a 10% faster launch rate and 20% health increase, avoiding the prior 50% blanket health increase. Plants with dedicated profiles retain their specific values.
- Removed an unused local zombie-form flag.
- Added `assets/ai/README.md` explaining that this project uses C++ gameplay logic and does not ship a neural-network model or custom Unnamed animation assets.

## Verification performed

- ZIP archive integrity checked before editing; source tree extracted and reviewed.
- Static checks: only one `mBrutalEvo` member exists in `Plant`; Brutal logic no longer references `mLastPortalX`; Evo hook is called from plant initialization; no `mTargetX = 7777` remains.
- CMake configuration was attempted locally but stops before compilation because the environment does not have `libopenmpt` installed (`OPENMPT_LIBRARY` not found). Therefore this pass is **not** claimed to have passed a full native or Android compile. GitHub Actions remains the authoritative build check.

## Known gaps / don't mistake these for verified features

- The project is a reimplementation inspired by community/fanon descriptions, not the original proprietary Unnamed/Brutal executable. Where source rules are ambiguous, the implementation is an approximation.
- Zombie form variety is still limited to the implemented form cases. Most zombie types have stat/behavior adjustments, but they do not all have a separate custom visual form.
- Evo plants currently have a per-plant state marker and stat profiles, plus Evo-gated shooter stacking and bonus sun. This is not yet a faithful recreation of every plant-specific Evo mechanic from the source mod; exact source spreadsheets/screenshots are needed to implement undocumented effects reliably.
- Unique custom art/animation rigs are not included. The current game reuses existing legal game data/animations.
- Full Android compile/runtime playtest is still required to discover compiler, packaging, and in-game timing issues that static review cannot prove away.

## Follow-up patch (v4)

- Fixed the missing comma in the `ZOMBIE_BACKUP_DANCER` row of `Challenge.h` that caused the reported `expected '}'` compiler error.
- Added every built-in challenge minigame, all I-Zombie stages, and all Scary Potter stages to the Secrets picker. The likely "Bingo" name is shown as **Bingo / Beghouled**; the engine mode is the built-in Beghouled challenge.
- Expanded the secrets dialog to four columns to fit the larger list on the 800x600 game canvas.
- Added an `EVO: ON/OFF` button next to Imitater on the Adventure seed chooser. It toggles one catalog in place (no second seed-bank row); toggling resets the draft selection to prevent unavailable Evo cards from becoming stuck in the normal catalog.
- Evo mode exposes all base plant cards and uses a separate cost table. Evo Sunflower costs 75 sun; Evo Sun-shroom costs 0. Other non-free plant costs are rounded to 25-sun increments at 1.25x base cost. Existing art is reused; this is a gameplay variant/catalog, not a newly authored sprite set.
- Pole-vaulter grave placement now targets the landing tile one grid column behind the vault and refuses to place a grave on any live plant tile.

## Validation status

- `tools/brutal_static_audit.py`: 12/12 existing checks passed after the patch.
- Additional source assertions and ZIP integrity checks were run for the new secret table, Evo toggle/costs, and pole-vaulter landing placement.
- A full local CMake configure/build remains blocked because this environment lacks the `libopenmpt` development library. GitHub Actions is still required to validate the Android compilation and runtime behavior.
