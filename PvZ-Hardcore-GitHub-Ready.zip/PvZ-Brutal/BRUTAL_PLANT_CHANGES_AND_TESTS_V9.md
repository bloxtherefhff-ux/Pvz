# Original PvZ Brutal Mode — Plant Changes and Tests (v9)

This is the original Brutal Mode source, not EX/EX Plus. Values and effects below describe source code; an Android build and device playtest are still required.

## Newly fixed

- **Torchwood stacking:** a pea ignited by the first Torchwood becomes a tier-1 fireball (40 direct damage); subsequent Torchwoods can upgrade it up to tier 5 (50/60/70/80 direct damage). Tier 2+ fireballs apply chill. Each projectile remembers the last Torchwood column it touched so it does not repeatedly upgrade at the same column. Stack testing should cover one through six Torchwoods, peas moving right, and Split Pea shots moving left.
- **Snow Pea charged shot:** 22% of Snow Pea shots are now a charged frost pea. It remains `PROJECTILE_SNOWPEA`, so it retains the normal slowing effect, and deals double direct damage (40 instead of 20). Previously this chance converted it to a fireball, which removed the chill effect. Passing it through a Torchwood intentionally converts it into a fireball as usual.

## Plant cost / recharge changes

| Plant | Cost | Recharge ticks | Plant | Cost | Recharge ticks |
|---|---:|---:|---|---:|---:|
| Peashooter | 125 | 650 | Sunflower | 75 | 900 |
| Cherry Bomb | 175 | 5500 | Wall-nut | 75 | 2700 |
| Potato Mine | 75 | 2500 | Snow Pea | 200 | 900 |
| Chomper | 125 | 650 | Repeater | 225 | 900 |
| Puff-shroom | 0 | 600 | Sun-shroom | 50 | 900 |
| Fume-shroom | 125 | 900 | Grave Buster | 50 | 600 |
| Hypno-shroom | 125 | 3500 | Scaredy-shroom | 100 | 650 |
| Ice-shroom | 100 | 5500 | Doom-shroom | 200 | 6000 |
| Lily Pad | 50 | 600 | Squash | 75 | 2500 |
| Threepeater | 300 | 900 | Tangle Kelp | 75 | 2500 |
| Jalapeño | 150 | 5500 | Spikeweed | 150 | 900 |
| Torchwood | 200 | 900 | Tall-nut | 150 | 3500 |
| Sea-shroom | 0 | 2500 | Plantern | 125 | 2500 |
| Cactus | 150 | 650 | Blover | 150 | 900 |
| Split Pea | 150 | 700 | Starfruit | 200 | 900 |
| Pumpkin | 225 | 3500 | Magnet-shroom | 100 | 700 |
| Cabbage-pult | 125 | 700 | Flower Pot | 50 | 600 |
| Kernel-pult | 125 | 700 | Coffee Bean | 100 | 900 |
| Garlic | 75 | 650 | Umbrella Leaf | 125 | 900 |
| Marigold | 200 | 2500 | Melon-pult | 350 | 900 |
| Gatling Pea | 300 | 6000 | Twin Sunflower | 200 | 5500 |
| Gloom-shroom | 175 | 6000 | Cattail | 250 | 6000 |
| Winter Melon | 275 | 6500 | Gold Magnet | 75 | 4500 |
| Spikerock | 175 | 5500 | Cob Cannon | 600 | 6500 |
| Imitater | copied cost +25 | copied recharge +750 | Explode-o-nut | 0 | 2500 |
| Giant Wall-nut | 0 | 3500 | Sprout | 0 | 3000 |
| Leftpeater | 175 | 700 | | | |

## Additional source effects already present

- Shooter-family fire-rate changes with a lower-bound safety clamp.
- Faster sun production hooks for Sunflower, Twin Sunflower, and Sun-shroom.
- Scaredy-shroom launch/health tuning; Garlic durability and poison; instant Potato Mine arming; adjusted Chomper digestion; Cob Cannon load tuning; Cactus/Starfruit firing tuning; Tangle Kelp multi-grab.
- Wall-nut/Tall-nut sustain; Spikeweed/Spikerock Brutal effects; Pumpkin death burst; Puff-shroom/Sea-shroom defensive effect; Gold Magnet shock; Plantern shooter support; Marigold combat pulse.
- Existing special attacks in the source include a 33% extra-spread chance for Repeater, Threepeater firing mixed ice/fire projectiles, Split Pea front fire/back ice, and a 17% extra lane strike for Melon-pult/Winter Melon. These should be tested in-game before assuming the behavior is bug-free.
- Evo plants remain disabled in original Brutal Mode.

## Device test checklist

1. Snow Pea: fire at least 100 shots; roughly 22 should be charged (random variation expected). Verify charged pea deals 40 damage and still slows; ordinary shot deals 20 and slows.
2. Snow Pea + Torchwood: verify the projectile becomes fire and no longer chills, matching Torchwood's fire behavior.
3. Torchwood stack: put 1–6 Torchwoods in one row with a Peashooter behind them. Measure damage per hit at 1/2/3/4/5 Torchwoods; damage should cap at tier 5. Ensure no repeated tier upgrade at the same torch.
4. Repeat stack test with Split Pea firing backward; verify no crash or accidental re-upgrade loop.
5. Test at least one placement, cost, recharge, special ability, and save/load for every plant.

## Verification boundary

Source edits and archive integrity can be checked here. Full Android compilation and runtime behavior require the GitHub Actions build and testing on a device; not claimed as complete here.
