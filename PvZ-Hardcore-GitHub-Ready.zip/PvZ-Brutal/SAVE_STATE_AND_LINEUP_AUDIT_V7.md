> **Superseded for save-state UI and plant balancing by `SAVE_STATE_AND_PLANT_AUDIT_V8.md`.** The former text-input save commands have been replaced by the in-game **SAVE STATE** button. Historical lineup notes below remain useful.

# Save State + Original Brutal Mode Lineup Audit (v7)

## Manual save states
- Added three manual slots through the existing Cheats input: `save 1`, `save 2`, `save 3`; restore with `load 1`, `load 2`, `load 3`.
- Uses the engine's existing board serializer (`LawnSaveGame` / `Board::LoadGame`) so state includes the serialized board rather than only level/progress metadata.
- Slots are stored in `userdata/brutal_state_1.v4` through `userdata/brutal_state_3.v4` under the application's data directory.
- Save/load is rejected outside an actively running level. Invalid slot syntax and empty/incompatible slots display an error dialog.

## Original Brutal Mode lineups
Compared `Board.cpp` level-specific allowed-zombie roster cases against public Beta 5.40 descriptions. The documented pools for 6-1 through 6-4 and 6-7 through 6-9 match the published lists. 6-6 is constrained using the user's screenshot but exact per-wave counts cannot be recovered from one image. 6-5 is a special garden/minigame stage; 6-10 is the Zomboss finale with 4,000 starting sun and seed selection as specified by the user.

Reference: https://www.youtube.com/watch?v=WUL8dP5Ajyk and https://www.youtube.com/watch?v=Md2vdfdl5mw

## Validation boundary
- Source-level checks only: this environment does not have the SDL development headers needed for a full C++ compile.
- Run GitHub Actions and test save/load in a real level before treating this as runtime-verified.
