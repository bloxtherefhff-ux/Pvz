# Brutal mobile patch notes

## Fixes in this patch
- Fixed the missing comma in `src/Lawn/Challenge.h` that caused the reported `expected '}'` compile failure in the zombie-wave initializer.
- Hardened `Board::CanAddGraveStoneAt`: it rejects out-of-range grid coordinates and refuses to place a gravestone over a live grounded plant. Brutal pole-vaulter landing graves therefore cannot delete/block the plant they jump over.
- Added Beghouled and Beghouled Twist to the Secret picker, mapped to the engine's existing challenge modes.
- Expanded the Secret picker dialog so its two-column layout has enough vertical space for the added entries.

## Important limitation
The existing Evo toggle in this codebase marks newly planted base plants as Evo-enhanced. It does **not yet implement separate Evo seed packet identities/costs** (for example, Evo Sunflower at 75 sun or Evo Sun-shroom at 0 sun). That requires extending the seed chooser, seed packet state, planting/cost pipeline, and plant initialization together. This patch does not claim that separate Evo plants are finished.

## Verification
- ZIP integrity checked.
- Source-level assertions checked the repaired initializer, grave-placement guard, secret IDs/table entries, and dialog sizing.
- A full Android C++ build has not been run here; GitHub Actions must confirm compiler/linker success.
