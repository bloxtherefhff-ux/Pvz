# Brutal Android patch audit — v4

## Implemented in this pass
- Fixed the GitHub Actions compile error in `src/Lawn/Challenge.h`: the backup-dancer row initializer was missing a comma before the next row.
- Added an `EVO` / `NORMAL` catalog toggle beside Imitater in seed selection. Evo mode filters to the 20 Evo plant entries currently documented by the Unnamed fanon reference. Switching catalogs clears the current seed selection so one loadout cannot mix modes accidentally.
- Added mode-aware seed costs for the documented Evo entries, including Evo Sunflower = 75 and Evo Sun-shroom = 0. The same cost function is used for chooser and in-level seed packet cost display and actual placement cost.
- Removed the main-menu `CHEATS` and `BEST ALL` buttons. In-level `CHEATS` remains available.
- Removed the cheat menu's level-skip / `Jump 1-1` through `Jump 5-1` shortcuts.
- Split no-cooldown and free-planting behavior. No-cooldown no longer enables the engine's broad easy-plant cheat; free planting no longer automatically removes cooldowns.
- Scoped custom in-level cheats (infinite sun, no cooldown, free planting) to the current board/level by resetting them when a new Board is constructed.
- Added an `ADMIN` button beside the in-level menu button, visible only for profiles named exactly `admin` or `Admin`. It opens a two-column zombie spawner listing every `ZombieType` in `NUM_ZOMBIE_TYPES`.
- Fixed Brutal speed multipliers to preserve the negative X velocity used by zombies moving left. Newspaper's mad-speed fallback now also moves left instead of accidentally assigning positive velocity.

## Reference used
The Evo catalog and costs were cross-checked against the Plants vs. Zombies: Unnamed fanon page:
https://plantszombiesfanon.fandom.com/wiki/Plants_vs._Zombies:_Unnamed
This is a fanon/community reference, not official PopCap documentation; its Evo section explicitly says some functions are unknown. Therefore, the cost list is based on that page, while undocumented mechanics should not be presented as verified original behavior.

## Validation and limits
- Archive structure and ZIP CRC are checked after packaging.
- Source checks verify the reported missing-comma line is fixed, admin UI and all-zombie list are present, and level-skip shortcuts are absent.
- CMake configuration was attempted locally but cannot proceed in this environment because `libopenmpt` / `OPENMPT_LIBRARY` is not installed. Therefore a full C++/Android build and in-game behavior test are **not verified** in this environment.
- This patch improves the Evo selection/cost identity and the admin test tools, but it does **not** prove every Evo special ability or every fanon zombie variant has been faithfully implemented. Custom animation/art assets are not included. The upstream game’s original zombie AI is still used for vanilla movement and pole vaulting.
