# Brutal Mode — bug audit and test report (this revision)

Scope honestly stated: this revision is a targeted source fix plus workflow hardening. It is
NOT a full 60-plant runtime audit, and the Android APK was NOT built or run in the environment
used for these changes (no Android NDK, no SDL headers, no network, no device).

## Input

Uploaded archive: `PvZ-Hardcore-GitHub-Ready.zip` (contains `PvZ-Brutal/`, 648 entries).
The request referred to `PvZ-Brutal-GitHub-Ready-v9.zip`; the uploaded file was used as the source of truth.

## Piercing investigation

Fume-shroom (`Plant::Fire`, `Plant::DoRowAreaDamage`):
- Does NOT use a projectile. Each volley calls `DoRowAreaDamage(20, 2U)`, which iterates all zombies,
  filters by row and `GetPlantAttackRect` overlap (x = plant+40 .. plant+760), and calls `TakeDamage`.
- Result: it already damages every eligible zombie in its row in one volley. The projectile
  "dies on first hit" logic is not involved. No code change was made to Fume-shroom.
- Caveat: this is verified from source only. The instant area hit is consistent with "piercing,"
  but gameplay on device was not observed. If testers still see single-target behavior, the cause
  is not in this code path and needs a device log.

Starfruit (`Plant::StarFruitFire`, `Projectile::DoImpact`):
- Root cause confirmed: `DoImpact` ends with an unconditional `Die()`, so every star was destroyed by its
  first zombie hit, even though the in-game Brutal Almanac says "piercing stars."
- This is the one plant whose documented intent (in this project's own Almanac text) is piercing and
  whose code does not pierce. It is the only projectile fix made.

Other plants mentioned as piercing in the Almanac, not changed:
- Cactus ("dual spikes / pierce"): Cactus uses `PROJECTILE_SPIKE` and ordinary projectile death. The
  Almanac wording is ambiguous ("dual spikes" vs "pierce"), so no change was made without a clearer spec.
- Cattail ("pierce + rare Cob shots"): uses a board-wide targeting rect and a homing-style projectile.
  Not changed; needs a design decision on whether it should pierce.
- Do not add piercing to plants not listed here.

## Files changed

- `src/Lawn/Projectile.h`: added `kMaxPierceHits` (16), `mPierceHitCount`, `mPierceHitIDs[]` (in-class
  initialized), and declarations for `IsPiercingStar`, `AlreadyPierced`, `RecordPierceHit`.
- `src/Lawn/Projectile.cpp`:
  - `ProjectileInitialize`: resets the hit list.
  - `FindCollisionTarget`: skips zombies the projectile already pierced.
  - `DoImpact`: records the hit for piercing stars; only calls `Die()` on a ground impact, a missing zombie,
    or a full hit list. Non-star projectiles still die on impact exactly as before.
  - New helpers `IsPiercingStar`, `AlreadyPierced`, `RecordPierceHit`.
- `.github/workflows/android.yml`: NDK step no longer hides `sdkmanager --install` failures with `|| true`,
  and no longer silently falls back to a different NDK. It fails if the pinned NDK toolchain file is absent.
- `PLANT_CHANGES_GUIDE.txt`: Starfruit piercing entry added; Fume-shroom attack mechanics documented.
- `tests/pierce_star_logic_test.cpp`: new standalone logic test (see below).
- `BRUTAL_BUG_AUDIT_AND_TESTS.md`: this report.

## Piercing star implementation details

- Each star stores up to 16 zombie IDs it has struck.
- Targeting skips those IDs, so a star overlapping a zombie for many frames damages it once.
- A hit on a non-null zombie does not destroy the star unless the list is full.
- Splash, shield, body, and Torchwood/Snow Pea logic are untouched; they run through the same `DoImpact` path.
- Star damage per hit remains 12 (Brutal value).

## Build and tests

Commands run:
- `unzip -l` / `unzip -q` on the uploaded archive: OK.
- `g++ -std=c++17 -fsyntax-only Projectile.cpp`: FAILED, `SDL.h` not found. The game sources cannot be
  syntax-checked here without SDL2 headers. The edits to `Projectile.cpp/.h` have NOT been compiled.
- `g++ -std=c++17 -Wall -Wextra tests/pierce_star_logic_test.cpp && ./pierce_test`: 8/8 checks passed.
  This test models the rules; it does not compile or run the game binary.

Not run:
- CMake configure / native build (needs NDK, vcpkg, SDL2).
- Gradle `assembleRelease` and APK inspection.
- GitHub Actions run.
- Any on-device or emulator gameplay test, including the 3-zombie piercing check in the real game.
- Full 60-plant runtime audit and the full guide cross-check against source values.

## Known remaining problems

1. Gradle wrapper: `android/gradlew` and `gradle-wrapper.jar` are absent. The workflow generates the
   wrapper with `gradle wrapper --gradle-version 8.12` when `gradlew` is missing. This was NOT verified
   against the AGP version in `android/build.gradle`.
2. The workflow still uses `|| true` for `sdkmanager --licenses` (expected when licenses are already accepted)
   and for `llvm-strip` (non-essential).
3. `PLANT_CHANGES_GUIDE.txt` covers 53 numbered entries. The project may define more plants, including
   variants and imitater-related rows; completeness was not verified.
4. Cactus, Cattail: piercing intent is ambiguous in the Almanac text. Left unchanged.
5. Fume-shroom may still be perceived as non-piercing on device if the 720-px row rect does not reach a
   visually-expected distance. Needs device testing before a claim is made.
6. Debug signing and any production signing: not addressed in this revision.

## Revision 2 — secrets

Root causes found in source (verified by reading the code, not on device):

1. "Dr. Zomboss Revenge says missing…" (and every secret banner): `Board::DisplayAdvice` receives
   `"[SECRET] " + title`. `PvzpStringTranslate` treats any string starting with `[` as a string-table key
   and drops its first and last characters, so the banner showed `<Missing SECRET] …>`.
   Fix: banner text is now `"SECRET: " + title` (`BrutalSecrets.cpp`).

2. Crash-prone launch for minigame secrets (Sunshine Storm, Visual Distortion, Air Raid, Night Fright,
   Slot Crisis, Invisible Guardians): `LaunchBrutalSecret` set the game mode to the minigame, then called
   `BrutalSafeRestartAdventure()`, which is the adventure restart path. Fix: minigame secrets now start
   through `PreNewGame(challengeMode, false)`, the same route the hidden Limbo/Puzzle modes use
   (`BrutalPickDialog.cpp`). Adventure secrets are unchanged.

3. Pool 3-1 secret ("No Swimming"): removed a block that rewrote `board->mLevel` to 21 after the board was
   built and wrote level 21 into the player's save. `startLevel` is already 21, so the block was redundant
   and unsafe (`BrutalSecrets.cpp`).

Not verified:
- Which specific level crashes on the device. The fix above matches the most likely cause, but I could not
  reproduce it. A device log (`adb logcat` or the crash report) would confirm it.
- Zombie-vs-plant behavior: the report did not say what goes wrong, so no change was made.
- Cheat-box `secret <name>` still forces adventure mode for minigame secrets (`CheatDialog.cpp`). Left as-is.
- Plant and zombie definitions were not re-verified against a device.
