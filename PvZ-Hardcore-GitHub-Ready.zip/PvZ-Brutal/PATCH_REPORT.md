# Brutal Mode patch report — v4

## Fixes in this pass

- Fixed the malformed `ZOMBIE_BACKUP_DANCER` initializer in `src/Lawn/Challenge.h`: the missing comma between the final row and the following row caused the reported `expected '}'` Android C++ build error.
- Restored and retained the main-menu `SECRETS`, `CHEATS`, and `BEST ALL` buttons.
- Removed the five hard-coded `Jump 1-1` through `Jump 5-1` buttons. The normal `Skip Level` action remains available.
- Split `Free Plants` into its own button. `No Cooldown` enables no cooldown plus free planting, as requested. `Infinite Sun` remains a separate visible cheat.
- Made no-cooldown actively refill seed packet refresh counters while enabled instead of only refreshing once when the button is pressed.
- Scoped the temporary cheat state to the selected Adventure level and clear it when the profile advances to another level.
- Added an admin-only `ADMIN ZOMBIES` button to the main menu when the current profile name is `admin` or `Admin` (case-insensitive).
- Added a compact zombie picker covering all `ZombieType` values. If a board is active it spawns immediately; from the title menu it queues the selected zombie and starts the current Adventure level for testing.
- Added `tools/brutal_triple_check.py` for focused source-level regression checks.

## Triple-check results

1. Existing Brutal static audit: 12/12 checks passed.
2. New regression audit: 14/14 checks passed.
3. ZIP integrity and source-tree checks are run during packaging.

## Important limits

The Android build is **not confirmed successful in this environment**. CMake configuration stops before compilation because `OPENMPT_LIBRARY` (`openmpt` / `libopenmpt`) is not installed in the local environment. The reported malformed initializer is fixed in source, but GitHub Actions must compile the Android target to prove the complete build. A real game run is still required to verify admin spawning and cheat scoping on-device.

The Evo system remains a reimplementation/approximation of the documented fan-mod behavior, not proof of exact parity with the original executable. This pass verifies the Evo initialization path and the existing per-instance guards; it does not claim that every Evo effect is a perfect recreation.
