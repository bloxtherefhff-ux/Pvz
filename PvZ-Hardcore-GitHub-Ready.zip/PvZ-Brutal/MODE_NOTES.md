# What changed this pass (not plants / not zombies / not book)

Wikipedia does not document fan “Brutal Mode”. We only adjusted **global mode systems**:

1. Wave health trigger → next wave sooner (0.45×)
2. Extra zombies per wave → 4 (max 55)
3. Day sky sun countdown slightly longer (tighter economy)
4. Menu/docs: modes named like official PvZ (Adventure, Mini-Games, Puzzle, Survival)

**Not changed:** plant skills, zombie forms/abilities, almanac [BRUTAL] text.
