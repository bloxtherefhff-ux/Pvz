# What changed in this pass

1. Wired the Evo toggle to new in-play plant creation; Evo is stored on each plant instance.
2. Removed the unsafe `mTargetX = 7777` / flash-counter marker and replaced it with `Plant::mBrutalEvo`.
3. Limited Evo shooter stacking and bonus-sun effects to Evo-tagged plants.
4. Separated Brutal zombie form IDs from `mLastPortalX`, preserving the engine's portal state.
5. Added an `assets/ai/README.md` describing the actual C++ behavior architecture and missing custom visual assets.
6. Added `BRUTAL_AUDIT.md` with verification results and explicit remaining limitations.

This is a source-level repair pass, not a claim of perfect 1:1 Unnamed parity. Full Android build and in-game testing are still required.
