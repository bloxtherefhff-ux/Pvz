# Original Brutal Mode Lineup / Campaign Audit

This source package now ends at **6-10 (stage ID 60)**. World 7 / stage IDs 61–70 have been removed from the campaign arrays and level-specific zombie roster. This patch targets original PvZ Brutal Mode, not EX or EX Plus.

## Publicly documented original-mode lineups

The publicly described original Brutal Mode Beta 5.40 reference documents the following World 6 pools:

- 6-1: Browncoats, Coneheads, Peashooter-head Screen Door zombies, Newspapers, Ladders.
- 6-2: Browncoats, Coneheads, Catapults, Pole Vaulters, Balloons.
- 6-3: Browncoats, Screen Doors, Wall-nut-head Screen Doors, Squash-head Screen Doors plus Buckets, Zombonis.
- 6-4: Browncoats, Coneheads, Pole Vaulters, Footballs, Squash-head Screen Doors plus Buckets, Jalapeno-head Coneheads.
- 6-5: a special garden/minigame-style stage; its implementation uses the level’s documented mixed lineup pool.
- 6-7: Browncoats, Screen Doors, Pole Vaulters, Ladders, Catapults, Zombonis, Balloons.
- 6-8: Browncoats, Newspapers, Jack-in-the-boxes, Wall-nut-head Screen Doors, Gargantuars.
- 6-9: Browncoats, Coneheads, Pole Vaulters, Footballs, Ladders, Tall-nut-head Screen Doors, Gargantuars.

Reference videos used for these descriptions: https://www.youtube.com/watch?v=OmVa_onkUnM and https://www.youtube.com/watch?v=WUL8dP5Ajyk . This is community gameplay evidence, not an official machine-readable wave table.

## User-provided corrections for 6-6 and 6-10

- **6-6:** the screenshot supplied in this conversation is the lineup reference. The allowed roster includes the visible standard zombies, cone-headed Jalapeno Zombotany, Peashooter-head Screen Door zombies, and the other visible special/armored variants. Exact per-wave counts cannot be recovered from a single screenshot, so it is used to constrain the level roster, not claimed to reconstruct every wave count.
- **6-10:** this is the Dr. Zomboss fight, shown through the original boss-level engine path, with **Choose Your Seeds** and **4,000 starting sun**. On the first clear, the level awards the silver trophy, marks Adventure complete, and leads into the credits. The original 5-10 boss remains a mid-campaign boss and no longer awards the adventure trophy.

## Checks specific to this package

- Campaign constants are 6 areas × 10 levels = 60.
- `gZombieWaves` and the non-special `gZombieAllowedLevels` rows contain 60 stage entries; special-only zombie rows keep their single `{0}` initializer.
- The special World 6 zombie filter covers 6-1 through 6-10 only; no stage-61–70 cases remain.
- The paginated main-menu Secrets picker includes the custom Brutal secrets and playable modes listed on the otherwise hidden Limbo and Puzzle pages, excluding Intro/Upsell transitions.
- Original-mode Evo UI and activation are disabled; Evo plants are reserved for the user’s separate EX Plus build.

## Validation boundary

The checks above are source-level inspections. A full native compile was not available in this environment because required SDL/OpenMPT development dependencies are absent; an Android GitHub Actions run and in-game test are still required to confirm runtime behavior.
