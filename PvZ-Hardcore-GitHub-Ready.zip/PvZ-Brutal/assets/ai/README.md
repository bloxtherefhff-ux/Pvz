# AI / behavior assets

This project does not use a neural-network AI model for zombie behavior. The gameplay AI is ordinary C++ state-machine logic in `src/Lawn/Zombie.cpp`, `src/Lawn/Plant.cpp`, and `src/Lawn/Brutal/BrutalMode.cpp`.

- Implement movement, attacks, targeting, variant rules, and special effects in C++.
- Put custom sprites/reanimations in the game's resource pipeline; an image or JSON file alone does not create a working animated zombie.
- Best path for missing visuals: create original sprite sheets/reanimation tracks compatible with PvZ-Portable's resource format, or reuse existing animations while implementing the behavior in C++.
- Do not copy proprietary assets from a commercial mod unless you have permission to redistribute them.
