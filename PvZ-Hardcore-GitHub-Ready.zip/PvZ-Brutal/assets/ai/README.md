# AI / behavior assets — important distinction

This project does not currently have a data-driven `assets/ai` runtime. PvZ-Portable is a C++ game engine: zombie decisions (movement, target selection, attacks, special-form effects) are implemented in `src/Lawn/Zombie.cpp` and `src/Lawn/Brutal/BrutalMode.cpp`. Plant rules live in `src/Lawn/Plant.cpp` and `src/Lawn/Brutal/BrutalMode.cpp`.

There is no missing neural-network model to download. For this 2D lane-defense game, the reliable and mobile-friendly option is deterministic C++ behavior code. A JSON folder alone would do nothing unless a parser and runtime loader were added, so this folder intentionally documents the architecture rather than pretending a configuration file is active.

## Visual assets

The ZIP does not include the original Unnamed/Brutal custom sprite sheets or animation rigs. The game can only display visuals supplied by the player's legally obtained PvZ data or new compatible assets. The current Brutal forms reuse the portable game's existing animations and apply tinting/behavior changes. For unique zombie silhouettes, the best next step is to create original sprite sheets and compatible reanimation definitions; an ordinary PNG alone is not enough to drive the engine's named animation tracks.
