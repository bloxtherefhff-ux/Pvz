# AI / behavior assets

This folder is intentionally not a model or neural-network directory. PvZ Portable's zombies and plants use C++ state machines plus the game's reanimation data. A JSON file here cannot create a new animated zombie by itself.

For this mobile port, the preferred workflow is:
1. Implement mechanics in `src/Lawn/Brutal/BrutalMode.cpp` and the relevant plant/zombie/projectile hooks.
2. Reuse existing legal game reanimations for prototypes.
3. For distinct visuals, add authored sprite/reanimation assets compatible with the engine and reference them through the engine's resource definitions. Do not ship ripped assets from another mod unless you have permission.
4. Add one regression case per mechanic and run the Android workflow plus in-game checks.
