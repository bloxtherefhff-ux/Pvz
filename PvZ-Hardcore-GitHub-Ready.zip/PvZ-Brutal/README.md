# PvZ Brutal Mode (Android)

PvZ-Portable + **Unnamed 1.1.0–style skills** reimplemented in open C++.

See **BRUTAL.md** for the mapping from the Unnamed Excel sheet.

## Build APK
GitHub Actions → **Build PvZ Brutal Mode Android APK** → `pvz-brutal-android-arm64-v8a`.

Import legal GOTY `main.pak` + `properties/` on device. No Unnamed assets shipped.


## Admin zombie spawner

Create/select a profile named `Admin` (case-insensitive), start a level, open the in-game cheat dialog, and enter `spawn <type> [row]`. Examples: `spawn cone 3`, `spawn redgarg 5`, `spawn boss`. Row is 1–5 on standard boards and 1–6 on pool/6-row boards. Supported names include normal, flag, cone, pole, bucket, newspaper, door, football, dancer, duckytube, snorkel, zamboni, bobsled, dolphin, jack, balloon, digger, pogo, yeti, bungee, ladder, catapult, garg, redgarg, imp, boss, peahead, wallnuthead, jalapenohead, gatlinghead, squashhead, tallnuthead.

This admin command is a local profile-name gate, not account security.

See `BRUTAL_TRIPLE_AUDIT.md` for verified source checks and explicitly listed remaining mechanics. Do not treat the APK as verified until the Android workflow succeeds and gameplay tests pass.
