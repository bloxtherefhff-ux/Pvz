# PvZ Brutal Mode (Android)

PvZ-Portable + **Unnamed 1.1.0–style skills** reimplemented in open C++.

See **BRUTAL.md** for the mapping from the Unnamed Excel sheet.

## Build APK
GitHub Actions → **Build PvZ Brutal Mode Android APK** → `pvz-brutal-android-arm64-v8a`.

Import legal GOTY `main.pak` + `properties/` on device. No Unnamed assets shipped.

## Cheats

The in-game **CHEATS** button includes **Evo Plants ON/OFF** and **Admin: Empty Test Board**. The admin sandbox starts Adventure 1-1 with zero zombie waves. World 7 levels 7-1 through 7-10 use different stage-gated zombie rosters. See `BRUTAL_AUDIT.md` for known limitations and verification status.
