# PvZ Brutal Mode (Android)

PvZ-Portable + **Unnamed 1.1.0–style skills** reimplemented in open C++.

See **BRUTAL.md** for the mapping from the Unnamed Excel sheet.

## Build APK
GitHub Actions → **Build PvZ Brutal Mode Android APK** → `pvz-brutal-android-arm64-v8a`.

Import legal GOTY `main.pak` + `properties/` on device. No Unnamed assets shipped.
