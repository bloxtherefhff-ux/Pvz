# Brutal Mode — three-pass source audit

## Reference boundary

The reference used for the Unnamed-style rules is the community-maintained Plants vs. Zombies: Unnamed fanon page: https://plantszombiesfanon.fandom.com/wiki/Plants_vs._Zombies:_Unnamed . It explicitly warns that the Evo section is newly written and that many functions are unknown. Therefore it is not authoritative proof of an exact commercial mod build. Engine behavior is cross-checked against this project's C++ implementation.

## Pass 1 — structure and integration

- Confirmed Android workflow, CMake project, plant/zombie/board implementations, BrutalMode module, cheat dialog, and app state are present.
- Fixed missing `mBrutalEvoPlanting` declaration in `LawnApp.h` (the menu and constructor referenced it).
- Evo state is now stored per plant in `mBrutalEvo`, not in `mTargetX` (which is used for actual targeting).
- Added per-instance Evo counters initialized both in constructor and plant initialization.
- Brutal zombie form state now uses `mBrutalForm`; `mLastPortalX` remains reserved for portal/projectile behavior.

## Pass 2 — behavior audit

- Letterhead form chance adjusted to about 1/9, its body health is doubled, its speed is multiplied by 4, and it ignores plants through `CanTargetPlant`.
- Letterhead tint now checks the zombie type so other forms that use the numeric form ID `1` do not receive the Letterhead tint.
- Evo toggle is applied before plant initialization hooks, so one-shot Evo effects can see the flag.
- Evo Peashooter uses snow-pea projectiles; Evo Kernel-pult forces butter; Evo Chomper deals 60 damage and clears freeze counters; Evo Sunshroom gives a 100–200 sun burst; Evo Blover returns zombies to the rightmost column and heals body/helmet/shield; Evo Gatling Pea damages the highest-health living zombie for 500 every 300 ticks; Evo Tall-Nut summons a hypnotized Newspaper/Football/Gargantuar after each 1200 damage.
- The Evo implementation is intentionally per-instance. It no longer grants generic stat buffs to every plant merely because no specific rule was written.
- Added admin-only spawn commands to the existing cheat dialog. The active profile name must be `Admin` (case-insensitive); enter `spawn <type> [row]` while playing.

## Pass 3 — static regression checks

- Verify no Brutal form references remain on `mLastPortalX`.
- Verify no `mTargetX = 7777` Evo marker remains.
- Verify the Evo toggle is declared, initialized, toggled, and read by `PlantInitialize`.
- Verify admin spawn parser, profile gate, row bounds, and Board spawn call are present.
- Verify ZIP integrity after packaging.

## Known gaps — not represented as fixed

This port still does not exactly reproduce every Unnamed Evo mechanic. In particular, distinct Evo seed packet costs, Wall-nut bowling movement, Evo Cherry Bomb's projectile spread/re-explosion, Evo Puff-shroom poison, Gravebuster seed drops, Hypnoshroom-to-Imp conversion, Scaredy-shroom tap shot, Plantern shadow power, Starfruit's random status table, Cabbage-pult's 3x3 splash/three-lane powered mode, Coffee Bean 3x3 wake, Umbrella projectile reflection, and Gloom-shroom fire/ice toggle/reload still need full mechanics. The current engine also lacks custom sprites/reanimation assets for several named zombie variants. These require additional source changes and in-game validation, not just an `assets/ai` folder.

## Build status

A local CMake configure was attempted but stopped at the environment dependency check because `libopenmpt` development files were not installed. This is not a successful native or Android build. Run `.github/workflows/android.yml` in GitHub Actions and test the resulting APK on-device before treating it as release-ready.
