# Brutal Mode implementation audit notes

This file began as an audit of prototype Unnamed/Evo code. It is **historical context**, not a claim that those features are enabled in the current original Brutal Mode build.

## Current package boundary

- The current package targets original PvZ Brutal Mode with 60 campaign stages and ends at 6-10. World 7 is removed.
- The current package does not expose an Evo selector, Evo cheat toggle, or Evo activation. Evo plants belong in a separate EX Plus project. Dormant per-plant fields/functions remain in the shared source but are always initialized false in this package.
- Zombie forms and Brutal combat hooks remain part of this source, subject to the current original-mode stage lineup restrictions.
- The main-menu Secrets button opens a paginated directory of custom Brutal secrets plus playable hidden Limbo/Puzzle challenge modes.

## Remaining validation

Static source checks do not replace an Android build or testing on a device. Confirm the generated APK launches, the 60-stage campaign ends at 6-10, the 6-10 Zomboss intro and seed chooser work with 4,000 starting sun, the first win awards the trophy, and each paginated secret entry starts the intended game mode.
