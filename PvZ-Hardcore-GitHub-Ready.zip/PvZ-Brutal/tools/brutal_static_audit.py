#!/usr/bin/env python3
"""Small regression checks for Brutal-specific state wiring."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
plant_h = (root / 'src/Lawn/Plant.h').read_text()
plant_cpp = (root / 'src/Lawn/Plant.cpp').read_text()
app_h = (root / 'src/LawnApp.h').read_text()
app_cpp = (root / 'src/LawnApp.cpp').read_text()
mode_cpp = (root / 'src/Lawn/Brutal/BrutalMode.cpp').read_text()
mode_h = (root / 'src/Lawn/Brutal/BrutalMode.h').read_text()
zombie_h = (root / 'src/Lawn/Zombie.h').read_text()
zombie_cpp = (root / 'src/Lawn/Zombie.cpp').read_text()
checks = {
    'single per-plant Evo flag': plant_h.count('mBrutalEvo;') == 1,
    'Evo app flag declared': 'mBrutalEvoPlanting' in app_h,
    'Evo app flag initialized': 'mBrutalEvoPlanting = false;' in app_cpp,
    'Evo profile invoked by plant initialization': 'ApplyEvoPlant(plant);' in mode_cpp,
    'Evo firing is instance-gated': 'if (!kEnabled || !plant || !plant->mBrutalEvo)' in mode_cpp,
    'Evo sun bonus is instance-gated': 'mBoard || !plant->mBrutalEvo' in mode_cpp,
    'no target sentinel': 'mTargetX = 7777' not in mode_cpp,
    'no flash counter marker': 'mEatenFlashCountdown = 40' not in mode_cpp,
    'dedicated zombie form member declared': 'mBrutalForm;' in zombie_h,
    'Brutal logic does not commandeer portal field': 'mLastPortalX' not in mode_cpp,
    'zombie render uses dedicated form': 'mBrutalForm == BrutalMode::BRUTAL_CONE_GRAMOPHONE' in zombie_cpp,
    'AI/assets limitation documented': (root / 'assets/ai/README.md').exists(),
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f'{len(checks)} static checks passed')
