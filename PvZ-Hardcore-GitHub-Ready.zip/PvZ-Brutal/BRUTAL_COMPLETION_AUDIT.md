# Brutal Mode follow-up audit (v4)

## Changes made in this pass
- Fixed the missing comma in the `ZOMBIE_BACKUP_DANCER` wave-allowance initializer in `src/Lawn/Challenge.h`, matching the Android compiler diagnostic.
- Fixed Brutal pole-vaulter grave placement: it now searches the landing tile and adjacent tiles and refuses to place a grave over a living plant. If no empty legal tile exists, it skips the grave rather than destroying a plant.
- Added an `ADMIN` button to the title/game selector, visible only when the current profile name is `admin` or `Admin` (case-insensitive).
- Added an admin zombie picker listing all `NUM_ZOMBIE_TYPES` regular zombie types. Choosing one queues that zombie and starts the current Adventure level; the queue is consumed once in `Board::StartLevel`.
- Removed the fixed `Jump 1-1` through `Jump 5-1` buttons from the Cheats dialog as requested.
- Removed a duplicate assignment to the same zombie helmet field.

## Important limitations — not falsely marked complete
- Evo plants are **not yet represented as independent seed packet types** with their own persistent identity/costs. The existing `mBrutalEvoPlanting` toggle applies a gameplay profile to ordinary plant types; this does not satisfy the requested distinct Evo selection list/cost model (e.g. Evo Sunflower 75 and Evo Sun-shroom 0). That requires carrying an Evo-variant flag through chooser selection, seed packet, cursor, plant placement, display/cost, and refresh logic. This pass does not claim that work is finished.
- The admin picker uses existing game visuals and behavior; it does not create missing custom zombie art/animations.
- Static source checks and ZIP integrity are not a substitute for a complete Android NDK build or in-game testing. The exact earlier build error was addressed, but this environment did not complete the full Android build.

## Verification checklist
1. Archive integrity (`unzip -t`).
2. Check the malformed initializer no longer contains a missing separator.
3. Check pole-vaulter grave placement contains plant-occupancy guard and bounded candidate columns.
4. Check admin button is profile-gated and the picker enumerates `NUM_ZOMBIE_TYPES`.
5. Check the pending admin zombie is reset to `-1` after one spawn.
6. Check the old fixed world-jump buttons are absent.
