# Save-State UI + Complete Plant Balance Audit (v8)

- Target is **original PvZ Brutal Mode (Beta 5.40-style campaign)**, not EX/EX Plus.
- The in-level bottom button row now has **SAVE STATE** next to **CHEATS**. Save State opens a stone-button menu with `Save Slot 1–3`, `Load Slot 1–3`, and `Back to Game`.
- Slot files use the engine serializer at `userdata/brutal_state_1.v4`, `userdata/brutal_state_2.v4`, and `userdata/brutal_state_3.v4` within app data. Load/save is only allowed while a level is running. UI reports success, missing/incompatible slot, or write error.
- Removed the text-entry save/load handler from the Cheats dialog; saving/loading is now button-driven instead of requiring commands.

## Plant cost and recharge roster

The `PlantDefinition` table contains 53 plant types, including Imitater, Leftpeater, and non-standard bowling/Zen Garden plant definitions. The checks below compare the complete definition list to the new cost and recharge switch profiles. Costs are sun; recharge values are engine ticks in the same units as the original plant definitions. Imitater resolves the copied plant type and adds a 25-sun / 750-tick surcharge. Beghouled’s explicit special costs and zombie-seed costs remain on their pre-existing special paths.

| Plant type | Base cost → Brutal cost | Base recharge → Brutal recharge |
|---|---:|---:|
| `PEASHOOTER` (`SEED_PEASHOOTER`) | 100 → 125 | 750 → 650 |
| `SUNFLOWER` (`SEED_SUNFLOWER`) | 50 → 75 | 750 → 900 |
| `CHERRY_BOMB` (`SEED_CHERRYBOMB`) | 150 → 175 | 5000 → 5500 |
| `WALL_NUT` (`SEED_WALLNUT`) | 50 → 75 | 3000 → 2700 |
| `POTATO_MINE` (`SEED_POTATOMINE`) | 50 → 75 | 3000 → 2500 |
| `SNOW_PEA` (`SEED_SNOWPEA`) | 175 → 200 | 750 → 900 |
| `CHOMPER` (`SEED_CHOMPER`) | 150 → 125 | 750 → 650 |
| `REPEATER` (`SEED_REPEATER`) | 200 → 225 | 750 → 900 |
| `PUFF_SHROOM` (`SEED_PUFFSHROOM`) | 0 → 0 | 750 → 600 |
| `SUN_SHROOM` (`SEED_SUNSHROOM`) | 25 → 50 | 750 → 900 |
| `FUME_SHROOM` (`SEED_FUMESHROOM`) | 100 → 125 | 750 → 900 |
| `GRAVE_BUSTER` (`SEED_GRAVEBUSTER`) | 75 → 50 | 750 → 600 |
| `HYPNO_SHROOM` (`SEED_HYPNOSHROOM`) | 100 → 125 | 3000 → 3500 |
| `SCAREDY_SHROOM` (`SEED_SCAREDYSHROOM`) | 125 → 100 | 750 → 650 |
| `ICE_SHROOM` (`SEED_ICESHROOM`) | 75 → 100 | 5000 → 5500 |
| `DOOM_SHROOM` (`SEED_DOOMSHROOM`) | 150 → 200 | 5000 → 6000 |
| `LILY_PAD` (`SEED_LILYPAD`) | 25 → 50 | 750 → 600 |
| `SQUASH` (`SEED_SQUASH`) | 50 → 75 | 3000 → 2500 |
| `THREEPEATER` (`SEED_THREEPEATER`) | 350 → 300 | 750 → 900 |
| `TANGLE_KELP` (`SEED_TANGLEKELP`) | 50 → 75 | 3000 → 2500 |
| `JALAPENO` (`SEED_JALAPENO`) | 125 → 150 | 5000 → 5500 |
| `SPIKEWEED` (`SEED_SPIKEWEED`) | 125 → 150 | 750 → 900 |
| `TORCHWOOD` (`SEED_TORCHWOOD`) | 175 → 200 | 750 → 900 |
| `TALL_NUT` (`SEED_TALLNUT`) | 125 → 150 | 3000 → 3500 |
| `SEA_SHROOM` (`SEED_SEASHROOM`) | 0 → 0 | 3000 → 2500 |
| `PLANTERN` (`SEED_PLANTERN`) | 150 → 125 | 3000 → 2500 |
| `CACTUS` (`SEED_CACTUS`) | 175 → 150 | 750 → 650 |
| `BLOVER` (`SEED_BLOVER`) | 125 → 150 | 750 → 900 |
| `SPLIT_PEA` (`SEED_SPLITPEA`) | 175 → 150 | 750 → 700 |
| `STARFRUIT` (`SEED_STARFRUIT`) | 175 → 200 | 750 → 900 |
| `PUMPKIN` (`SEED_PUMPKINSHELL`) | 200 → 225 | 3000 → 3500 |
| `MAGNET_SHROOM` (`SEED_MAGNETSHROOM`) | 125 → 100 | 750 → 700 |
| `CABBAGE_PULT` (`SEED_CABBAGEPULT`) | 100 → 125 | 750 → 700 |
| `FLOWER_POT` (`SEED_FLOWERPOT`) | 25 → 50 | 750 → 600 |
| `KERNEL_PULT` (`SEED_KERNELPULT`) | 100 → 125 | 750 → 700 |
| `COFFEE_BEAN` (`SEED_INSTANT_COFFEE`) | 75 → 100 | 750 → 900 |
| `GARLIC` (`SEED_GARLIC`) | 100 → 75 | 750 → 650 |
| `UMBRELLA_LEAF` (`SEED_UMBRELLA`) | 100 → 125 | 750 → 900 |
| `MARIGOLD` (`SEED_MARIGOLD`) | 150 → 200 | 3000 → 2500 |
| `MELON_PULT` (`SEED_MELONPULT`) | 300 → 350 | 750 → 900 |
| `GATLING_PEA` (`SEED_GATLINGPEA`) | 250 → 300 | 5000 → 6000 |
| `TWIN_SUNFLOWER` (`SEED_TWINSUNFLOWER`) | 150 → 200 | 5000 → 5500 |
| `GLOOM_SHROOM` (`SEED_GLOOMSHROOM`) | 125 → 175 | 5000 → 6000 |
| `CATTAIL` (`SEED_CATTAIL`) | 200 → 250 | 5000 → 6000 |
| `WINTER_MELON` (`SEED_WINTERMELON`) | 200 → 275 | 5000 → 6500 |
| `GOLD_MAGNET` (`SEED_GOLD_MAGNET`) | 50 → 75 | 5000 → 4500 |
| `SPIKEROCK` (`SEED_SPIKEROCK`) | 125 → 175 | 5000 → 5500 |
| `COB_CANNON` (`SEED_COBCANNON`) | 500 → 600 | 5000 → 6500 |
| `IMITATER` (`SEED_IMITATER`) | 0 → copy + 25 | 750 → copy + 750 |
| `EXPLODE_O_NUT` (`SEED_EXPLODE_O_NUT`) | 0 → 0 | 3000 → 2500 |
| `GIANT_WALLNUT` (`SEED_GIANT_WALLNUT`) | 0 → 0 | 3000 → 3500 |
| `SPROUT` (`SEED_SPROUT`) | 0 → 0 | 3000 → 3000 |
| `LEFTPEATER` (`SEED_LEFTPEATER`) | 200 → 175 | 750 → 700 |

## Existing combat behavior reviewed

- Shooter-family fire-rate ramp is capped; the profile still clamps launch rate to a safe minimum.
- Sunflower/Twin Sunflower/Sun-shroom production acceleration remains active; bonus-sun hooks are kept.
- Scaredy-shroom health/launch-rate tuning, Garlic durability/poison, instant Potato Mine arming, Chomper digest timing, Cob Cannon load tuning, Cactus/Starfruit fire-rate tuning, and Tangle Kelp multi-grab behavior remain in place.
- Wall-nut/Tall-nut sustain, Spikeweed/Spikerock Brutal effects, Pumpkin death burst, Puff-shroom/Sea-shroom defensive effect, Gold Magnet shock, Plantern shooter support, and Marigold combat pulse remain in place.
- Original Brutal Mode has Evo disabled. The Evo code path remains dormant and is not activated by this change.

## Verification and limits

- Static coverage script: **all 53 entries in `gPlantDefs` have a case in both plant cost and plant recharge profiles**; the save-state dialog has all six save/load buttons plus a close button; all button draw/update/click wiring and app launch declarations were checked.
- ZIP integrity will be checked after packaging.
- A native CMake build could not configure here because `libopenmpt` development library is missing. A direct C++ syntax check is also blocked because SDL headers (`SDL.h`) are unavailable. Therefore Android compilation and in-game runtime testing remain unverified and should be confirmed by GitHub Actions/device testing.
