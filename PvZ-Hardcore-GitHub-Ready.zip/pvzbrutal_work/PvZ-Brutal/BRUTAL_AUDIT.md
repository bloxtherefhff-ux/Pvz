# Brutal / Unnamed implementation audit — v4

## Corrected in v4

- Evo mode no longer applies a generic stat buff or price change to every plant. It recognizes only the Evo counterparts listed in the public Unnamed reference. Plants without a documented Evo counterpart retain their normal cost and are not marked as Evo.
- Added explicit Evo seed costs and routed both planting affordability and seed-packet display through `Board::GetCurrentPlantCost`. Costs include Evo Sunflower 75 and Evo Sun-shroom 0 (the latter follows the user's requested balance rather than the wiki's incomplete/uncertain Evo data).
- Implemented Evo Sunflower's faster first sun and 40-sun production (25 + 15) and Evo Sun-shroom's one-time 100–200 sun burst followed by consumption.
- Added Evo Gatling Pea's 500-damage strongest-zombie strike every 5 seconds.
- Removed the bogus fallback that boosted unrelated plants when Evo mode was enabled.
- Fixed Unnamed fire-rate stacking so only Peashooter and Cabbage-pult get that passive; unrelated shooters no longer inherit it.
- Fixed Wall-nut's 48-second full-heal to use a dedicated no-damage timer instead of its lifetime animation counter and removed unintended gradual healing.
- Fixed Lily Pad and Flower Pot recharge to 5 seconds.
- Fixed Cob Cannon's reload adjustment: the previous `max(1000, launchRate * 32 / 35)` forced the rate to at least 1000, which contradicts a faster reload. It now subtracts 300 ticks, bounded at 100.
- Fixed Starfruit's Unnamed fire interval adjustment to be slower rather than faster, and removed unintended global fire-rate boosts from ordinary sun producers and Cactus.
- Pole-vault graves now skip landing tiles occupied by a plant, preventing the grave from overwriting the plant on landing.

## Reference used

The community-maintained Plants vs. Zombies: Unnamed page describes the base plant changes and Evo variants. It is fanon/community documentation, not official source code, and explicitly notes that several Evo behaviors remain uncertain: https://plantszombiesfanon.fandom.com/wiki/Plants_vs._Zombies:_Unnamed

## Important remaining gaps

This is still a C++ reimplementation using Portable's existing SeedType values and art. The toggle currently chooses the Evo profile for a supported plant type; it does **not** add a completely separate red-present seed packet for every Evo plant. Evo Peashooter's powered/unpowered projectile transformation, Evo Cherry Bomb's multi-stage Grapeshot behavior, Evo Wall-nut's rolling movement, Evo Puff-shroom poison, Evo Grave Buster seed refund, Evo Hypno-shroom's Imp conversion, Evo Tall-nut's ally spawning, Evo Plantern's adjacency-powered shadow network, Evo Blover's time-warp effect, Evo Starfruit's random effects, Evo Cabbage-pult's three-lane powered attack, Evo Coffee Bean's area wake-up, Evo Umbrella's projectile reflection, and Evo Gloom's fire/ice modes are not all implemented by this patch. Do not treat the Evo roster as complete until each of those mechanics is implemented and tested.

The Unnamed page's base plant abilities are also broader than this patch. Some are implemented in `BrutalMode.cpp`/`Plant.cpp`, but repeater diagonal shots, full Cattail Cob-shot behavior, all Starfruit piercing effects, all zombie variants, and exact custom animation assets remain incomplete. This report intentionally lists those gaps rather than claiming a perfect recreation.

## Verification

- Run `python3 tools/brutal_static_audit.py` for source-wiring regression checks.
- ZIP integrity and source-tree diff are checked when packaging.
- A static source check is not an Android build or gameplay proof. GitHub Actions must still compile the APK; then test the Evo cost display, placing supported and unsupported plants, sun pickup, Wall-nut healing, and Pole Vaulter landings in-game.
